Imports System.Collections
Public Class Context
    
    Dim fl As vbFile
    Dim x() As Single, y() As Single
    Dim plts As PlotStrategy
    '-----
    Public Sub setLinePlot()
        plts = New LinePlotStrategy()
    End Sub
    '-----
    Public Sub setBarPlot()
        plts = New BarPlotStrategy()
    End Sub
    '-----
    Public Sub plot()
        readFile()
        plts.plot(x, y)      'do whatever kind of plot
    End Sub
    '-----
    Private Sub readFile()
        Dim xc As New arraylist()
        Dim yc As New arrayList()
        Dim sline As String
        Dim tmp As Single
        Dim i As Integer
        'reads data in from data file
        fl = New vbFile("data.txt")
        fl.OpenForRead()
        
        While Not fl.fEof
            sline = fl.readLine
            i = sline.IndexOf(" ")
            If i > 0 Then
                tmp = sline.Substring(0, i).ToSingle
                xc.Add(tmp)
                tmp = sline.Substring(i + 1).ToSingle
                yc.Add(tmp)
            End If
        End While
        'copy into arrays from collections
        Dim xp(xc.Count) As Single
        Dim yp(yc.Count) As Single
        For i = 0 To xc.Count - 1
            xp(i) = CType(xc(i), Single)
            yp(i) = CType(yc(i), Single)
        Next i
        x = xp
        y = yp
        fl.closeFile()
    End Sub
    
End Class
