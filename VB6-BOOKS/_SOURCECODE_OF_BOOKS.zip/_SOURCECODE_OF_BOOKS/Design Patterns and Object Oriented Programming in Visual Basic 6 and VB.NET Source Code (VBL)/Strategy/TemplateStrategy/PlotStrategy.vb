Public MustInherit Class PlotStrategy
    Public MustOverride Sub plot(ByVal x() As Single, ByVal y() As Single)
End Class
