Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class LineButton
    Inherits BarButton
    'Implements Command
    Public Sub New()
        MyBase.New

        'This call is required by the Win Form Designer.
        InitializeComponent

        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    Dim WithEvents LineButton As System.WinForms.UserControl

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Public Overrides Sub Execute()
        contxt.setLinePlot()
        contxt.plot()
    End Sub
End Class
