Public Class LinePlotStrategy
    Inherits PlotStrategy
    Public Overrides Sub plot(ByVal x() As Single, ByVal y() As Single)
        Dim lplot As New LinePlot()
        lplot.Show()
        lplot.plot(x, y)
    End Sub
End Class
