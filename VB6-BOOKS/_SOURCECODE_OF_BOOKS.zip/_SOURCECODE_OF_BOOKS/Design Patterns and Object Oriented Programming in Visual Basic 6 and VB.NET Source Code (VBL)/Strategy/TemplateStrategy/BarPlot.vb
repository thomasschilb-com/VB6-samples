Imports System.Drawing
Imports System.WinForms
Imports System.ComponentModel
Imports System.Collections

Public Class BarPlot
    Inherits PlotWindow
    
    Private colors As arraylist
    '-----    
    Public Sub New()
        MyBase.New()
        BarPlot = Me
        InitializeComponent()
        colors = New arraylist()
        colors.Add(New SolidBrush(Color.Red))
        colors.Add(New SolidBrush(color.Green))
        colors.Add(New SolidBrush(color.Blue))
        colors.Add(New SolidBrush(Color.Magenta))
        colors.Add(New SolidBrush(color.Yellow))
    End Sub
    '-----    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    
    Dim WithEvents BarPlot As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pic = New System.WinForms.PictureBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Pic.Location = New System.Drawing.Point(24, 24)
        Pic.Size = New System.Drawing.Size(256, 216)
        Pic.TabIndex = 0
        Pic.TabStop = False
        
        Me.Text = "BarPlot"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(Pic)
    End Sub
    
#End Region
    '-----    
    Public Overridable Sub Pic_Paint(ByVal sender As Object, ByVal e As System.WinForms.PaintEventArgs) Handles Pic.Paint
        Dim g As Graphics = e.Graphics
        Dim i, ix, iy As Integer
        Dim br As Brush
        If hasData Then
            For i = 0 To x.Length - 1
                ix = calcx(x(i))
                iy = calcy(y(i))
                br = CType(colors(i), brush)
                g.FillRectangle(br, ix, h - iy, 20, iy)
            Next
        End If
    End Sub
    Public Overloads Sub plot(ByVal x() As Single, ByVal y() As Single)
        MyBase.plot(x, y, pic)
    End Sub
    
    Public Overrides Sub repaint()
        pic.Refresh()
    End Sub
End Class
