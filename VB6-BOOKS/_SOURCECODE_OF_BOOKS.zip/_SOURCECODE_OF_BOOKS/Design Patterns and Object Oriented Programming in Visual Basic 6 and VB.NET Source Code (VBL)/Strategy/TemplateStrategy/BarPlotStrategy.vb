Public Class BarPlotStrategy
    Inherits PlotStrategy
    Public Overrides Sub plot(ByVal x() As Single, ByVal y() As Single)
        Dim bplot As New BarPlot()
        bplot.Show()
        bplot.plot(x, y)       
    End Sub
End Class
