Imports System
Imports System.IO
Imports System.ComponentModel

Public Class vbFile
    'encapsulates the common read, write, exists and delete methods
    'for text file manipulation
    
    Private opened As Boolean   'true if file is open
    Private end_file As Boolean 'true if at end of file
    Private errDesc As String   'text of last error message
    Private File_name As String 'name of file
    Private fl As File
    Private ts As StreamReader
    Private tok As StringTokenizer
    Private tokLine As String
    Private fs As FileStream
    Private sw As StreamWriter
    Private errFlag As Boolean
    Private lineLength As Integer
    Private sep As String           'tokenizer separator
    '-----
    Public Sub New(ByVal filename As String)
        MyBase.New()
        file_name = filename
        fl = New File(file_name)
        tokLine = ""
        sep = ","
    End Sub
    
    Public Overloads Function OpenForRead() As Boolean
        OpenForRead = OpenForRead(file_name)
        
    End Function
    
    Public Overloads Function OpenForRead(ByVal Filename As String) As Boolean
        file_name = Filename
        errFlag = False
        end_File = False
        tok = New StringTokenizer("")
        Try
            ts = fl.Opentext()
        Catch e As Exception
            errDesc = e.Message
            Console.writeline(errDesc)
            errFlag = True
        End Try
        openForRead = errFlag
        
    End Function
    
    Public Function readLine() As String
        Dim s As String
        Try
            s = ts.readLine
            lineLength = s.length
        Catch e As Exception
            end_file = True
            s = ""
            'finally
            'readLine = s 
            'return( s)
        End Try
        Return s
    End Function
    
    
    Public Function readToken() As String
        Dim token As String
        
        token = tok.nextToken
        If (token.length < 1) Then
            tokLine = ts.readLine
            tok = New StringTokenizer(tokLine, sep)
            token = tok.nextToken
        End If
        
        Return token
    End Function
    
    Public Sub closeFile()
        ts.close()
    End Sub
    
    Public Function exists() As Boolean
        exists = fl.exists
    End Function
    
    Public Function getLastError() As String
        getlastError = errDesc
    End Function
    
    Public Function OpenForWrite(ByVal fname As String) As Boolean
        errFlag = False
        Try
            file_name = fname
            fs = New FileStream(fname, FileMode.OpenOrCreate, FileAccess.Write)
            sw = New StreamWriter(fs)
        Catch e As Exception
            errDesc = e.Message
            errflag = True
        End Try
        openForWrite = errFlag
    End Function
    
    Public Sub writeText(ByVal s As String)
        sw.writeLine(s)
    End Sub
    
    Public Sub setFilename(ByVal fname As String)
        file_name = fname
    End Sub
    
    Public Function getFilename() As String
        getFilename = file_name
    End Function
    
    Public Function fEOF() As Boolean
        fEOF = end_file
    End Function
    
End Class


