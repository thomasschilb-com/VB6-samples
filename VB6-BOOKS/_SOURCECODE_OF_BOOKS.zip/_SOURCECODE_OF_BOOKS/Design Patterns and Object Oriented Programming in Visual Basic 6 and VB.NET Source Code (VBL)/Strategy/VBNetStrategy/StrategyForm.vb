Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private contxt As Context
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent()
        Dim evh As EventHandler = New EventHandler(AddressOf ButClick)
        AddHandler btLine.Click, evh
        AddHandler btBar.Click, evh
        contxt = New Context()
        btbar.setContext(contxt)
        btline.setContext(contxt)
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 
    Public Sub ButClick(ByVal Sender As Object, ByVal e As EventArgs)
        Dim cmd As Command
        cmd = CType(Sender, command)
        cmd.Execute()
    End Sub
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btBar As VBNetStrategy.BarButton
    Private WithEvents btLine As VBNetStrategy.LineButton
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btBar = New VBNetStrategy.BarButton()
        Me.btLine = New VBNetStrategy.LineButton()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        btBar.Location = New System.Drawing.Point(184, 32)
        btBar.Size = New System.Drawing.Size(75, 23)
        btBar.TabIndex = 1
        btBar.Text = "Bar plot"
        
        btLine.Location = New System.Drawing.Point(40, 32)
        btLine.Size = New System.Drawing.Size(75, 23)
        btLine.TabIndex = 0
        btLine.Text = "Line plot"
        Me.Text = "Strategy plots"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(296, 157)
        
        Me.Controls.Add(btBar)
        Me.Controls.Add(btLine)
    End Sub
    
#End Region
    
End Class
