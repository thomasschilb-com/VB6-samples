Imports System.Drawing
Imports System.WinForms


Imports System.ComponentModel


Public Class LinePlot
    Inherits BarPlot
    
    Public Sub New()
        MyBase.New
        LinePlot = Me
        InitializeComponent()
        bpen = New Pen(Color.Black)
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    
    Dim WithEvents LinePlot As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pic = New System.WinForms.PictureBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Pic.Location = New System.Drawing.Point(24, 16)
        Pic.Size = New System.Drawing.Size(256, 216)
        Pic.TabIndex = 0
        Pic.TabStop = False
        Me.Text = "LinePlot"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(Pic)
    End Sub
    
#End Region

    Public Overrides Sub Pic_Paint(ByVal sender As Object, ByVal e As System.WinForms.PaintEventArgs) Handles Pic.Paint
        Dim g As Graphics = e.Graphics
        Dim i, ix, iy, ix1, iy1 As Integer
        Dim br As Brush
        If hasData Then
            For i = 1 To x.Length - 1
                ix = calcx(x(i - 1))
                iy = calcy(y(i - 1))
                ix1 = calcx(x(i))
                iy1 = calcy(y(i))
                g.drawline(bpen, ix, iy, ix1, iy1)
            Next
        End If
    End Sub
End Class
