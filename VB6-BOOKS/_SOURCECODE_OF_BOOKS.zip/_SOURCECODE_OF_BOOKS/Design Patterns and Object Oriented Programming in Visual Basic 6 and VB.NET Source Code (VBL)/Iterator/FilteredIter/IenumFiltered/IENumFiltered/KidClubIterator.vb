Imports System.Collections
Public Class KidClubIterator
    Implements IEnumerator
    'Class KidClubIterator
    Private index As Integer
    Private kidList As arraylist
    Private club As String
    '-----
    Public Sub New(ByRef col As ArrayList, ByRef clb As String)
        MyBase.New()
        index = 0
        kidList = col
        club = clb
    End Sub
    '-----
    Public Function MoveNext() As Boolean Implements System.Collections.IEnumerator.MoveNext
        index = index + 1
        Dim more As Boolean
        Dim kd As Kid
        more = index < kidList.Count()
        If more Then
            kd = CType(kidList.Item(index), kid)
            While more And kd.getClub <> club
                kd = CType(kidList.Item(index), kid)
                index = index + 1
                more = index < kidList.Count()
            End While
        End If
        Return more
    End Function
    '-----
    Public Sub Reset() Implements System.Collections.IEnumerator.Reset
        index = 0
    End Sub
    '-----
    Public ReadOnly Property Current() As Object Implements System.Collections.IEnumerator.Current
        Get
            Return kidList.Item(index)
        End Get
    End Property
End Class
