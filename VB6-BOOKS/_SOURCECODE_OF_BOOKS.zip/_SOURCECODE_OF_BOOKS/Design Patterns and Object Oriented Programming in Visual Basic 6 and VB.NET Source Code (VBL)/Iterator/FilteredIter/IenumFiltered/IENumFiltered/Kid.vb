	Public  Class Kid
		
		'Public Class Kid
		
		Private  lname, frname, club As String
		Private  age As Short
		Private  time As Single
		'-------------------------------------
    Public Sub New(ByVal line As String)
        MyBase.new()
        Dim lnum As String
        Dim tok As StringTokenizer
        tok = New StringTokenizer(line)
        tok.setSeparator(" ")
        lnum = tok.nextToken()
        frname = tok.nextToken
        lname = tok.nextToken()
        age = tok.nextToken().ToInt16
        club = tok.nextToken()
        time = tok.nextToken().ToSingle
    End Sub
    
    '--------------------------------
    Public Function getAge() As Short
        getAge = age
    End Function
    Public Function getTime() As Single
        getTime = time
    End Function
    Public Function getFrname() As String
        getFrname = frname
    End Function
    Public Function getLname() As String
        getLname = lname
    End Function
    Public Function getClub() As String
        getClub = club
    End Function
End Class
