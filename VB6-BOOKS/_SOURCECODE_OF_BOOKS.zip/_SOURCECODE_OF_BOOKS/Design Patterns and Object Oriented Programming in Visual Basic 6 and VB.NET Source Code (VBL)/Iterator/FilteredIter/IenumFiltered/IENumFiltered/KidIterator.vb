Imports System.Collections
Public Class KidIterator
    Implements IEnumerator
    
    Private index As Integer
    Private kidList As ArrayList
    '-----
    Public Sub New(ByVal col As Arraylist)
        index = 0
        kidList = col
    End Sub
    '-----
    Public Function MoveNext() As Boolean _
        Implements System.Collections.IEnumerator.MoveNext
        index = index + 1
        Return index < kidList.Count
    End Function
    '-----
    Public Sub Reset() Implements _
        System.Collections.IEnumerator.Reset
        index = 0
    End Sub
    '-----
    Public ReadOnly Property Current() As Object _
        Implements System.Collections.IEnumerator.Current
        Get
            Return kidList.Item(index)
        End Get
    End Property
End Class
