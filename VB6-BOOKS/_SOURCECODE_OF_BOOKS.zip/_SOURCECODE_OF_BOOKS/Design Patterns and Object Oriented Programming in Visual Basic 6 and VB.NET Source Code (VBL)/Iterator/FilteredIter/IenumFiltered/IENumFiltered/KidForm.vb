
Imports System.Collections

Public Class KidForm
    Inherits System.WinForms.Form
    Private Shared m_vb6FormDefInstance As KidForm
    Public Shared Property DefInstance() As KidForm
        Get
            If m_vb6FormDefInstance Is Nothing Then
                m_vb6FormDefInstance = New KidForm()
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#Region " Windows Form Designer generated code "
    ' Required by the Win Form Designer
    Private components As System.ComponentModel.Container
    Public ToolTip1 As System.WinForms.ToolTip
    'Public Tag1 As Microsoft.VisualBasic.Compatibility.VB6.Tag
    Private WithEvents KidForm As KidForm
    Public WithEvents lscKids As System.WinForms.ListBox
    Public WithEvents cbClubs As System.WinForms.ComboBox
    Public WithEvents List1 As System.WinForms.ListBox
    Public Sub New()
        MyBase.New()
        Me.KidForm = Me
        ' This call is required by the Win Form Designer
        If m_vb6FormDefInstance Is Nothing Then
            m_vb6FormDefInstance = Me
        End If
        InitializeComponent()
        Form_Load()
    End Sub
    ' Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    ' The main entry point for the application
    Shared Sub Main()
        System.WinForms.Application.Run(New KidForm())
    End Sub
    ' NOTE: The following procedure is required by the Win Form Designer
    ' It can be modified using the Win Form Designer.
    ' Do not modify it using the code editor.
    
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.WinForms.ToolTip(components)
        '        Me.Tag1 = New Microsoft.VisualBasic.Compatibility.VB6.Tag()
        ToolTip1.Active = True
        ' @design ToolTip1.SetLocation(New System.Drawing.Point(7,7))
        ' @design Tag1.SetLocation(New System.Drawing.Point(90,7))
        Me.lscKids = New System.WinForms.ListBox()
        Me.cbClubs = New System.WinForms.ComboBox()
        Me.List1 = New System.WinForms.ListBox()
        Me.ControlBox = True
        Me.Text = "Kid List"
        Me.ClientSize = New System.Drawing.Size(362, 244)
        Me.Location = New System.Drawing.Point(4, 23)
        Me.StartPosition = System.WinForms.FormStartPosition.WindowsDefaultLocation
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BorderStyle = System.WinForms.FormBorderStyle.Sizable
        Me.Enabled = True
        Me.KeyPreview = False
        Me.MaximizeBox = True
        Me.MinimizeBox = True
        Me.Cursor = System.Drawing.Cursors.Default
        Me.RightToLeft = System.WinForms.RightToLeft.No
        Me.ShowInTaskbar = True
        Me.HelpButton = False
        Me.WindowState = System.WinForms.FormWindowState.Normal
        lscKids.Size = New System.Drawing.Size(121, 121)
        lscKids.Location = New System.Drawing.Point(224, 56)
        lscKids.TabIndex = 2
        lscKids.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        lscKids.BackColor = System.Drawing.SystemColors.Window
        lscKids.CausesValidation = True
        lscKids.Enabled = True
        lscKids.ForeColor = System.Drawing.SystemColors.WindowText
        lscKids.IntegralHeight = True
        lscKids.Cursor = System.Drawing.Cursors.Default
        lscKids.SelectionMode = System.WinForms.SelectionMode.One
        lscKids.RightToLeft = System.WinForms.RightToLeft.No
        lscKids.Sorted = False
        lscKids.TabStop = True
        lscKids.Visible = True
        lscKids.MultiColumn = False
        cbClubs.Size = New System.Drawing.Size(113, 21)
        cbClubs.Location = New System.Drawing.Point(224, 16)
        cbClubs.TabIndex = 1
        cbClubs.Text = "Combo1"
        cbClubs.BackColor = System.Drawing.SystemColors.Window
        cbClubs.CausesValidation = True
        cbClubs.Enabled = True
        cbClubs.ForeColor = System.Drawing.SystemColors.WindowText
        cbClubs.IntegralHeight = True
        cbClubs.Cursor = System.Drawing.Cursors.Default
        cbClubs.RightToLeft = System.WinForms.RightToLeft.No
        cbClubs.Style = System.WinForms.ComboBoxStyle.DropDown
        cbClubs.TabStop = True
        cbClubs.Visible = True
        List1.Size = New System.Drawing.Size(161, 160)
        List1.Location = New System.Drawing.Point(24, 32)
        List1.TabIndex = 0
        List1.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        List1.BackColor = System.Drawing.SystemColors.Window
        List1.CausesValidation = True
        List1.Enabled = True
        List1.ForeColor = System.Drawing.SystemColors.WindowText
        List1.IntegralHeight = True
        List1.Cursor = System.Drawing.Cursors.Default
        List1.SelectionMode = System.WinForms.SelectionMode.One
        List1.RightToLeft = System.WinForms.RightToLeft.No
        List1.Sorted = False
        List1.TabStop = True
        List1.Visible = True
        List1.MultiColumn = False
        Me.Controls.Add(lscKids)
        Me.Controls.Add(cbClubs)
        Me.Controls.Add(List1)
    End Sub
#End Region
    'Class KidForm
    Dim kidz As Kids ' same as iter
    Dim clubs As ArrayList
    Private Sub addClub(ByRef club As String)
        Dim i As Integer
        Dim found As Boolean
        found = False
        i = 0
        While i < clubs.count And Not found
            found = (CType(clubs(i), String) = club)
            i = i + 1
        End While
        If Not found Then
            clubs.add(club)
        End If
    End Sub
    Private Sub sortClubs()
        'UPGRADE_ISSUE: Declaration of cb was changed.
        Dim cb(clubs.count) As String
        Dim j, i, max As Integer
        Dim tmp As String
        
        max = clubs.Count()
        For i = 0 To max - 1
            cb(i) = CType(clubs(i), String)
        Next i
        For i = 0 To max - 1
            For j = i To max - 1
                If cb(i) > cb(j) Then
                    tmp = cb(i)
                    cb(i) = cb(j)
                    cb(j) = tmp
                End If
            Next j
        Next i
        clubs = Nothing
        clubs = New ArrayList()
        For i = 0 To max - 1
            clubs.add(cb(i))
        Next i
    End Sub
    
    Private Sub cbClubs_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Dim club As String
        Dim iter As ienumerator
        Dim kd As Kid
        
        club = cbClubs.Text
        iter = kidz.getClubIterator(club)
        lscKids.Items.Clear()
        While iter.MoveNext
            kd = CType(iter.Current, Kid)
            lscKids.Items.Add(kd.getFrname & " " & kd.getLname)
        End While
        
    End Sub
    
    Private Sub Form_Load()
        Dim iter As IEnumerator  ' same as kidz
        Dim kd As Kid
        Dim i As Integer
        
        clubs = New arraylist()
        kidz = New Kids(System.WinForms.Application.StartUpPath & "\50free.txt")
        'initialize the collection class
        'and read in the data file
        'treat collection class as iterator
        iter = kidz.getIterator
        While iter.MoveNext  ' load into listbox
            kd = CType(iter.Current, kid)
            List1.Items.Add(kd.getFrname & " " & kd.getLname)
            addClub(kd.getClub)
        End While
        sortClubs()
        For i = 0 To clubs.Count() - 1
            cbClubs.Items.Add(clubs.Item(i))
        Next i
        cbClubs.SelectedIndex = 0
    End Sub
End Class
