Imports System.Collections
Public Class KidClubIterator
    Implements Iterator
    'Class KidClubIterator
    Private index As Integer
    Private kidList As arraylist
    Private club As String
    '-----
    Public Sub New(ByRef col As ArrayList, ByRef clb As String)
        MyBase.New()
        index = 0
        kidList = col
        club = clb
    End Sub
    '-----
    Public Function hasMoreElements() As Boolean Implements Iterator.hasMoreElements
        Dim more As Boolean
        Dim kd As Kid
        more = index < kidList.Count()
        If more Then
            kd = CType(kidList.Item(index), kid)
            While more And kd.getClub <> club
                kd = CType(kidList.Item(index), kid)
                index = index + 1
                more = index < kidList.Count()
            End While
        End If
        Return more
    End Function
    '-----
    Public Sub moveFirst() Implements Iterator.moveFirst
        index = 0
    End Sub
    '-----
    Private Function nextElement() As Object Implements Iterator.nextElement
        index = index + 1
        Return kidList.Item(index - 1)
    End Function
End Class
