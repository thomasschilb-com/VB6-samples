Interface Iterator
    Sub moveFirst()
    
    Function hasMoreElements() As Boolean
    
    Function nextElement() As Object
End Interface
