Imports System.Collections
Public Class KidIterator
    Implements Iterator
    'Class KidIterator
    Private index As Integer
    Private kidList As ArrayList
    '-----
    Public Sub New(ByVal col As Arraylist)
        index = 0
        kidList = col
    End Sub
    Private Function hasMoreElements() As Boolean Implements Iterator.hasMoreElements
        Return index < kidList.Count
    End Function
    '-----
    Private Sub moveFirst() Implements Iterator.moveFirst
        index = 0
    End Sub
    '-----
    Private Function nextElement() As Object Implements Iterator.nextElement
        index = index + 1
        Return kidList.Item(index - 1)
    End Function
End Class
