Imports System.Collections
Public Class Kids
    'Class Kids
    
    Private kidList As Arraylist
    Private index As Short
    Public Sub New(ByRef Filename As String)
        MyBase.New()
        Dim sline As String ' line read in
        Dim vbf As vbFile = New vbFile(filename) ' file class
        Dim kd As Kid ' kid object
        kidList = New ArrayList()
        vbf.OpenForRead() ' open the file
        sline = vbf.readLine
        While sline.Length > 0 ' read in the lines
            kd = New Kid(sline)
            kidList.add(kd) ' Add to collection
            sline = vbf.readLine
        End While
        vbf.closeFile()
        
    End Sub
    Public Function getIterator() As Iterator
        Dim kiter As KidIterator = New KidIterator(kidlist) ' create an iterator
        Return kiter ' and return it
    End Function
    Public Function getClubIterator(ByRef clb As String) As Iterator
        Dim kiter As KidClubIterator = New KidClubIterator(kidlist, clb) ' create an iterator
        Return kiter ' and return it
    End Function
End Class
