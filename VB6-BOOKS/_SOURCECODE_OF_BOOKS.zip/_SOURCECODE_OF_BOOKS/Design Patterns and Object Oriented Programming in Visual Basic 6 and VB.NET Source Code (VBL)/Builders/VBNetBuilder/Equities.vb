Imports System
Imports System.ComponentModel
Imports System.Collections

Public MustInherit Class Equities
    Protected ar As Arraylist
    '-------
    Public MustOverride Overrides Function toString() As String
    '-------
    Public Function getNames() As ArrayList
        Return ar
    End Function
    '-------
    Public Function count() As Integer
        Return ar.count
    End Function
    '-------
End Class
