Imports System
Imports System.ComponentModel
Imports System.Collections

Public Class Stocks
    Inherits Equities
    '-----
    Public Sub New()
        MyBase.New()
        ar = New ArrayList()
        ar.Add("Cisco")
        ar.Add("Coca Cola")
        ar.Add("GE")
        ar.Add("Harley Davidson")
        ar.Add("IBM")
        ar.Add("Microsoft")
    End Sub
    '-----    
    Public Overrides Function toString() As String
        Return "Stocks"
    End Function
End Class
