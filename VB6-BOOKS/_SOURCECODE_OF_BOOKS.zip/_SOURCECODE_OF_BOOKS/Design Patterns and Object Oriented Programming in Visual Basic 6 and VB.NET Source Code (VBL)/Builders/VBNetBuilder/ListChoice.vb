Imports System
Imports System.ComponentModel
Imports System.WinForms
Imports System.Collections
Imports System.Drawing

Public Class ListChoice
    Implements MultiChoice
    
    Private stocks As ArrayList
    Private pnl As Panel
    Private lst As ListBox
    '--------
    'create a panel containing a 
    'multiselectablen list box
    Public Sub New(ByVal stks As Equities)
        MyBase.New()
        stocks = stks.getNames 'get the names
        pnl = New Panel()
        'create the list box
        lst = New ListBox()
        lst.Location = New Point(16, 0)
        lst.Size = New Size(120, 160)
        lst.SelectionMode = _
              SelectionMode.MultiExtended
        lst.TabIndex = 0
        'add it into the panel
        pnl.Controls.Add(lst)
        'add the names into the list
        Dim i As Integer
        For i = 0 To stks.count - 1
            lst.items.add(stocks(i))
        Next i
    End Sub
    '--------
    'return selected items
    Public Function getSelected() As ArrayList _
             Implements MultiChoice.getSelected
        Dim i As Integer
        Dim item As String
        Dim arl As New ArrayList()
        
        'get items and put in ArrayLlist
        For i = 0 To lst.SelectedIndices.count - 1
            item = lst.Items( _
                lst.SelectedIndices(i)).toString
            arl.add(item)
        Next i
        Return arl    'return the ArrayList
    End Function
    '--------
    'clear all selected items
    Public Sub clear() Implements MultiChoice.clear
        lst.Items.clear()
    End Sub
    '--------
    'return the constructed panel
    Public Function getWindow() As Panel _
            Implements MultiChoice.getWindow
        Return pnl
    End Function
    
End Class
