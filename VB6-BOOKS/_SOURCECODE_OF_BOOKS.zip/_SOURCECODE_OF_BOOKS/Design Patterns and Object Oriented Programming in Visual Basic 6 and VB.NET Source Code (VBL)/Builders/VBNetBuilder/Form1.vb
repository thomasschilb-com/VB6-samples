Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private Pnl As Panel
    Private mchoice As MultiChoice
    Private eq As Equities
    Public Sub New()
        MyBase.New
        Form1 = Me
        InitializeComponent()
        Dim i As Integer
        Dim eq As Equities       
        lsEqTypes.Items.add(New Stocks())
        lsEqTypes.Items.add(New Bonds())
        lsEqTypes.Items.add(New Mutuals())
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    Private Sub setPanel()
        pnl.Location = New System.Drawing.Point(152, 24)
        pnl.Size = New System.Drawing.Size(128, 168)
        pnl.TabIndex = 1
        Me.Controls.Add(pnl)
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btShow As System.WinForms.Button
    
    Private WithEvents lsEqTypes As System.WinForms.ListBox
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btShow = New System.WinForms.Button()
        Me.lsEqTypes = New System.WinForms.ListBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        btShow.Location = New System.Drawing.Point(208, 176)
        btShow.Size = New System.Drawing.Size(64, 24)
        btShow.TabIndex = 1
        btShow.Text = "Show"
        
        lsEqTypes.Location = New System.Drawing.Point(24, 24)
        lsEqTypes.Size = New System.Drawing.Size(104, 134)
        lsEqTypes.TabIndex = 0
        
        Me.Text = "Simple builder"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 213)
        
        Me.Controls.Add(btShow)
        Me.Controls.Add(lsEqTypes)
    End Sub
    
#End Region
    
    Protected Sub btShow_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim amesg As ArrayList
        amesg = mchoice.getSelected
        Dim i As Integer
        Dim mesg As String = ""
        For i = 0 To amesg.Count - 1
            mesg += CType(amesg(i), String)
        Next
        MessageBox.Show(mesg, "Selected funds", Messagebox.OK)
    End Sub
    
    Protected Sub lsEqTypes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim i As Integer
        i = lsEqTypes.SelectedIndex
        
        'get the Equity from the list box
        eq = CType(lsEqTypes.items(i), Equities)
        
        'get the right Builder
        mchoice = StockFactory.getBuilder(eq)
        
        'remove the old panel
        Try
            Me.Controls.remove(pnl)
        Catch ex As NullReferenceException
        End Try
        'get the new one and add it to the window
        pnl = mchoice.getWindow
        setPanel()
        
    End Sub
    
End Class
