Imports System
Imports System.ComponentModel
Imports System.WinForms
Imports System.Collections

Interface MultiChoice
    'an interface to any group of components
    'that can return zero or more selected items
    'the names  are returned in an Arraylist   
    Function getSelected() As ArrayList
    Sub clear()             'clear all selected
    Function getWindow() As Panel
End Interface

