Imports System
Imports System.ComponentModel
Imports System.WinForms
Imports System.Collections
Imports System.Drawing

Public Class CheckChoice
    Implements MultiChoice
    
    Private stocks As ArrayList
    Private pnl As Panel
    Private boxes As ArrayList   
    '--------
    'create a Panel containing 
    '0 to 3 check boxes  
    Public Sub New(ByVal stks As Equities)
        MyBase.New()
        stocks = stks.getNames
        pnl = New Panel()
        boxes = New Arraylist() 'in an ArrayList
        Dim i As Integer
        For i = 0 To stocks.count - 1
            Dim Ck As New Checkbox()
            Ck.Location = _
               New System.Drawing.Point(8, 16 + i * 32)
            Ck.Text = stocks(i).toString
            Ck.Size = New Size(112, 24)
            Ck.TabIndex = 0
            Ck.TextAlign = _
               ContentAlignment.MiddleLeft
            boxes.add(ck)              'internal array
            pnl.Controls.add(ck)       'add into panel
        Next i
        
    End Sub
    '--------
    'clear all selected check boxes
    Public Sub clear() Implements MultiChoice.clear
        Dim i As Integer
        Dim ck As Checkbox
        For i = 0 To boxes.count - 1
            ck = CType(boxes(i), Checkbox)
            ck.Checked = False
        Next i
    End Sub
    '--------
    'gets list of selected names
    Public Function getSelected() As ArrayList _
             Implements MultiChoice.getSelected
        Dim ar As New ArrayList()
        Dim i As Integer
        Dim ck As Checkbox
        
        For i = 0 To Boxes.count - 1
            ck = CType(boxes(i), Checkbox)
            If ck.Checked Then
                ar.add(ck.Text)
            End If
        Next i
        Return ar
    End Function
    '--------
    'gets the Panel containing the check boxes
    Public Function getWindow() As Panel _
            Implements MultiChoice.getWindow
        Return pnl
    End Function
End Class
