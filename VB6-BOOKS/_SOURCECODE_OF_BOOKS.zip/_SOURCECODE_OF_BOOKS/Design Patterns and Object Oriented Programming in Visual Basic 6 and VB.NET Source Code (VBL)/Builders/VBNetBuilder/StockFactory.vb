
Imports System
Imports System.ComponentModel
Imports System.WinForms
Imports System.Collections

Public Class StockFactory   
    'This class has only one shared method
    Public Shared Function getBuilder(ByVal _
            stocks As Equities) _
             As MultiChoice
        
        Dim mult As MultiChoice
        
        If stocks.Count <= 3 Then
            'get check boxes 
            mult = New checkChoice(stocks)
        Else
            'get a listbox     
            mult = New listChoice(stocks)
        End If
        Return mult
    End Function
End Class
