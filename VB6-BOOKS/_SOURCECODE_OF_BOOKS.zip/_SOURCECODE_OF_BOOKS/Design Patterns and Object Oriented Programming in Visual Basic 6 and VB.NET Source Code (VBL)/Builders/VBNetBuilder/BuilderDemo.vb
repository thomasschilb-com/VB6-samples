Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

 Public Class BuilderDemo
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
        
        Private Pnl As Panel
        Private lsEqtypes As ListBox
        Private btShow as Button
        Private mchoice as MultiChoice
        Private eq as Equities
        '--------
        Public Sub New()
           MyBase.New
    
           InitializeComponent
           
           Dim i as integer
           Dim eq as Equities
           
           lsEqTypes.Items.add(new Stocks)
           lsEqTypes.Items.add(new Bonds)
           lsEqTypes.Items.add(new Mutuals)

        End Sub
        '--------
        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 
       '--------
        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New BuilderDemo())
        End Sub
       '--------
        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.lsEqtypes = New System.WinForms.ListBox
            Me.pnl = New System.WinForms.Panel
            Me.btShow = new System.WinForms.Button
            
            lsEqtypes.Location = New System.Drawing.Point(16, 24)
            lsEqtypes.Size = New System.Drawing.Size(120, 160)
            lsEqtypes.TabIndex = 0
            lsEqtypes.AddOnSelectedIndexChanged( _
                New System.EventHandler(AddressOf _ 
                Me.lsEqtypes_SelectedIndexChanged))
            
            btShow.Text = "Show"
            btShow.Location = New System.Drawing.Point(170, 200)
            btShow.Size = New System.Drawing.Size(50, 30)
            btShow.AddOnClick(New System.EventHandler(AddressOf Me.View_Click))

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Wealth Builder"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0

           
            Me.Controls.Add(lsEqtypes)
            Me.Controls.Add(btShow)
            setPanel()

        End Sub
'--------
'Click on line of listbox
Protected Sub lsEqtypes_SelectedIndexChanged( _
        ByVal sender As System.Object, _
        ByVal e As System.EventArgs) 
  Dim i as integer
  i =  lsEqTypes.SelectedIndex  
  
  'get the Equity from the list box
  eq = CType(lsEqTypes.items(i), Equities)
  
  'get the right Builder
  mchoice = StockFactory.getBuilder(eq)
  
  'remove the old pable
  Me.Controls.remove(pnl)
  
  'get the new one and add it to the window
  pnl = mchoice.getWindow
  setPanel()
  
End Sub
'--------
Protected Sub View_Click(ByVal sender As System.Object, _ 
        ByVal e As System.EventArgs) 
  Dim snames as String
  Dim i as Integer
  sNames = ""
  Dim ar as ArrayList
  ar = mchoice.getSelected
  for i = 0 to ar.count - 1
    sNames = sNames+ CType(ar(i), String) +", "
  next i
  MessageBox.Show(sNames)  
End Sub
'--------
Private function setPanel
 pnl.Location = New System.Drawing.Point(152, 24)
 pnl.Size = New System.Drawing.Size(128, 168)
 pnl.TabIndex = 1
 Me.Controls.Add(pnl)
End Function

End Class


