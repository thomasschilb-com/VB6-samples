
Imports System
Imports System.ComponentModel
Imports System.Collections

Public Class Bonds
    Inherits Equities
    
    Public Sub New()
        MyBase.New()
        ar = New ArrayList()
        ar.Add("CT GO 2005")
        ar.Add("NY GO 2012")
        ar.Add("GE Corp bonds")
    End Sub
    
    Public Overrides Function toString() As String
        Return "Bonds"
    End Function
    
End Class
