

Imports System
Imports System.ComponentModel
Imports System.Collections

Public Class Mutuals
    Inherits Equities
    
    Public Sub New()
        MyBase.New()
        ar = New ArrayList()
        ar.Add("Dreyfus Tax Smart")
        ar.Add("Fidelity Magellan")
        ar.Add("Strong Short Term")
        ar.Add("Vanguard Index 500")
        
    End Sub
    
    Public Overrides Function toString() As String
        Return "Mutual funds"
    End Function
    
End Class
