Option Strict Off
Option Explicit On
Namespace Project1
	Public  Class Form1
		Inherits System.WinForms.Form
		Private Shared  m_vb6FormDefInstance As Form1
		Public Shared  Property DefInstance() As Form1
			Get
				If m_vb6FormDefInstance Is Nothing Then
					m_vb6FormDefInstance = New Form1()
				End If
				DefInstance = m_vb6FormDefInstance
			End Get
			Set
				m_vb6FormDefInstance = Value
			End Set
		End Property
#Region " Windows Form Designer generated code "
		' Required by the Win Form Designer
		Private  components As System.ComponentModel.Container
		Public  ToolTip1 As System.WinForms.ToolTip
		Public  Tag1 As Microsoft.VisualBasic.Compatibility.VB6.Tag
		Private WithEvents  Form1 As Form1
		Public Sub New()
			MyBase.New()
			Me.Form1 = Me
			' This call is required by the Win Form Designer
			If m_vb6FormDefInstance Is Nothing Then
				m_vb6FormDefInstance = Me
			End If
			InitializeComponent()
		End Sub
		' Form overrides dispose to clean up the component list.
		Public Overrides Sub Dispose()
			MyBase.Dispose()
			components.Dispose()
		End Sub
		' The main entry point for the application
		Shared Sub Main()
			System.WinForms.Application.Run(New Form1())
		End Sub
		' NOTE: The following procedure is required by the Win Form Designer
		' It can be modified using the Win Form Designer.
		' Do not modify it using the code editor.

		Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Me.ToolTip1 = New System.WinForms.ToolTip(components)
			Me.Tag1 = New Microsoft.VisualBasic.Compatibility.VB6.Tag()
			ToolTip1.Active = True
			' @design ToolTip1.SetLocation(New System.Drawing.Point(7,7))
			' @design Tag1.SetLocation(New System.Drawing.Point(90,7))
			Me.ControlBox = True
			Me.Text = "Form1"
			Me.ClientSize = New System.Drawing.Size(312, 213)
			Me.Location = New System.Drawing.Point(4, 23)
			Me.StartPosition = System.WinForms.FormStartPosition.WindowsDefaultLocation
			Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.BorderStyle = System.WinForms.FormBorderStyle.Sizable
			Me.Enabled = True
			Me.KeyPreview = False
			Me.MaximizeBox = True
			Me.MinimizeBox = True
			Me.Cursor = System.Drawing.Cursors.Default
			Me.RightToLeft = System.WinForms.RightToLeft.No
			Me.ShowInTaskbar = True
			Me.HelpButton = False
			Me.WindowState = System.WinForms.FormWindowState.Normal
		End Sub
#End Region 
	End Class
End NameSpace