Public Class Employee
    Inherits Person
    
    Public Overrides Function getJob() As System.String
        Return "Worker"
    End Function
End Class
