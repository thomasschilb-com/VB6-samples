Option Strict Off
Option Explicit On

Public MustInherit Class Person
    
    'Class Person
    Private age As Short
    Protected personName As String
    '-----
    Public Sub init(ByRef nm As String)
        personName = nm
    End Sub
    '-----
    Public Function makeJob() As String
        makeJob = "hired"
    End Function
    '-----
    Private Sub splitNames()
        
    End Sub
    '-----
    Public Function getAge() As Short
        getAge = age
    End Function
    '-----
    Public MustOverride Function getJob() As String
    
End Class
