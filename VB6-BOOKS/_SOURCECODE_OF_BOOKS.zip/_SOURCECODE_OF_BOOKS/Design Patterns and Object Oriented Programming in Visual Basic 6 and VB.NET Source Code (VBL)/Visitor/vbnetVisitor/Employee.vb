Public Class Employee
    Dim sickDays As Integer, vacDays As Integer
    Dim salary As Single
    Dim name As String
    '-----
    Public Sub New(ByVal nm As String, ByVal sl As Single, ByVal vDays As Integer, ByVal sDays As Integer)
        name = nm
        salary = sl
        vacDays = vDays
        sickDays = sDays
    End Sub
    '-----
    Public Function getName() As String
        Return name
    End Function
    '-----
    Public Function getSalary() As Single
        Return salary
    End Function
    '-----
    Public Function getSickdays() As Integer
        Return sickDays
    End Function
    '-----
    Public Function getVacDays() As Integer
        Return vacDays
    End Function
    '-----
    Public Overridable Sub accept(ByVal v As Visitor)
        v.visit(Me)
    End Sub
End Class
