Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class Form1
    Inherits System.WinForms.Form
    Private empls(7) As employee
    Private empl As Employee
    Private bos As Boss
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        Dim i As Integer = 0
        
        empls(i) = New Employee("Susan Bear", 55000, 12, 1)
        i = i + 1
        empls(i) = New Employee("Adam Gehr", 150000, 9, 0)
        i = i + 1
        empls(i) = New Employee("Fred Harris", 50000, 15, 2)
        i = i + 1
        empls(i) = New Employee("David Oakley", 57000, 12, 2)
        i = i + 1
        empls(i) = New Employee("Larry Thomas", 100000, 20, 6)
        i = i + 1
        bos = New Boss("Leslie Susi", 175000, 16, 4)
        bos.setBonusdays(12)
        empls(i) = bos
        i = i + 1
        bos = New Boss("Laurence Byerly", 35000, 17, 6)
        bos.setBonusdays(17)
        empls(i) = bos
        
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents List1 As System.WinForms.ListBox
    Private WithEvents Compute As System.WinForms.Button
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Compute = New System.WinForms.Button()
        Me.List1 = New System.WinForms.ListBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Compute.Location = New System.Drawing.Point(96, 200)
        Compute.Size = New System.Drawing.Size(80, 32)
        Compute.TabIndex = 0
        Compute.Text = "Compute"
        
        List1.Location = New System.Drawing.Point(32, 24)
        List1.Size = New System.Drawing.Size(232, 147)
        List1.TabIndex = 1
        Me.Text = "Form1"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(List1)
        Me.Controls.Add(Compute)
    End Sub
    
#End Region
    
    Protected Sub Compute_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim i As Integer
        Dim vac As New VacationVisitor()
        Dim bvac As New bVacationVisitor()
        For i = 0 To empls.Length - 1
            empls(i).accept(vac)      'get the employee
            empls(i).accept(bvac)
        Next i
        List1.items.Add("Total vacation days=" + vac.getTotalDays.toString)
        List1.items.Add("Total boss vacation days=" + bvac.getTotalDays.tostring)
    End Sub
    
End Class
