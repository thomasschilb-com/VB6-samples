Public Class VacationVisitor
    Inherits Visitor
    Dim totalDays As Integer
    '-----
    Public Sub new()
        totalDays = 0
    End Sub
    '-----
    Public Function getTotalDays() As Integer
        getTotalDays = totalDays
    End Function
    '-----
    Public Overrides Sub visit(ByVal emp As Employee)
        totalDays = totalDays + emp.getVacDays
    End Sub
    Public Overrides Sub visit(ByVal bos As Boss)
        totalDays = totalDays + bos.getVacDays
    End Sub
End Class
