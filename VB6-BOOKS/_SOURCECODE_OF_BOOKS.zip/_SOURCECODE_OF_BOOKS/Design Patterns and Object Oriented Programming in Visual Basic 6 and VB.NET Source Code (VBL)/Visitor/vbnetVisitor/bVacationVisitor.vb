Public Class bVacationVisitor
    Inherits Visitor
    Private totalDays As Integer
    '-----
    Public Overrides Sub visit(ByVal emp As Employee)
        totalDays += emp.getVacDays
        If TypeOf emp Is Manager Then
            Dim mgr As Manager = CType(emp, Manager)
            totaldays += mgr.getBonusDays
        End If
    End Sub
    '-----
    Public Overrides Sub visit(ByVal bos As Boss)
        totalDays += bos.getVacDays
        totalDays += bos.getBonusDays
    End Sub
    '-----
    Public Function getTotalDays() As Integer
        Return totalDays
    End Function
End Class
