Public Class Boss
    Inherits Employee
    Private bonusDays As Integer
    '-----
    Public Sub New(ByVal nm As String, ByVal sl As Single, _
         ByVal vDays As Integer, ByVal sDays As Integer)
        MyBase.New(nm, sl, vdays, sdays)
    End Sub
    '-----
    Public Sub setBonusDays(ByVal bdays As Integer)
        bonusdays = bdays
    End Sub
    '-----
    Public Function getBonusDays() As Integer
        Return bonusDays
    End Function
    '-----
    Public Overrides Sub accept(ByVal v As Visitor)
        v.visit(Me)
    End Sub
End Class
