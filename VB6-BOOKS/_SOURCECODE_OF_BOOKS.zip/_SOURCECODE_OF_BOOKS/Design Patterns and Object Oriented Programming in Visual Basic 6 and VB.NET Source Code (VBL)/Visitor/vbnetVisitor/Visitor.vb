Public MustInherit Class Visitor
    Public MustOverride Sub visit(ByVal emp As Employee)
    Public MustOverride Sub visit(ByVal bos As Boss)
End Class
        