Imports System.Drawing
Public Class StdTriangle
    Inherits Triangle
    '-----
    Public Sub new(ByVal a As Point, _
            ByVal b As Point, ByVal c As Point)
        MyBase.new(a, b, c)
    End Sub
    '-----
    Public Overrides Function draw2ndLine( _
        ByVal g As Graphics, ByVal a As point, _
        ByVal b As Point) As Point
        g.DrawLine(bpen, a.X, a.Y, b.X, b.Y)
        Return b
    End Function
End Class
