Imports System.Drawing
Imports System.Math
Public Class IsocelesTriangle
    Inherits Triangle
    Private newc As Point
    Private newcx, newcy As Integer
    '-----    
    Public Sub New(ByVal a As Point, ByVal b As Point, ByVal c As Point)
        MyBase.New(a, b, c)
        Dim dx1, dy1, dx2, dy2, side1, side2 As Single
        Dim slope, intercept As Single
        Dim incr As Integer
        dx1 = b.x - a.x
        dy1 = b.y - a.y
        dx2 = c.x - b.x
        dy2 = c.y - b.y
        
        side1 = calcSide(dx1, dy1)
        side2 = calcSide(dx2, dy2)
        
        If (side2 < side1) Then
            incr = -1
        Else
            incr = 1
        End If
        slope = dy2 / dx2
        intercept = c.y - slope * c.X
        
        'move point c so that this is an isoceles triangle
        newcx = c.X
        newcy = c.Y
        While (abs(side1 - side2) > 1)
            newcx = newcx + incr    'iterate a pixel at a time until close
            newcy = (slope * newcx + intercept).ToInt16
            dx2 = newcx - b.x
            dy2 = newcy - b.y
            side2 = calcSide(dx2, dy2)
        End While
        newc = New Point(newcx, newcy)
    End Sub
    '------
    Private Function calcSide(ByVal dx As Single, ByVal dy As Single) As Single
        Return Sqrt(dx * dx + dy * dy).ToSingle
    End Function
    '-----
    'draw 2nd line using new saved point
    Public Overrides Function draw2ndLine( _
        ByVal g As Graphics, ByVal b As Point, _
            ByVal c As Point) As Point
        g.DrawLine(bpen, b.X, b.Y, newc.X, newc.Y)
        Return newc
    End Function
End Class
