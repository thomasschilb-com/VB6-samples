Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private triangles As ArrayList
    Public Sub New()
        MyBase.New
        Form1 = Me
        InitializeComponent()
        'Create a list of triangles to draw
        triangles = New ArrayList()
        Dim t1 As New StdTriangle( _
            New Point(10, 10), New Point(150, 50), _
             New point(100, 75))
        Dim t2 As New IsocelesTriangle( _
            New Point(150, 100), New Point(240, 40), _
             New Point(175, 150))
        triangles.Add(t1)
        triangles.Add(t2)       
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pic = New System.WinForms.PictureBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Pic.Location = New System.Drawing.Point(16, 32)
        Pic.Size = New System.Drawing.Size(264, 192)
        Pic.TabIndex = 0
        Pic.TabStop = False
        
        Me.Text = "TriangleForm"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(Pic)
    End Sub
    
#End Region

    Public Sub Pic_Paint(ByVal sender As Object, _
        ByVal e As System.WinForms.PaintEventArgs) _
            Handles Pic.Paint
        Dim i As Integer
        Dim g As Graphics = e.Graphics
        For i = 0 To triangles.Count - 1
            Dim t As Triangle = CType(triangles(i), triangle)
            t.draw(g)
        Next
    End Sub
End Class
