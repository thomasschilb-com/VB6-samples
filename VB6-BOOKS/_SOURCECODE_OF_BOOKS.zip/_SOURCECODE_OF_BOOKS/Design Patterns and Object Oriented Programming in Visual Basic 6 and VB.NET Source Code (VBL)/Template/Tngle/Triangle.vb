Imports System.Drawing
Public MustInherit Class Triangle
    Private p1, p2, p3 As Point
    Protected bPen As Pen
    '-----
    Public Sub New(ByVal a As Point, ByVal b As Point, _
             ByVal c As Point)
        p1 = a
        p2 = b
        p3 = c
        bPen = New Pen(Color.Black)
    End Sub
    '-----
    'draw the complete triangle
    Public Sub draw(ByVal g As Graphics)
        drawLine(g, p1, p2)
        Dim c As Point = draw2ndLine(g, p2, p3)
        closeTriangle(g, c)
    End Sub
    '-----
    'draw one line
    Public Sub drawLine(ByVal g As Graphics, ByVal a As Point, _
            ByRef b As Point)
        g.drawLine(bpen, a.x, a.y, b.x, b.y)
    End Sub
    '-----
    'Hook method you must override in derived classes
    Public MustOverride Function draw2ndLine(ByVal g As Graphics, _
        ByVal a As Point, ByVal b As Point) As Point
    '-----
    'close by drawing back to beginning
    Public Sub closeTriangle(ByVal g As Graphics, ByVal c As Point)
        g.DrawLine(bpen, c.X, c.Y, p1.x, p1.y)
    End Sub
End Class
