Public Class FillState
    Inherits State
    Private med As Mediator
    Public Sub New(ByVal md As Mediator)
        med = md
    End Sub
    Public Overrides Sub mouseDown(ByVal x As System.Integer, ByVal y As System.Integer)
        Dim i As Integer
        Dim d As Drawing
        'Fill drawing if you click inside one
        i = med.findDrawing(x, y)
        If i >= 0 Then
            d = med.getDrawing(i)
            d.setFill(True)  'fill drawing
        End If
    End Sub
    
    Public Overrides Sub selectOne(ByVal d As VBNetState.Drawing)
        'Fill drawing if selected
        d.setFill(True)  'fill that drawing
    End Sub
End Class
