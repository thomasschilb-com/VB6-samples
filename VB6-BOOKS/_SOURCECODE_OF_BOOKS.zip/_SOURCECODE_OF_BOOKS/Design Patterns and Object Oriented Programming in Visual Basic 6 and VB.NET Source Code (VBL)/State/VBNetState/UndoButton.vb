Public Class UndoButton
    Inherits CmdToolbarButton
    Public Sub New(ByVal md As Mediator)
        MyBase.New("Undo", md)
    End Sub
    Public Overrides Sub Execute()
        med.undo()
    End Sub
End Class
