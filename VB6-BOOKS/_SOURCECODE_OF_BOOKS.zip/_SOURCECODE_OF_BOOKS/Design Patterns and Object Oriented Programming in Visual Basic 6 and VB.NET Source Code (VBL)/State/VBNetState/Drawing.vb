Imports system.Drawing
Public Interface Drawing
    Sub setSelected(ByVal b As Boolean)    
    Sub draw(ByVal g As Graphics)
    Sub move(ByVal xpt As Integer, ByVal ypt As Integer)
    Function contains(ByVal x As Integer, _
             ByVal y As Integer) As Boolean
    Sub setFill(ByVal b As Boolean)
    Property rects() As vbpatterns.Rectangle
End Interface
