Imports System.WinForms
'The rectangle toolbar button
Public Class RectButton
    Inherits CmdToolbarButton
    '-----
    Public Sub New(ByVal md As Mediator)
        MyBase.New("Rectangle", md)
        Me.Style = ToolBarButtonStyle.ToggleButton
        med.registerRectButton(Me)
    End Sub
    '-----
    Public Overrides Sub Execute()
        med.startrectangle()
    End Sub
End Class
