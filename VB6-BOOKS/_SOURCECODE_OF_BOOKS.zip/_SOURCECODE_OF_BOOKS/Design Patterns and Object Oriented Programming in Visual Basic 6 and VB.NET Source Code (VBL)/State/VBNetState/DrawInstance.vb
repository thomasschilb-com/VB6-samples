Public Class DrawInstance
    Implements Memento
    Private intg As Integer
    Private med As Mediator
    'treats a drawing index as an object
    Public Sub restore() Implements VBNetState.Memento.restore
        med.removeDrawing(intg)
    End Sub
    
    Public Sub New(ByVal a As Integer, ByVal md As Mediator)
        intg = a       'remember the index
        med = md
    End Sub
    ReadOnly Property integ() As Integer
        Get
            Return intg
        End Get
    End Property
    
    
End Class
