Public Class DrawMemento
    Implements Memento
    Private x As Integer, y As Integer
    Private w As Integer, h As Integer
    Private rect As vbpatterns.Rectangle
    Private visDraw As Drawing
    '-----
    Public Sub restore() Implements Memento.restore
        'restore the state of a drawing object
        rect.x = x
        rect.y = y
        rect.h = h
        rect.w = w
        visDraw.rects = rect
    End Sub
    '-----
    Public Sub New(ByRef d As Drawing)
        'save the state of a visual rectangle
        visDraw = d
        rect = visDraw.rects
        x = rect.x
        y = rect.y   
        w = rect.w
        h = rect.h
    End Sub
    
End Class
