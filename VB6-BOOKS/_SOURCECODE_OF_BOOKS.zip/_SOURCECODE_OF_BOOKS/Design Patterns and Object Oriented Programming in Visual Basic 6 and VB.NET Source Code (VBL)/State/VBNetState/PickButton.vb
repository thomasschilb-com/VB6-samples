Imports System.WinForms
Public Class PickButton
    Inherits CmdToolbarButton
    Public Sub new(ByVal md As Mediator)
        MyBase.New("Select", md)
        Me.Style = ToolBarButtonStyle.ToggleButton
        med.registerArrowButton(Me)
    End Sub
    Public Overrides Sub Execute()
        med.startArrow()
    End Sub
End Class
