Imports System.Drawing
Public Class VisRectangle
    Implements Drawing
    Protected x, y, w, h As Integer
    Private rect As vbpatterns.Rectangle
    Protected selected As Boolean
    Protected filled As Boolean
    Protected bBrush As SolidBrush
    Protected rBrush As SolidBrush
    Protected bPen As Pen
    Private fillColor As Color
    '-----
    Public Sub New(ByVal xp As Integer, ByVal yp As Integer)
        x = xp     'save coordinates
        y = yp
        w = 40     'default size
        h = 30
        fillColor = Color.Red
        bbrush = New SolidBrush(color.Black)
        rbrush = New SolidBrush(fillcolor)
        bPen = New Pen(color.Black)
        saveAsRect() 'keep in rectangle class as well
    End Sub
    '------
    Protected Sub saveAsRect()
        rect = New vbpatterns.Rectangle(x, y, w, h)
    End Sub
    '-----
    Public Function contains(ByVal xp As Integer, _
        ByVal yp As Integer) As Boolean Implements Drawing.contains
        Return rect.contains(xp, yp)
    End Function
    '-----
    Public Overridable Sub draw(ByVal g As Graphics) _
        Implements Drawing.draw
        'draw rectangle
        If filled Then
            g.FillRectangle(rbrush, x, y, w, h)
        End If
        g.DrawRectangle(bpen, x, y, w, h)
        If selected Then   'draw handles
            drawHandles(g)
        End If
    End Sub
    '-----
    Protected Sub drawHandles(ByVal g As Graphics)
        g.fillrectangle(bBrush, (x + w \ 2), (y - 2), 4, 4)
        g.FillRectangle(bbrush, x - 2, y + h \ 2, 4, 4)
        g.FillRectangle(bbrush, x + (w \ 2), y + h - 2, 4, 4)
        g.FillRectangle(bbrush, x + (w - 2), y + (h \ 2), 4, 4)
    End Sub
    '-----
    Public Overridable Sub move(ByVal xpt As System.Integer, _
         ByVal ypt As System.Integer) _
            Implements VBNetState.Drawing.move
        x = xpt
        y = ypt
        saveAsRect()
    End Sub
    '-----
    Friend Property rects() As vbPatterns.Rectangle _
        Implements Drawing.rects
        Set
            x = value.x
            y = value.y
            w = value.w
            h = value.h
            saveAsRect()
        End Set
        Get
            Return rect
        End Get
    End Property
    '-----
    Public Sub setFill(ByVal b As Boolean) _
        Implements Drawing.setFill
        filled = b
    End Sub
    '-----
    Public Sub setSelected(ByVal b As Boolean) _
        Implements VBNetState.Drawing.setSelected
        selected = b
    End Sub
End Class
