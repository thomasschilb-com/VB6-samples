Public Class FillMemento
    Implements Memento
    Private index As Integer
    Private med As Mediator
    Public Sub New(ByVal dindex As Integer, ByVal md As Mediator)
        index = dindex
        med = md
    End Sub
    Public Sub restore() Implements VBNetState.Memento.restore
        Dim d As Drawing
        d = med.getDrawing(index)
        d.setFill(False)
    End Sub
End Class
