Imports System.WinForms
Public Class FillButton
    Inherits CmdToolbarButton
    Public Sub New(ByVal md As Mediator)
        MyBase.new("Fill", md)
        Me.Style = ToolBarButtonStyle.ToggleButton
        med.registerFillButton(Me)
    End Sub
    Public Overrides Sub Execute()
        med.startFill()
    End Sub
    
End Class
