Public Class CircleState
    Inherits State
    
    Private med As Mediator
    Public Sub New(ByVal md As Mediator)
        med = md
    End Sub
    Public Overrides Sub mouseDown(ByVal x As System.Integer, ByVal y As System.Integer)
        Dim c As New visCircle(x, y)
        med.addDrawing(c)
    End Sub
    
End Class
