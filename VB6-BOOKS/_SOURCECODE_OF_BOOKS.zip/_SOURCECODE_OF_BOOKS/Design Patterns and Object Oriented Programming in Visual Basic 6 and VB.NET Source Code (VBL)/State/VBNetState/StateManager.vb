Public Class StateManager
    
    Private currentState As State
    Private rState As RectState
    Private aState As ArrowState
    Private cState As CircleState
    Private fState As FillState
    '-----
    Public Sub New(ByVal med As Mediator)
        'create an instance of each state
        rState = New RectState(med)
        cState = New CircleState(med)
        aState = New ArrowState(med)
        fState = New FillState(med)
        'and initialize then
        'set default state
        currentState = aState
    End Sub
    '-----
    'These methods are called when the tool buttons
    'are selected
    Public Sub setRect()
        currentState = rState
    End Sub
    '-----
    Public Sub setCircle()
        currentState = cState
    End Sub
    '-----
    Public Sub setFill()
        currentState = fState
    End Sub
    '-----
    Public Sub setArrow()
        currentState = aState
    End Sub
    '-----
    Public Sub mouseDown(ByVal x As Integer, ByVal y As Integer)
        currentState.mouseDown(x, y)
    End Sub
    '-----
    Public Sub mouseUp(ByVal x As Integer, ByVal y As Integer)
        currentState.mouseUp(x, y)
    End Sub
    '-----
    Public Sub mouseDrag(ByVal x As Integer, ByVal y As Integer)
        currentState.mouseDrag(x, y)
    End Sub
    '-----
    Public Sub selectOne(ByVal d As Drawing)
        currentState.selectOne(d)
    End Sub
    
    
    
End Class
