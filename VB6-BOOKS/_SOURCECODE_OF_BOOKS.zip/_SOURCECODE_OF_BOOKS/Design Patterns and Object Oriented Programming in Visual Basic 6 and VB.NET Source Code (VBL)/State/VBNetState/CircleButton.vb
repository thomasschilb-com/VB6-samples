Imports System.WinForms

Public Class CircleButton
    Inherits CmdToolbarButton
    Public Sub new(ByVal md As Mediator)
        MyBase.New("Circle", md)
        Me.Style = ToolBarButtonStyle.ToggleButton
        med.registerCircleButton(Me)
    End Sub
    Public Overrides Sub Execute()
        med.startCircle()
    End Sub
End Class
