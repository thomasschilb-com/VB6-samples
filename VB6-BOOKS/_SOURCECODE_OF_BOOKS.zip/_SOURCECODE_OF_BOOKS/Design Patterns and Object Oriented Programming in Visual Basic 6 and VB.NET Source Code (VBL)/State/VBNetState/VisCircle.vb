Imports System.Drawing
Public Class VisCircle
    Inherits VisRectangle
    Private r As Integer
    '-----    
    Public Sub New(ByVal xp As Integer, ByVal yp As Integer)
        MyBase.New(xp, yp)
        r = 15
        w = 30
        h = 30
        saveAsRect()
    End Sub
    '-----
    Public Overrides Sub draw(ByVal g As Graphics)
        If filled Then
            g.FillEllipse(rbrush, x, y, w, h)
        End If
        g.DrawEllipse(bpen, x, y, w, h)
        If selected Then
            drawHandles(g)
        End If
    End Sub    
End Class
