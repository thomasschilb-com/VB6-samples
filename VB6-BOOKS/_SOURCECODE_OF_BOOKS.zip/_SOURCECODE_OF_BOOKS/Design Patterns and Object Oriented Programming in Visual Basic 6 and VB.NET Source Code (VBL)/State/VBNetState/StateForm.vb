Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class StateForm
    Inherits System.WinForms.Form
    Private CircButton As CircleButton
    Private RctButton As RectButton
    Private ArowButton As PickButton
    Private flbutton As FillButton
    Private undoB As UndoButton
    Private clrb As ClearButton
    Private med As Mediator
    Public Sub New()
        MyBase.New()
        InitializeComponent()
        'create a Mediator
        med = New Mediator(pic)
        'create the buttons
        RctButton = New RectButton(med)
        ArowButton = New PickButton(med)
        circbutton = New CircleButton(med)
        flButton = New FillButton(med)
        undob = New UndoButton(med)
        clrb = New ClearButton(med)
        'add the buttons into the toolbar
        Tbar.Buttons.Add(ArowButton)
        Tbar.Buttons.Add(RctButton)
        tbar.Buttons.Add(circbutton)
        Tbar.Buttons.Add(flbutton)
        'include a separator
        Dim sep As New ToolBarButton()
        sep.Style = ToolBarButtonStyle.Separator
        tbar.Buttons.Add(sep)
        Tbar.Buttons.Add(undoB)
        Tbar.Buttons.Add(clrb)
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    Private WithEvents Tbar As System.WinForms.ToolBar
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Tbar = New System.WinForms.ToolBar()
        Me.Pic = New System.WinForms.PictureBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Tbar.Size = New System.Drawing.Size(384, 22)
        Tbar.DropDownArrows = True
        Tbar.TabIndex = 0
        Tbar.ShowToolTips = True
        
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Pic.Location = New System.Drawing.Point(16, 40)
        Pic.Size = New System.Drawing.Size(352, 256)
        Pic.TabIndex = 1
        Pic.TabStop = False
        
        Me.Text = "State Drawing"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 309)
        
        Me.Controls.Add(Pic)
        Me.Controls.Add(Tbar)
    End Sub
    
#End Region
    'process button commands
    Protected Sub Tbar_ButtonClick(ByVal sender As Object, _
            ByVal e As ToolBarButtonClickEventArgs)
        Dim cmd As Command
        Dim tbutn As ToolBarButton = e.button
        cmd = CType(tbutn, Command) 'get the command object
        cmd.Execute()           'and execute it
    End Sub
    
    Public Sub Pic_MouseDown(ByVal sender As Object, ByVal e As System.WinForms.MouseEventArgs) Handles Pic.MouseDown
        med.mouseDown(e.X, e.Y)
    End Sub
    Public Sub Pic_MouseMove(ByVal sender As Object, ByVal e As System.WinForms.MouseEventArgs) Handles Pic.MouseMove
        If e.Button <> MouseButtons.None Then
            med.mouseDrag(e.X, e.Y)
        End If
    End Sub
    Public Sub Pic_MouseUp(ByVal sender As Object, ByVal e As System.WinForms.MouseEventArgs) Handles Pic.MouseUp
        med.mouseUp(e.x, e.y)
    End Sub
    Public Sub Pic_Paint(ByVal sender As Object, ByVal e As System.WinForms.PaintEventArgs) Handles Pic.Paint
        med.reDraw(e.Graphics)
    End Sub
End Class
