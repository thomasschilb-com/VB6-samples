Public Interface Memento
    Sub restore()
End Interface
