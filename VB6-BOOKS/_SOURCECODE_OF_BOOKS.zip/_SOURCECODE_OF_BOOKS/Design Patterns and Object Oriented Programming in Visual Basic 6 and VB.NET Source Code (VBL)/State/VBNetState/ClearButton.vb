Public Class ClearButton
    Inherits CmdToolbarButton
    Public Sub New(ByVal md As Mediator)
        MyBase.New("Clear", md)
    End Sub
    Public Overrides Sub Execute()
        med.clear()
    End Sub
End Class
