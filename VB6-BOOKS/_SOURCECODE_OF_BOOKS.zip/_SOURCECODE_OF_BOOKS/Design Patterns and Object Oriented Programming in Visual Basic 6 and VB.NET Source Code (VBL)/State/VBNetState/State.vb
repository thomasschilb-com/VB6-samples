Public Class State
    Public Overridable Sub mouseDown(ByVal x As Integer, ByVal y As Integer)    
    End Sub
    '-----
    Public Overridable Sub mouseUp(ByVal x As Integer, ByVal y As Integer)
    End Sub
    '-----
    Public Overridable Sub mouseDrag(ByVal x As Integer, ByVal y As Integer)
    End Sub
    '-----
    Public Overridable Sub selectOne(ByVal d As Drawing)
    End Sub
End Class
        