Public Class RectState
    Inherits State
    Private med As Mediator
    Public Sub New(ByVal md As Mediator)
        med = md
    End Sub
    '-----
    Public Overrides Sub mouseDown(ByVal x As Integer, _
        ByVal y As Integer)
        Dim vr As New VisRectangle(x, y)
        med.addDrawing(vr)
    End Sub
End Class
