Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

'A toolbar button class that also
'has a command interface
Public Class CmdToolbarButton
    Inherits System.WinForms.ToolBarButton
    Implements Command
    Protected med As Mediator
    Protected selected As Boolean
    Public Sub New(ByVal caption As String, ByVal md As mediator)
        MyBase.New()
        Me.Text = caption
        med = md
        InitializeComponent()
    End Sub
    
    'CmdToolbarButton overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    
    Dim WithEvents CmdToolbarButton As System.WinForms.UserControl
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub
    
#End Region
    Public Overridable Sub setSelected(ByRef b As Boolean)
        selected = b
    End Sub
    Public Overridable Sub Execute() _
        Implements Command.Execute
    End Sub
End Class
