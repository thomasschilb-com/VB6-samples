Imports system.WinForms
Imports System.Data.ADO
Imports System.Data

Public Class Indexer
    Private db As DBase
    Private tableName As String
    Private dtable As DataTable
    'creates data tables - none of this works in ADO in VB.Net so far
    Public Sub new(ByVal datab As DBase)
        db = datab
    End Sub
    Public Sub makeTable(ByVal name As String)
        'starts creation of table   
        
    End Sub
    Public Sub openTable(ByVal name As String)
        tableName = name
    End Sub
    Public Sub addTable()
    
    End Sub
    Public Sub createKey(ByVal keyName As String)
    End Sub
    'creates text column
    Public Overloads Sub createColumn(ByVal colName As String, ByVal length As Integer)
    End Sub
    'creates single precision table columne
    Public Overloads Sub createColumn(ByVal colName As String)
        
    End Sub
    Public Sub makeIndex(ByVal name As String, ByVal primary As Boolean)
        
    End Sub
    
End Class
