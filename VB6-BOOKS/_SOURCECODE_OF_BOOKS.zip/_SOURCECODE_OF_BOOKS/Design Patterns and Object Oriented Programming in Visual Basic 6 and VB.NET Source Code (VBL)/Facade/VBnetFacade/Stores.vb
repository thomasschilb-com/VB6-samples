Public Class Stores
    Inherits DBTable
    
    Public Sub New(ByVal datab As DBase)
        MyBase.New(datab, "Stores")
    End Sub
    Public Overloads Sub makeTable()
        MyBase.makeTable("StoreName")
    End Sub
End Class
