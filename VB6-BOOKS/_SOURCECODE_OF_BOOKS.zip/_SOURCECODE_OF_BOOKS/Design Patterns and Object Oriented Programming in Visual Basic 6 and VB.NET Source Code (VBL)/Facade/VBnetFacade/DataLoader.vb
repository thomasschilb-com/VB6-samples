
Public Class DataLoader
    Private vfile As vbFile
    Private stor As Stores
    Private fods As Foods
    Private price As Prices
    Private db As DBase
    '--------------
    Public Sub new(ByVal datab As DBase)
        db = datab
        stor = New Stores(db)   'create class instances
        fods = New Foods(db)
        price = New Prices(db)
    End Sub
    '--------------
    Public Sub load(ByVal datafile As String)
        Dim sline As String
        Dim storekey As Long, foodkey As Long
        Dim tok As StringTokenizer
        
        'delete current table contents
        stor.delete()
        fods.delete()
        price.delete()
        'now read in new ones
        vfile = New vbFile(datafile)
        vfile.OpenForRead()
        sline = vfile.readLine
        While (sline <> "")
            tok = New StringTokenizer(sline, ",")
            stor.addTableValue(tok.nextToken)   'store name
            fods.addTableValue(tok.nextToken)   'food name
            sline = vfile.readLine
        End While
        vfile.closeFile()
        'construct store and food tables
        stor.makeTable("StoreName")
        fods.makeTable("FoodName")
        vfile.OpenForRead()
        sline = vfile.readLine
        While (sline <> "")
            'get the gets and add to storefoodprice objects
            tok = New StringTokenizer(sline, ",")
            storekey = stor.getKey(tok.nextToken, "Storekey")
            foodkey = fods.getKey(tok.nextToken, "Foodkey")
            price.addRow(storekey, foodkey, tok.nextToken.ToSingle)
            sline = vfile.readLine
        End While
        'add all to price table
        price.makeTable()
        vfile.closeFile()
    End Sub
End Class
