Imports System.Collections
Imports System.Data
Imports System.Data.ADO
Imports System.WinForms
Public Class DBTable
    Private names As Hashtable
    Protected db As DBase
    Protected tableName As String
    Private index As Integer
    Private dtable As DataTable
    Private filled As Boolean
    Private columnName As String
    Private rowIndex As Integer
    Private opened As Boolean
    Dim adc As ADOConnection
    Dim cmd As adocommand
    Dim dset As DataSet
    Dim row As DataRow
    
    Public Sub New(ByVal datab As DBase, ByVal tname As String)
        names = New Hashtable()
        db = datab
        tablename = tname
        index = 1
        filled = False
        opened = False
    End Sub
    '-------
    Public Sub createTable()
        'not yet available in ADO
    End Sub
    '-------
    Public Function hasMoreElements() As Boolean
        If opened Then
            Return (rowindex < dtable.Rows.Count)
        else
            Return False
        End If
    End Function
    '-------
    Public Function getKey(ByVal nm As String, ByVal keyname As String) As Long
        Dim i, key As Integer
        Dim dtable As DataTable
        Dim row As DataRow
        If Not filled Then
            Return CType(names.Item(nm), Integer)
        Else
            Dim query As String
            query = "select * from " + tablename + " where " + columnname + "='" + nm + "'"
            dtable = db.openQuery(query)
            row = dtable.Rows(0)
            key = row(keyname).ToString.ToInt32
            Return key
        End If
    End Function
    '-------
    Public Function getValue(ByVal columnName As String) As String
        'returns the next name in the table
        'assuems that openTable has already been called
        If opened Then
            Dim row As DataRow
            row = dtable.rows(rowindex)
            rowindex = rowindex + 1
            Return row(columnName).ToString
        Else
            Return ""
        End If
    End Function
    '-------
    Public Sub openTable()
        dtable = db.openTable(tablename)
        rowindex = 0
        opened = True
    End Sub
    Public Overridable Sub addTableValue(ByVal nm As String)
        'accumulates names in hash table
        Try
            names.Add(nm, index)
            index = index + 1
        Catch e As ArgumentException
            'do not allow duplicate names to be added
        End Try
    End Sub
    '-------
    Public Overridable Sub makeTable(ByVal colName As String)
        'stores current hash table values in data table
        dset = New DataSet(tablename)   'create the data set
        columnName = colname
        Dim name As String
        dtable = New DataTable(tablename)   'and a datatable
        dset.Tables.Add(dtable)             'add to collection
        adc = db.getConnection
        adc.Open()                      'open the connection
        Dim adcmd As New ADODataSetCommand()
        'open the table
        adcmd.SelectCommand = _
            New ADOCommand("Select * from " + tablename, adc)
        adcmd.TableMappings.Add("Table", tablename)
        'loac curren data into the local table copy
        adcmd.FillDataSet(dset, tablename)
        'get the Enumerator from ther Hashtable
        Dim ienum As IEnumerator = names.Keys.GetEnumerator
        'move through the table, adding the names to new rows
        While ienum.MoveNext
            name = CType(ienum.Current, String)
            row = dtable.NewRow     'get new rows
            row(colname) = name
            dtable.Rows.Add(row)    'add into table
        End While
        'Now update the database with this table
        Try
            adcmd.Update(dset)
            adc.Close()
            filled = True
        Catch e As Exception
            Messagebox.show(e.Message)
        End Try
    End Sub
    '------
    Public Sub delete()
        'deletes entire table
        adc = db.getConnection
        adc.Open()
        Dim adcmd As New ADOCommand("Delete * from " + tablename, adc)
        Try
            adcmd.ExecuteNonQuery()
            adc.Close()
        Catch e As Exception
            Messagebox.show(e.Message)
        End Try
    End Sub
End Class
