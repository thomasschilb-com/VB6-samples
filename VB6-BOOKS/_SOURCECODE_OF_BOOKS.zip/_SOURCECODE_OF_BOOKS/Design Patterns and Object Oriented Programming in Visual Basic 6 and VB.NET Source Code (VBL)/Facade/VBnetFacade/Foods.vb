Public Class Foods
    Inherits DBTable
    '-------
    Public Sub New(ByVal datab As DBase)
        MyBase.New(datab, "Foods")
    End Sub
    '-------
    Public Overloads Sub makeTable()
        MyBase.makeTable("FoodName")
    End Sub
    '-------
    Public Overloads Function getValue() As String
        Return MyBase.getValue("FoodName")
    End Function
End Class
