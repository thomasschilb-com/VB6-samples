Public Class StoreFoodPrice
    Private storeKey, foodKey As Long
    Private foodPrice As Single
    Public Sub new(ByVal storeky As Long, ByVal foodky As Long, ByVal fprice As Single)
        storekey = storeky
        foodkey = foodky
        foodprice = fprice
    End Sub
    Public Function getStore() As Long
        Return storekey
    End Function
    Public Function getFood() As Long
        Return foodKey
    End Function
    Public Function getPrice() As Single
        Return foodprice
    End Function
End Class
