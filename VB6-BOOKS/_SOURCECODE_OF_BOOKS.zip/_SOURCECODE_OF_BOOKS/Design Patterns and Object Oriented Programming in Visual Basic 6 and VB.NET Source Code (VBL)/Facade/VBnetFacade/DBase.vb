Imports System.WinForms
Imports System.Data.ADO
Imports System.Data
Public Class DBase
    Private adc As ADOConnection
    '-----    
    Public Overloads Sub New(ByVal connect As String)
        Adc = New ADOConnection(connect)
    End Sub
    Public Overloads Sub New(ByVal dbName As String, ByVal connectionType As String)
        Dim connection As String
        connectiontype = connectiontype.ToLower
        Select Case connectionType
            Case "access"
                connection = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dbname
            Case "sqlserver"
                connection = "Persist Security Info = False;" & _
                "Initial Catalog =" + dbname + ";" & _
                "Data Source = myDataServer;User ID = myName;" & _
                "password="
                
            Case Else
                connection = dbname
        End Select
        Adc = New ADOConnection(connection)
    End Sub
    '-----
    Public Overloads Sub New(ByVal dbname As String, ByVal userid As String, _
        ByVal servername As String, ByVal password As String, _
        ByVal connectionType As String)
        Dim connection As String
        connectiontype = connectiontype.ToLower
        Select Case connectionType
            Case "sqlserver"
                connection = "Persist Security Info = False;" & _
                "Initial Catalog =" + dbname + ";" & _
                "Data Source =" & servername & ";" & _
                "User ID =" & userid & ";" & _
                "password=" & password
            Case Else
                connection = dbname
        End Select
        Adc = New ADOConnection(connection)
    End Sub
    '-------
    Public Function makeTable(ByVal nm As String) As Indexer
        'none of this works so far in ADO
    End Function
    '-------
    Public Function openTable(ByVal tbName As String) As DataTable
        'create the dataset command connection
        Dim dsCmd As New ADODataSetCommand()
        'put the query into the dataset command
        Dim query As String = "Select * from " & tbname
        dsCmd.SelectCommand = New ADOCommand(query, adc)
        'create the destination dataset
        Dim dset As New DataSet()
        'open the connection and fill the table in the dataset
        ADC.Open()
        dsCmd.FillDataSet(dset, tbname)
        'get the table from the result dataset
        Dim dtable As DataTable = dset.Tables(0)
        adc.Close() 'close the connection
        Return dtable   'return the table we read
    End Function
    '-------    
    Public Function openQuery(ByVal query As String) As DataTable
        Dim dsCmd As New ADODataSetCommand()
        Try
            dsCmd.SelectCommand = New ADOCommand(query, ADC)
            Dim dset As New DataSet()
            ADC.Open()
            dsCmd.FillDataSet(dset, "mine")
            Dim dtable As DataTable = dset.Tables(0)
            adc.Close()
            Return dtable
        Catch e As Exception
            messagebox.show(e.Message)
        End Try
        
    End Function
    Public Function getConnection() As ADOConnection
        Return adc
    End Function
End Class
