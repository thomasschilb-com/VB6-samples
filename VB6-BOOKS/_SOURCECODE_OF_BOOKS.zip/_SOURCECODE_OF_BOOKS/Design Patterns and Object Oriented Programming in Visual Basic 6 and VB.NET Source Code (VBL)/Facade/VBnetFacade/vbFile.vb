Imports System
Imports System.IO
Imports System.ComponentModel



Public class vbFile
'encapsulates the common read, write, exists and delete methods
'for text file manipulation

Private opened As Boolean   'true if file is open
Private end_file As Boolean 'true if at end of file
Private errDesc As String   'text of last error message
Private File_name As String 'name of file
private fl as File
private ts as StreamReader
private tok as StringTokenizer
private tokLine as String
private fs as FileStream
private sw as StreamWriter
private errFlag as boolean
private lineLength as integer
private sep as String           'tokenizer separator
'-----
Public sub New(filename as String) 
  MyBase.New
  file_name = filename
  fl = New File(file_name)
  tokLine = ""
  sep = ","
end Sub

Public Overloads Function OpenForRead() as Boolean
   OpenForRead = OpenForRead(file_name)
   
end Function

Public OverLoads Function OpenForRead(Filename As String) As Boolean
 file_name = Filename
 errFlag = false
 end_File = false
 tok = new StringTokenizer("")
try
 ts = fl.Opentext()
catch e as Exception
  errDesc = e.Message
  Console.writeline(errDesc)
  errFlag = true
end Try  
openForRead = errFlag

End Function

Public Function readLine() As String
 dim s as string
 try
  s = ts.readLine
  lineLength = s.length
 catch e as Exception
  end_file =true
  s=""
 'finally
  'readLine = s 
  'return( s)
 end try 
 return s
End Function


Public Function readToken() As String
 dim token as string  
 
  token = tok.nextToken
        If (token.length < 1) Then
            tokLine = ts.readLine
            tok = New StringTokenizer(tokLine, sep)
            token = tok.nextToken
        End If
        
        Return token
    End Function
    
    Public Sub closeFile()
        ts.close()
    End Sub
    
    Public Function exists() As Boolean
        exists = fl.exists
    End Function
    
    Public Function getLastError() As String
        getlastError = errDesc
    End Function
    
    Public Function OpenForWrite(ByVal fname As String) As Boolean
        errFlag = False
        Try
            file_name = fname
            fs = New FileStream(fname, FileMode.OpenOrCreate, FileAccess.Write)
            sw = New StreamWriter(fs)
        Catch e As Exception
            errDesc = e.Message
            errflag = True
        End Try
        openForWrite = errFlag
    End Function
    
    Public Sub writeText(ByVal s As String)
        sw.writeLine(s)
    End Sub
    
    Public Sub setFilename(ByVal fname As String)
        file_name = fname
    End Sub
    
    Public Function getFilename() As String
        getFilename = file_name
    End Function
    
    Public Function fEOF() As Boolean
        fEOF = end_file
    End Function
    
End Class


