Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class FoodPrices
    Inherits System.WinForms.Form
    Private db As DBase
    Private shops As Stores
    Private prc As prices
    '-----
    Public Sub New()
        MyBase.New()
        Dim i As Integer
        Form1 = Me
        InitializeComponent()
        db = New DBase("newgroc.mdb", "Access")
        shops = New Stores(db)
        prc = New Prices(db)
        loadfoodtable()        
    End Sub
    '-----
    Private Sub loadFoodTable()
        Dim fods As New Foods(db)
        fods.openTable()
        While fods.hasMoreElements
            lsfoods.Items.Add(fods.getValue)
        End While
    End Sub
    '-----
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btLoad As System.WinForms.Button
    Private WithEvents lsPrices As System.WinForms.ListBox
    Private WithEvents lsFoods As System.WinForms.ListBox
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsFoods = New System.WinForms.ListBox()
        Me.lsPrices = New System.WinForms.ListBox()
        Me.btLoad = New System.WinForms.Button()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsFoods.Location = New System.Drawing.Point(16, 32)
        lsFoods.Size = New System.Drawing.Size(176, 199)
        lsFoods.TabIndex = 0
        
        lsPrices.Location = New System.Drawing.Point(248, 32)
        lsPrices.Size = New System.Drawing.Size(168, 199)
        lsPrices.TabIndex = 1
        
        btLoad.Location = New System.Drawing.Point(64, 240)
        btLoad.Size = New System.Drawing.Size(80, 24)
        btLoad.TabIndex = 2
        btLoad.Text = "Load data"
        Me.Text = "Database Facade"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 273)
        
        Me.Controls.Add(btLoad)
        Me.Controls.Add(lsPrices)
        Me.Controls.Add(lsFoods)
    End Sub
    
#End Region
    '-----
    Protected Sub btLoad_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim dload As New DataLoader(db)
        dload.load("groceries.txt")
        loadfoodtable()
    End Sub
    '-----
    Protected Sub lsFoods_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim food As String = lsfoods.Text
        Dim dtable As DataTable = prc.getPrices(food)
        Dim rw As datarow
        lsprices.Items.Clear()
        For Each rw In dtable.Rows
            lsprices.Items.Add(rw("StoreName").tostring + " " + rw("Price").tostring)
        Next
    End Sub
    
End Class
