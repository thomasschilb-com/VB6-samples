Imports System.Collections
Imports System.Data
Imports System.Data.ADO

Public Class Prices
    Inherits DBTable
    Private priceList As ArrayList
    Public Sub new(ByVal datab As DBase)
        MyBase.New(datab, "Prices")
        pricelist = New ArrayList()
    End Sub
    '------
    Public Sub addRow(ByVal storekey As Long, ByVal foodkey As Long, ByVal price As Single)
        pricelist.Add(New StoreFoodPrice(storekey, foodkey, price))
    End Sub
    '------
    Public Overloads Sub makeTable()
        'stores current array list values in data table
        Dim adc As ADOConnection
        Dim cmd As adocommand
        Dim dset As New DataSet(tablename)
        Dim row As DataRow
        Dim fprice As StoreFoodPrice
        Dim dtable As New DataTable(tablename)
        dset.Tables.Add(dtable)
        adc = db.getConnection
        adc.Open()
        Dim adcmd As New ADODataSetCommand()
        'fill in price table
        adcmd.SelectCommand = New ADOCommand("Select * from " + tablename, adc)
        adcmd.TableMappings.Add("Table", tablename)
        adcmd.FillDataSet(dset, tablename)
        Dim ienum As IEnumerator = pricelist.GetEnumerator
        'add new price entries
        While ienum.MoveNext
            fprice = CType(ienum.Current, Storefoodprice)
            row = dtable.NewRow
            row("foodkey") = fprice.getFood
            row("storekey") = fprice.getStore
            row("price") = fprice.getPrice
            dtable.Rows.Add(row)    'add to table
        End While
        adcmd.Update(dset)      'send back to database
        adc.Close()        
    End Sub
    '------
    Public Function getPrices(ByVal food As String) As DataTable
        Dim query As String
        query = "SELECT Stores.StoreName, Foods.Foodname, Prices.Price " & _
        "FROM (Prices INNER JOIN Foods ON Prices.Foodkey = Foods.Foodkey) INNER JOIN Stores ON Prices.StoreKey = Stores.StoreKey " & _
        "WHERE(((Foods.Foodname) = """ & food & """)) " & _
        "ORDER BY Prices.Price;"
        Return db.openQuery(query)
    End Function
    
End Class
