Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

public class FileOpen
  implements Command
  inherits MenuItem
  
public sub New(evh as EventHandler)
  MyBase.New("Open", evh)

end Sub

public Sub Execute Implements Command.Execute
        Dim fd as OpenFileDialog
            fd = New OpenFileDialog
            fd.ShowDialog

End Sub


End Class
