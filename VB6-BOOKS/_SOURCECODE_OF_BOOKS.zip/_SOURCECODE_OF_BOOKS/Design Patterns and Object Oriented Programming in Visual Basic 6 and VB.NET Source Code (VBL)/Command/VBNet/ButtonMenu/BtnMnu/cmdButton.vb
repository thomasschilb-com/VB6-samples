Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class cmdButton
    Inherits System.WinForms.Button
    Implements Command
    Private frm As Form
    Public Sub New()
        MyBase.New
        InitializeComponent
    End Sub
    '-----
    Public Sub setForm(ByVal fm As Form)
        frm = fm
    End Sub
    '-----
    'overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    
    Dim WithEvents cmdButton As System.WinForms.UserControl
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub
    
#End Region
    '-----
    Public Sub Execute() Implements Command.Execute
        frm.BackColor = Color.Red
    End Sub
End Class
