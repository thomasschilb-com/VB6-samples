public interface Command
 Sub Execute()
End interface
