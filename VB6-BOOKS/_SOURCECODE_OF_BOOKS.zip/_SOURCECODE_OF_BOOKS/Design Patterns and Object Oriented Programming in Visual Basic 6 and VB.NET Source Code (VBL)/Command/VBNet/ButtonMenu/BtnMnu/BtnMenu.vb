Imports System.Drawing
Imports System.WinForms


Imports System.ComponentModel


Public Class BtnMenu
    Inherits System.WinForms.Form

    Public Sub New()
        MyBase.New

        BtnMenu = Me

        'This call is required by the Win Form Designer.
        InitializeComponent()
        'create the event handler        
        Dim evh As EventHandler = _
                  New EventHandler(AddressOf commandhandler)
        'set up the button
        btRed.setForm(Me)
        AddHandler btRed.Click, evh
        'define the menu ite,s
        Dim mnuOpen As FileOpen = New FileOpen()
        Dim mnuExit As exitmenu = New ExitMenu(Me)
        menubar.MenuItems.Add(mnuopen)
        menubar.MenuItems.Add(mnuexit)
        'connect event handler to them
        AddHandler mnuexit.Click, evh
        AddHandler mnuopen.Click, evh
    End Sub
    '-----
    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub
    '-----
    Private Sub CommandHandler(ByVal sender As Object, _
            ByVal e As System.EventArgs)
        Dim cmd As Command
        cmd = CType(sender, Command)
        cmd.Execute()
    End Sub
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btRed As BtnMnu.cmdButton
    
    
    Private WithEvents Menubar As System.WinForms.MenuItem
    Private File As System.WinForms.MainMenu
    
    Dim WithEvents BtnMenu As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Menubar = New System.WinForms.MenuItem()
        Me.btRed = New BtnMnu.cmdButton()
        Me.File = New System.WinForms.MainMenu()
        
        '@design Me.TrayHeight = 90
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Menubar.Text = "File"
        Menubar.Index = 0
        
        btRed.Location = New System.Drawing.Point(88, 40)
        btRed.Size = New System.Drawing.Size(80, 32)
        btRed.TabIndex = 0
        btRed.Text = "Red"
        
        '@design File.SetLocation(New System.Drawing.Point(7, 7))
        Dim a__1(1) As System.WinForms.MenuItem
        a__1(0) = Menubar
        File.MenuItems.All = a__1
        Me.Text = "BtnMenu"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.Menu = File
        Me.ClientSize = New System.Drawing.Size(280, 137)
        
        Me.Controls.Add(btRed)
    End Sub
    
#End Region
    
End Class
