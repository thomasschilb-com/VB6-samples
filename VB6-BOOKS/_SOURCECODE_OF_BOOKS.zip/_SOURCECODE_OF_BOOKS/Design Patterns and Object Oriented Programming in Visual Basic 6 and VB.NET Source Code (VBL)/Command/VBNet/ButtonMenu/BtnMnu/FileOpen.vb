Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

Public Class FileOpen
    Implements Command
    Inherits MenuItem
    
    Public Sub new()
        MyBase.New("Open")
    End Sub
    '-----
    Public Sub Execute() Implements Command.Execute
        Dim fd As OpenFileDialog
        fd = New OpenFileDialog()
        fd.ShowDialog()
    End Sub
    
    
End Class
