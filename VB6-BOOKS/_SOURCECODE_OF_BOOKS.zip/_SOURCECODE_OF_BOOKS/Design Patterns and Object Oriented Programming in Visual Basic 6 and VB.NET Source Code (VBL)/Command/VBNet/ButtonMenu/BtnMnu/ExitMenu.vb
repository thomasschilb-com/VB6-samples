Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public class ExitMenu
  inherits MenuItem
  implements Command
  
Private frm as Form
'-----
    Public Sub New(ByVal frm_ As Form)
        MyBase.New("Exit")
        frm = frm_
    End Sub
    '-----
    Public Sub Execute() Implements Command.Execute
        frm.close()
    End Sub
End Class
