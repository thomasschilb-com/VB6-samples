Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public class ExitMenu
  inherits MenuItem
  implements Command
  
Private frm as Form
'-----
Public sub New(evh as EventHandler, frm_ as Form)
 MyBase.New("Exit", evh)
 frm = frm_  
End sub
'-----
Public sub Execute Implements Command.Execute
 frm.close
End sub

End class
