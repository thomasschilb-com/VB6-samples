Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

'Button that turns the form red
Public class RedButton
  inherits Button
  implements Command
  
Private frm as Form
'-----
public sub New(frm_ as Form, evh as EventHandler)
 MyBase.New()
 Me.Text = "Red"
 AddOnClick(evh)
 frm = frm_
End Sub
'-----  
'Set the background color to red
Public sub Execute implements Command.Execute
 frm.backColor = red
End sub

End class
