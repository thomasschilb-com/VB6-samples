Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms


Public class FileOpenCommand
    Implements Command
    'Command object to show file-open dialog 
    Public Sub New()
        MyBase.New()
    End Sub
    '------
    Public Sub Execute() Implements Command.Execute
        Dim fd As OpenFileDialog
        fd = New OpenFileDialog()
        fd.ShowDialog()
    End Sub
End Class

