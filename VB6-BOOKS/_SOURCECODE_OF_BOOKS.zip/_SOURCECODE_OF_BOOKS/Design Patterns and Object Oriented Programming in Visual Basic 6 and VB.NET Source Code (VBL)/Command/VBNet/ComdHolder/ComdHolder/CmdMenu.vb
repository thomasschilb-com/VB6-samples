Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

Public Class CmdMenu
    Implements CommandHolder
    Inherits MenuItem   
    Protected comd As Command
    '-----
    Public Sub New(ByVal lbl As String, ByVal cmd As Command, ByVal evh As EventHandler)
        MyBase.New(lbl)
        AddHandler Click, evh
        comd = cmd
    End Sub
    '-----
    Public Function getCommand() As Command Implements CommandHolder.getCommand
        Return comd
    End Function
End Class
