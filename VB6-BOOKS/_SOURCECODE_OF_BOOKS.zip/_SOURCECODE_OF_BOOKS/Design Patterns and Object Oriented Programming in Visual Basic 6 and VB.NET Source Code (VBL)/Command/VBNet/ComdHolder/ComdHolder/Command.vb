public interface Command

Sub Execute()

end interface
