Imports System.Drawing
Imports System.WinForms


Imports System.ComponentModel


Public Class CmdHolder
    Inherits System.WinForms.Form

    Public Sub New()
        MyBase.New

        CmdHolder = Me

        'This call is required by the Win Form Designer.
        InitializeComponent()
        Dim redc As RedCommand = New RedCommand(Me)
        redbutton.setCommand(redc)
        Dim exitc As ExitCommand = New ExitCommand(Me)
        Dim fopenc As FileOpenCommand = New FileOpenCommand()
        Dim evh As EventHandler = New EventHandler(AddressOf CommandHandler)
        AddHandler redButton.Click, evh
        'menu items
        Dim mnuOpen As CmdMenu = New CmdMenu("Open", fopenc, evh)
        menubar.MenuItems.Add(mnuOpen)
        Dim mnuRed As CmdMenu = New CmdMenu("Red", redc, evh)
        menubar.MenuItems.Add(mnured)
        Dim mnuExit As CmdMenu = New CmdMenu("Exit", exitc, evh)
        menuBar.MenuItems.Add(mnuExit)
        
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents redButton As ComdHolder.cmdButton
    Private WithEvents MenuBar As System.WinForms.MenuItem
    Private MainMenu1 As System.WinForms.MainMenu
    
    Dim WithEvents CmdHolder As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.redButton = New ComdHolder.cmdButton()
        Me.MainMenu1 = New System.WinForms.MainMenu()
        Me.MenuBar = New System.WinForms.MenuItem()
        
        '@design Me.TrayHeight = 90
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        redButton.Location = New System.Drawing.Point(128, 80)
        redButton.Size = New System.Drawing.Size(80, 32)
        redButton.TabIndex = 0
        redButton.Text = "Red"
        
        '@design MainMenu1.SetLocation(New System.Drawing.Point(7, 7))
        Dim a__1(1) As System.WinForms.MenuItem
        a__1(0) = MenuBar
        MainMenu1.MenuItems.All = a__1
        
        MenuBar.Text = "File"
        MenuBar.Index = 0
        Me.Text = "CmdHolder"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.Menu = MainMenu1
        Me.ClientSize = New System.Drawing.Size(376, 229)
        
        Me.Controls.Add(redButton)
    End Sub
    
#End Region
    Public Sub CommandHandler(ByVal sender As Object, _
            ByVal e As EventArgs)
        Dim cmdh As CommandHolder
        Dim cmd As Command
        cmdh = CType(sender, CommandHolder)
        cmd = cmdh.getCommand
        cmd.Execute()
    End Sub
End Class
