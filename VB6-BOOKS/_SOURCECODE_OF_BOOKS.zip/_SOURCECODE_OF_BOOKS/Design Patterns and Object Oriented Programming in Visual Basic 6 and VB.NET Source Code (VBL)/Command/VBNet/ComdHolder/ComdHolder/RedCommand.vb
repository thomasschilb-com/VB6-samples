Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

public class RedCommand
 implements Command
private frm as Form 

public sub New(Frm_ as Form)
MyBase.New
frm = Frm_
end Sub

public sub Execute Implements Command.Execute
 frm.backColor = red
End Sub

End Class
