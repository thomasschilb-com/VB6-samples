Public Interface CommandHolder
    Function getCommand() As Command  
End Interface
