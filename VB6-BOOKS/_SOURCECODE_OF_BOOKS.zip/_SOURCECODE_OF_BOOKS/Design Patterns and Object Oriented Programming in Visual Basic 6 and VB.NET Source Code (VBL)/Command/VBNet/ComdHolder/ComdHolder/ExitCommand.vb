Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

public class ExitCommand
 implements Command
 
private frm as Form

public Sub New(frm_ as Form)
 MyBase.New
 frm = frm_
end Sub 

public sub Execute Implements Command.Execute
    frm.close
End sub

end class
