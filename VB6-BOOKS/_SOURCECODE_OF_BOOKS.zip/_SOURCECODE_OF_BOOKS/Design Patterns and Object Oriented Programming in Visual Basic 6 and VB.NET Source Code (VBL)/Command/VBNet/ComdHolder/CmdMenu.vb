Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

public class CmdMenu
 implements CommandHolder
 inherits MenuItem
 
protected comd as Command

public Sub New(lbl as String, evh as EventHandler, cmd as Command)
 MyBase.New(lbl, evh)
 comd = cmd
end Sub 

public function getCommand as Command Implements CommandHolder.getCommand
 return comd
End Function

end class
