public Interface CommandHolder

 Function getCommand as Command

End Interface
