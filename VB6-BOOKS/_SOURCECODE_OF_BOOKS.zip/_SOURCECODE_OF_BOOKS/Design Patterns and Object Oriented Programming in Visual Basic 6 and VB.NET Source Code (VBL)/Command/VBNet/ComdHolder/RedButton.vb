Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms


public class RedButton
  inherits Button
  implements CommandHolder

private cmd as Command
  
public sub New(evh as EventHandler, cmd_ as Command)

MyBase.New()
Me.Text = "Red"
AddOnClick(evh)
cmd = cmd_
End Sub

Public Function getCommand() as Command Implements CommandHolder.getCommand
 return cmd
end Function
  

end class
