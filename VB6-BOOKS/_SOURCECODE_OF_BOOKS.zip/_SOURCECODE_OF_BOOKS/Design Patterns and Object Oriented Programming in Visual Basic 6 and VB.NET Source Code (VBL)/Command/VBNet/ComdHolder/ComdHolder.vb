Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

 
    Public Class ComdHolder
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
        Private MainMenu As System.WinForms.MainMenu
                Private RedButton As System.WinForms.Button
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New ComdHolder())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.MainMenu = New System.WinForms.MainMenu
            Dim miFile As MenuItem = mainMenu.MenuItems.Add("&File")
            Dim cmd, rcmd as Command
            Dim evh as EventHandler
            evh = new EventHandler(AddressOf CommandHandler)
            
            cmd = New FileOpenCommand
            miFile.MenuItems.Add(new CmdMenu("Open", evh, cmd))
            
            
            rcmd = new RedCommand(me)
            miFile.MenuItems.Add(new CmdMenu("Red", evh, rcmd) )
            cmd = New ExitCommand(Me)
            miFile.MenuItems.Add(new CmdMenu( "Exit", evh, cmd) )
            Me.RedButton = New RedButton(evh, rcmd)

            RedButton.Location = New System.Drawing.Point(80, 64)
            RedButton.Size = New System.Drawing.Size(88, 32)
            RedButton.TabIndex = 0
            RedButton.Text = "Red"
            

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Button Menu"
            
            Me.Menu = MainMenu
            Me.ClientSize = New System.Drawing.Size(272, 165)

            Me.Controls.Add(RedButton)

        End Sub
        
Private Sub CommandHandler(sender As object, e As System.EventArgs)      
 Dim cmdh as CommandHolder
 Dim cmd as Command

 cmdH = CType(sender, CommandHolder)
 cmdH.getCommand().Execute
 end sub
        
End Class


