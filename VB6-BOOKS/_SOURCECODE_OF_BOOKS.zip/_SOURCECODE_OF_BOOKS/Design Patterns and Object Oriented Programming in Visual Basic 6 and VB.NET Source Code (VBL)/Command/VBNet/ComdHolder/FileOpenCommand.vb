Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms


Public class FileOpenCommand
  implements Command
'Command object to show file-open dialog 
public Sub New()
  MyBase.New
End sub


public Sub Execute Implements Command.Execute
 Dim fd as OpenFileDialog
 fd = New OpenFileDialog
 fd.ShowDialog
End Sub

End Class

