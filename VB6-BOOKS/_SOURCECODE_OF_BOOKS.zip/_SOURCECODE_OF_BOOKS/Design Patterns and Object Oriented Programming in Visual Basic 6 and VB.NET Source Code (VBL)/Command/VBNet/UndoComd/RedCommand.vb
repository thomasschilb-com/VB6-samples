Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms
Imports System.Collections


Public CLass RedCommand
Inherits BlueCommand

Public Sub New(pict As PictureBox)
  MyBase.New(pict)
  colr = Red
  x = 0
  dx = 20
  y = 0
  dy = 0
End Sub

End CLass
