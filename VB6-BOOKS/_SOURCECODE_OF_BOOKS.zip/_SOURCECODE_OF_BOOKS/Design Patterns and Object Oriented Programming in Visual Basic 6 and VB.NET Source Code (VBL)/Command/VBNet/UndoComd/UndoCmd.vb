Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


    Public Class UndoCmd
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private btBlue As System.WinForms.Button
                Private btUndo As System.WinForms.Button
                        Private btRed As System.WinForms.Button
                Private Pic As PaintPanel
                Private uCmd as UndoCommand
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New UndoCmd())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            
            Me.Pic = new PaintPanel
            Pic.Location = New System.Drawing.Point(0, 24)
            Pic.Size = New System.Drawing.Size(272, 200)
            Pic.TabIndex = 0
            Pic.TabStop = False
            Pic.Text = "P"
                        

            Dim bCmd as BlueCommand = new BlueCommand(Pic)
            Me.btBlue = New BlueButton("Blue", bcmd)
            DIm rCmd as RedCommand = new RedCommand(Pic)
            Me.btRed = New RedButton("Red", rcmd)
            ucmd = new UndoCommand
            Me.btUndo = New UndoButton("Undo", ucmd)

            Pic.setCommands(rcmd, bcmd)

            btBlue.Location = New System.Drawing.Point(192, 240)
            btBlue.Size = New System.Drawing.Size(64, 24)
            btBlue.TabIndex = 3
            btBlue.Text = "Blue"
            btBlue.AddOnClick(New System.EventHandler(AddressOf Me.CommandHandler))

            btRed.Location = New System.Drawing.Point(16, 240)
            btRed.Size = New System.Drawing.Size(48, 24)
            btRed.TabIndex = 1
            btRed.Text = "Red"
            btRed.AddOnClick(New System.EventHandler(AddressOf Me.CommandHandler))

            
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Win32Form1"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0

            btUndo.Location = New System.Drawing.Point(96, 240)
            btUndo.Size = New System.Drawing.Size(64, 24)
            btUndo.TabIndex = 2
            btUndo.Text = "Undo"
            btUndo.AddOnClick(New System.EventHandler(AddressOf Me.CommandHandler))

            Me.Controls.Add(btBlue)
            Me.Controls.Add(btUndo)
            Me.Controls.Add(btRed)
            Me.Controls.Add(Pic)

        End Sub
        
Private Sub CommandHandler(sender As object, e As System.EventArgs)
       
 Dim cmdh as CommandHolder
 Dim cmd as Command

 cmdH = CType(sender, CommandHolder)
 cmd = cmdH.getCommand
 cmd.Execute
 uCmd.add(cmd)          'add each command into Undo list
End sub

     


End Class


