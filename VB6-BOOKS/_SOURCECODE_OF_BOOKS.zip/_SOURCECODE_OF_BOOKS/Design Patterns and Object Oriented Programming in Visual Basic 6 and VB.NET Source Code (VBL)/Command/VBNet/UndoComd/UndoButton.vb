Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

public class UndoButton
  inherits BlueButton
  
public sub New(txt as String, cmd as Command)
 MyBase.New(txt, cmd)
end Sub

End Class
