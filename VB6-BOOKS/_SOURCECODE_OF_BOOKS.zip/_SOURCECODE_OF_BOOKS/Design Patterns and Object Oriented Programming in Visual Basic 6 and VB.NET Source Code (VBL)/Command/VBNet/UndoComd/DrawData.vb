
public class DrawData
Private x, y, dx , dy As Integer

Public Sub New(x_ As Integer, y_ As Integer, dx_ As Integer, dy_ As Integer)
MyBase.New
 x = x_
 y = y_
 dx = dx_
 dy = dx_
End Sub

Public Function getX() As Integer
 getX = x
End Function

Public Function getY() As Integer
 getY = y
End Function

Public Function getdX() As Integer
 getdX = dx
End Function

Public Function getdY() As Integer
 getdY = dy
End Function

End Class
