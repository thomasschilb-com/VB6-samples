public Interface Command

 Sub Execute()

 Sub Undo()

Function isUndo as Boolean
End Interface
