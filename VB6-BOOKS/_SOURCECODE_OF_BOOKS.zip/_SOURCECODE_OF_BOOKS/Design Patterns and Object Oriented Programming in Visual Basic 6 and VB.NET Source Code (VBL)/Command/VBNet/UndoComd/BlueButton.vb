Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class BlueButton 
  Inherits Button
  Implements CommandHolder
private cmd as Command  

public Sub New(txt as String, comd as Command)
 MyBase.New()
 Me.text = txt
 cmd = comd
End Sub

public Function getCommand() as Command Implements CommandHolder.getCommand
  return cmd
End Function


End Class
