Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class UndoCommand
Implements Command
Private undoList As ArrayList

Public Sub New()
 MyBase.New
 undoList = New ArrayList
End Sub

Public Sub add(cmd As Command)
If Not (cmd.IsUndo) Then
  undoList.add (cmd)
End If
End Sub

Public Sub Execute Implements Command.Execute
Dim Index As Integer
Dim cmd As Command
Index = undoList.Count-1

If Index >= 0 Then
  cmd = Ctype(undoList(Index), COmmand)
  cmd.Undo
  undoList.RemoveAt( Index)
  
End If
End Sub

public function isUndo as Boolean Implements Command.IsUndo
 return true
end function 


Private Sub Undo Implements Command.Undo
'do nothing
End Sub

End Class
