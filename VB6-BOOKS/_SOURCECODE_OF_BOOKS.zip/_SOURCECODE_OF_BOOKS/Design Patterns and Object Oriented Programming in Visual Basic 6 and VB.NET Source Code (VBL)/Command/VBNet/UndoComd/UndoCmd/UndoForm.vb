Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class UndoForm
    Inherits System.WinForms.Form
    Private redc As RedCommand
    Private bluec As BlueCommand
    Private undoC As UndoCommand
    Public Sub New()
        MyBase.New()
        
        Form1 = Me
        
        'This call is required by the Win Form Designer.
        InitializeComponent()
        Dim evh As EventHandler = New EventHandler(AddressOf commandhandler)
        redc = New RedCommand(pict)
        bluec = New BlueCommand(pict)
        undoc = New UndoCommand()
        redbutton.setCommmand(redc)
        blueButton.setCommmand(bluec)
        undoButton.setCommmand(undoc)
        AddHandler RedButton.Click, evh
        AddHandler BlueButton.Click, evh
        AddHandler UndoButton.Click, evh
        AddHandler Pict.Paint, New PaintEventHandler(AddressOf painthandler)
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pict As System.WinForms.PictureBox
    Private WithEvents UndoButton As UndoCmd.CmdButton
    Private WithEvents BlueButton As UndoCmd.CmdButton
    Private WithEvents RedButton As UndoCmd.CmdButton
    
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.UndoButton = New UndoCmd.CmdButton()
        Me.BlueButton = New UndoCmd.CmdButton()
        Me.Pict = New System.WinForms.PictureBox()
        Me.RedButton = New UndoCmd.CmdButton()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        UndoButton.Location = New System.Drawing.Point(168, 240)
        UndoButton.Size = New System.Drawing.Size(72, 32)
        UndoButton.TabIndex = 3
        UndoButton.Text = "Undo"
        
        BlueButton.Location = New System.Drawing.Point(288, 240)
        BlueButton.Size = New System.Drawing.Size(72, 32)
        BlueButton.TabIndex = 2
        BlueButton.Text = "Blue"
        
        Pict.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pict.Location = New System.Drawing.Point(32, 16)
        Pict.Size = New System.Drawing.Size(352, 216)
        Pict.TabIndex = 4
        Pict.TabStop = False
        
        RedButton.Location = New System.Drawing.Point(40, 240)
        RedButton.Size = New System.Drawing.Size(64, 32)
        RedButton.TabIndex = 1
        RedButton.Text = "Red"
        Me.Text = "Undo Command Example"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 285)
        
        Me.Controls.Add(Pict)
        Me.Controls.Add(UndoButton)
        Me.Controls.Add(BlueButton)
        Me.Controls.Add(RedButton)
    End Sub
    
#End Region
    Public Sub CommandHandler(ByVal sender As Object, ByVal e As EventArgs)
        Dim cmdh As CommandHolder
        Dim cmd As Command
        'get the command
        cmdh = CType(sender, commandholder)
        cmd = cmdh.getCommand
        undoc.add(cmd) 'add it to the undo list
        cmd.Execute()
    End Sub
    Public Sub PaintHandler(ByVal sender As Object, ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        redc.draw(g)
        bluec.draw(g)
    End Sub
End Class
