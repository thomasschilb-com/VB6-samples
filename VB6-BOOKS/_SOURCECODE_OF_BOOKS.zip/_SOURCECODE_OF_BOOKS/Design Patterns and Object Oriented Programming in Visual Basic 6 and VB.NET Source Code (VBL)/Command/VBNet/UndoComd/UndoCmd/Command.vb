Public Interface Command
    Sub Execute()
    Sub Undo()  
    Function isUndo() As Boolean
End Interface
