Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class CmdButton
    Inherits System.WinForms.Button
    Implements CommandHolder
    Private cmd As Command

    Public Sub New()
        MyBase.New
        'This call is required by the Win Form Designer.
        InitializeComponent       
    End Sub
    
    'CmdButton overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    Dim WithEvents CmdButton As System.WinForms.UserControl

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region
    '-----
    Public Sub setCommmand(ByVal Comd As Command)
        cmd = comd
    End Sub
    '-----
    Public Function getCommand() As Command Implements CommandHolder.getCommand
        Return cmd
    End Function
End Class
