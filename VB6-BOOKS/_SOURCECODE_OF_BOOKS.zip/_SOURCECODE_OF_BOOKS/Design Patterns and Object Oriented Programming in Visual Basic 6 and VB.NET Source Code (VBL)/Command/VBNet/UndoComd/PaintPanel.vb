Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms

Public Class PaintPanel 
  Inherits PictureBox

Dim rc as RedCommand
DIm bc as BlueCommand  

public sub setCommands(rdc as RedCommand, blc as BlueCommand)
  rc = rdc
  bc = blc
End Sub


Protected Overrides Sub OnPaint(e as PaintEventArgs) 
         Dim g as Graphics = e.Graphics
        
         rc.draw(g)
         bc.draw(g)   
        
     End Sub
     
End Class  
