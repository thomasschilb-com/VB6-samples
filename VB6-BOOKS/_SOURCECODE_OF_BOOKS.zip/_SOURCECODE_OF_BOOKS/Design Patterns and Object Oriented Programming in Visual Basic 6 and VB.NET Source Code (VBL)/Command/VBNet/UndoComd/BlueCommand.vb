Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Color
Imports System.WinForms
Imports System.Collections

public class BlueCommand
  Implements Command

Private drawList As ArrayList
Protected colr as Color
Protected x, y , dx, dy As Integer
Private pic As PictureBox

Public Sub New(pict As PictureBox)
  MyBase.New
  pic = pict
  drawList = New ArrayList
  x = pic.Width
  Colr = blue
  dx = -20
  y = 0
  dy = 0
End Sub

Public Sub Execute Implements Command.Execute
 Dim dl As DrawData
 dl = New DrawData( x, y, dx, dy)
 drawList.add( dl)
 x = x + dx
 y = y + dy
 pic.Refresh
End Sub

public function isUndo as Boolean Implements Command.IsUndo
 return false
end function 

Public Sub Undo Implements Command.Undo
 Dim Index As Integer
 Dim dl As DrawData
 Index = drawList.Count-1
 If Index >= 0 Then
   dl = CType(drawList(index), DrawData)
   drawList.RemoveAt( Index)
   x = dl.getX
   y = dl.getY
 End If
 pic.Refresh
 
End Sub

Public Sub draw(g as Graphics)
Dim h , w As Integer
Dim i As Integer
Dim dl As DrawData

Dim rpen As new Pen(Color.FromARGB(255, colr), 1)

h = pic.Height
w = pic.Width

For i = 0 To drawList.Count-1
 dl = CType(drawList(i), DrawData)
 'Console.writeLine(dl.getX.tostring+" "+dx.tostring+" "+dl.getY.toString+" "+(dl.getY+h).toString)
 g.drawLine (rpen, dl.getX, dl.getY, dl.getX + dx, dl.getdY + h)
Next i


End Sub
End Class
