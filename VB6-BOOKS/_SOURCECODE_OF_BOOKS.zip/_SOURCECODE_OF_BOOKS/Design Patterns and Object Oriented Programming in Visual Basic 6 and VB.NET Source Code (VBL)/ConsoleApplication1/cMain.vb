Public Class cMain
    Shared Sub Main()
        Console.WriteLine("Hello classy VB world")
    End Sub
End Class
