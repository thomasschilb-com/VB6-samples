Imports System
Imports System.Collections

Public Class ArrayTest
    Shared Sub Main()
        Dim i As Integer
        Dim max As Integer
        max = 10
        Dim x(10) As Single
        For i = 0 To 9
            x(i) = i
        Next i
        
        Dim ar As New ArrayList()
        For i = 0 To 9
            ar.Add(i)
        Next i
        For i = 0 To ar.Count - 1
            Console.writeLine(ar.Item(i))
            Console.writeLine(ar(i))
        Next i
        
        Try
            For i = 0 To ar.Count
                Console.write(ar.Item(i))
            Next i
        Catch e As Exception
            Console.writeLine(e.Message)
            Console.writeLine(e.stackTrace)
        End Try
        
        Console.writeline("end of loop")
        
        For i = 0 To ar.Count
            Console.writeline(ar.Item(i))
        Next i
        Console.writeline("end of loop")
        
    End Sub
End Class
