Imports System
Imports System.Collections

Public class ArrayTest
  Shared Sub Main
  Dim i as Integer
  Dim max as Integer
  max = 10
  Dim x(10) as Single
  For i = 0 to 9
    x(i) = i
  next i
  
Dim ar as New ArrayList
  For i = 0 to 9
    ar.Add(i)
  next i
  For i = 0 to ar.Count-1
    Console.writeLine(ar.Item(i))
    Console.writeLine(ar(i))
  next i
  
Try
   For i = 0 to ar.Count
    Console.write(ar.Item(i))
   Next i
Catch e as Exception
  Console.writeLine(e.Message)
  Console.writeLine(e.stackTrace)
End Try

Console.writeline("end of loop")

   For i = 0 to ar.Count
    Console.writeline(ar.Item(i))
   Next i
Console.writeline("end of loop")

  End Sub                       
End Class
