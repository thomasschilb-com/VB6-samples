Imports System
Imports System.IO
Imports System.ComponentModel


Namespace VBPatterns

Public class vbFile
'encapsulates the common read, write, exists and delete methods
'for text file manipulation

Private opened As Boolean   'true if file is open
Private end_file As Boolean 'true if at end of file
Private errDesc As String   'text of last error message
Private File_name As String 'name of file
private fl as File
private ts as StreamReader
private tok as StringTokenizer
private tokLine as String
private fs as FileStream
private sw as StreamWriter
private errFlag as boolean
private lineLength as integer
private sep as String           'tokenizer separator
'-----
Public Sub New(filename as String) 
 'Create new file instance 
  MyBase.New               'parent construction
  file_name = filename     'save file name
  fl = New File(file_name) 'get file object
  tokLine = ""             'initialize tokenizer
  sep = ","                'and separator
End Sub
'----------------
Public Overloads Function OpenForRead() as Boolean
   OpenForRead = OpenForRead(file_name)
End Function
'----------------
Public OverLoads Function OpenForRead(Filename As String) As Boolean
'opens specified file
file_name = Filename    'save file name
errFlag = false         'clear errors
end_File = false        'and end of file
Try
  ts = fl.Opentext()    'open the file
Catch e as Exception
  errDesc = e.Message   'save error message
  errFlag = true        'and flag
End Try  
openForRead = not errFlag   'false if error

End Function

Public Function readLine() As String
'Read one line from the file
 Dim s as string
 Try
  s = ts.readLine        'read line from file
  lineLength = s.length  'use to catch null exception
 Catch e as Exception
  end_file = true        'set EOF flag if null
  s=""                   'and return zero length string
 Finally
   readLine = s 
 End Try 
End Function

'example of alternate appraoch to detecting end of file
Public Function readLineE() As String
'Read one line from the file
 Dim s as string
If ts.peek >= 0 then   'look ahead
  s = ts.readLine       'read if more chars
  readLineE = s 
Else
  end_file = True       'Ser EOF flag if none left
  readLineE = ""
End If  
End Function

Public Function readToken() As String
  if(tokLine = "")
     tokLine = ts.readLine
  endif
  tok = new StringTokenizer(tokLine, sep)
  tokLine = tok.nextToken
  readToken = tokLine
End Function

Public Sub closeFile()
try 
 ts.close
 catch e as Exception
end try 

try 
 sw.close
 catch e as Exception
end try 

 
End Sub

Public Function exists() As Boolean
 exists = fl.exists
End Function

Public Function getLastError() As String
  getlastError = errDesc
End Function

Public OverLoads Function OpenForWrite(fname As String) As Boolean
   errFlag= false
   Try
    file_name = fname
    fl = new File(file_name)    'create File object
    sw = fl.CreateText          'get StreamWriter
   Catch e As Exception
     errDesc = e.Message
     errflag = true   
   End Try
openForWrite = Not errFlag  
End Function
'-------------
public Overloads Function OpenForWrite as boolean
 OpenForWrite = OpenForWrite(file_name)
End Function
'-------------
Public Sub writeText(s As String)       
   sw.writeLine(s)              'writ text to stream
End Sub

Public Sub setFilename(fname As String)
  file_name = fname
End Sub

Public Function getFilename() As String
    getFilename = file_name
End Function

Public Function fEOF as boolean
  fEOF = end_file
end Function

End Class

End NameSpace
