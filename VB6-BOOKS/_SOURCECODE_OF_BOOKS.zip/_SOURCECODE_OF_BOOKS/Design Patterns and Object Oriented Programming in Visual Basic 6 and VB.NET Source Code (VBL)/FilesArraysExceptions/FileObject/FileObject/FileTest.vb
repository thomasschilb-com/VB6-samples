
Imports System.IO
Imports System.ComponentModel
Imports FileObject.VBPatterns

Public Class FileTest
    
    Public Sub New()
        MyBase.New()
        Dim fl As vbFile
        Dim s As String
        
        fl = New vbFile("500free.txt")
        fl.openForRead()
        s = fl.readLine
        
        While Not (fl.fEOF)
            Console.writeline(s)
            s = fl.readLine
        End While
        fl.closeFile()
        
        Dim outf As New vbFile("outTest.txt")
        outf.OpenForWrite()
        outf.writeText("file write test")
        outf.closeFile()
    End Sub
    
    Public Shared Sub Main()
        
        Dim ft As FileTest
        ft = New FileTest()
    End Sub
    
End Class
