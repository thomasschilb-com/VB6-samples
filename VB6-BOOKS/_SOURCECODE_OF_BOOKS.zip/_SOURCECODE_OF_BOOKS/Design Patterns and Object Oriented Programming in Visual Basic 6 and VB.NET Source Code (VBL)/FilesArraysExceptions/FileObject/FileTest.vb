Imports System
Imports System.IO
Imports System.ComponentModel
imports vbPatterns

public class FileTest

public Sub New()
   myBase.New
   Dim fl as vbFile
   Dim s as String
   
   fl = new vbFile("500free.txt")
   fl.openForRead
   s = fl.readLine

   while not(fl.fEOF)  
        Console.writeline(s)  
        s = fl.readLine
   end While
   fl.closeFile

   Dim outf as New vbFile("outTest.txt")
   outf.OpenForWrite
   outf.writeText("file write test")
   outf.closeFile     
 End Sub

public Shared Sub Main()
  
  Dim ft as FileTest
  ft = new FileTest
end Sub

end Class
