
Imports System
Imports System.Collections

Public class ArrayTest
  Shared Sub Main
  Dim i as Integer
  Dim max as Integer
  max = 10
  Dim x(10) as Single
  For i = 0 to 9
    x(i) = i
  next i
  
Dim ar as New ArrayList
  For i = 0 to 9
    ar.Add(i)
  next i
Try
   For i = 0 to ar.Count
    Console.writeLine(i.toString +" "+ar.Item(i)/i)
   Next i
Catch e as DivideByZeroException
  Console.writeLine(e.Message)
  Console.writeLine(e.stackTrace)
Catch e as IndexOutOfRangeException  
  Console.writeLine(e.Message)
  Console.writeLine(e.stackTrace)
Catch e As Exception
  Console.writeLine("general exception"+e.Message)
  Console.writeLine(e.stackTrace)

End Try


  End Sub                       
End Class
