Imports System.Collections

Public Class ArrayTest
    Shared Sub Main()
        Dim i As Integer
        Dim max As Integer
        max = 10
        Dim x(10) As Single
        For i = 0 To 9
            x(i) = i
        Next i
        
        Dim ar As New ArrayList()
        For i = 0 To 9
            ar.Add(i)
        Next i
        Try
            For i = 0 To ar.Count
                Dim k As Integer = CType(ar(i), Integer)
                Console.writeLine(i.toString & " " & k / i)
            Next i
        Catch e As DivideByZeroException
            Console.writeLine(e.Message)
            Console.writeLine(e.stackTrace)
        Catch e As IndexOutOfRangeException
            Console.writeLine(e.Message)
            Console.writeLine(e.stackTrace)
        Catch e As Exception
            Console.writeLine("general exception" + e.Message)
            Console.writeLine(e.stackTrace)
        End Try
    End Sub
End Class
