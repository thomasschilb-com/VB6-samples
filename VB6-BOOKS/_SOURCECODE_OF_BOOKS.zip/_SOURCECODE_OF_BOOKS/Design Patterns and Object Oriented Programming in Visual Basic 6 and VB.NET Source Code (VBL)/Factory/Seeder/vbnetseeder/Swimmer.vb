Imports System
Imports System.ComponentModel
Imports System.Collections
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility
Imports vbnetseeder.vbPatterns

Public Class Swimmer
    
    Private frname, lname As String
    Private club As String
    Private tm As Single
    Private heat, lane As Integer
    
    Public Sub New(ByVal dataline As String)
        MyBase.new()
        
        Dim tok As New StringTokenizer(dataline, " ")
        Dim lnum As String
        Dim age As String
        Dim tmS As Times
        Dim s As String
        
        lnum = tok.nextToken    'line number
        frname = tok.nextToken  'first name
        lname = tok.nextToken   'last name
        age = tok.nextToken     'age
        club = tok.nextToken    'club initials
        s = tok.nextToken
        tms = New Times(s)
        tm = tmS.getSingle      'time
    End Sub
    
    Public Function getTime() As Single
        getTime = tm
    End Function
    
    Public Function getName() As String
        getName = frname + " " + lname
    End Function
    
    Public Function getClub() As String
        getClub = club
    End Function
    
    Public Sub setLane(ByVal ln As Integer)
        lane = ln
    End Sub
    
    Public Function getLane() As Integer
        getLane = lane
    End Function
    
    Public Sub setHeat(ByVal ht As Integer)
        heat = ht
    End Sub
    
    Public Function getHeat() As Integer
        getHeat = heat
    End Function
End Class

