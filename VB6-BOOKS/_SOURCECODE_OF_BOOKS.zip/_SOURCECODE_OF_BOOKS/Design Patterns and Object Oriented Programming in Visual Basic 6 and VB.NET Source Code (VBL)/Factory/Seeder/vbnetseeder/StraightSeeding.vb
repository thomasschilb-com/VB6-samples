
Imports System.ComponentModel
Imports System.Collections
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility.VB6


Public Class StraightSeeding
    Inherits Seeding
    '-----
    Public Overrides Sub seed()
        Dim lastHeat As Integer
        Dim lastlanes As Integer
        Dim i, j, count, heats As Integer
        Dim swmr As Swimmer
        
        Try
            sw = sort(sw)
            laneOrder = calcLaneOrder(numLanes)
            count = sw.count
            
            lastHeat = count Mod numLanes
            If (lastHeat < 3) And lastHeat > 0 Then
                lastHeat = 3   'last heat must have 3 or more
            End If
            count = sw.count
            lastlanes = count - lastHeat
            numheats = lastlanes \ numLanes
            If (lastHeat > 0) Then
                numheats = numheats + 1
            End If
            heats = numheats
            
            'place heat and lane in each swimmer's object
            
            j = 0
            For i = 0 To lastlanes - 1
                
                swmr = sw.swm(i)
                
                swmr.setLane(CType(laneOrder(j), Integer))
                j = j + 1
                swmr.setHeat(heats)
                If (j >= numLanes) Then
                    heats = heats - 1
                    j = 0
                End If
            Next i
            
            
            'Add in last partial heat
            If (lastHeat > 0) Then
                If j > 0 Then
                    heats = heats - 1
                End If
                j = 0
                For i = lastlanes To count - 1
                    swmr = CType(sw(i), swimmer)
                    swmr.setLane(CType(laneOrder(j), Integer))
                    j = j + 1
                    swmr.setHeat(heats)
                Next i
            End If
            
        Catch e As exception
            Console.writeLine(i.toString + j.toString + e.toString)
            Console.writeLine(e.stackTrace)
        End Try
    End Sub
    '-----
    Public Sub New(ByVal swmrs As Swimmers, ByVal lanes As Integer)
        MyBase.new(swmrs, lanes)
    End Sub
    
End Class

