Imports System
Imports System.ComponentModel
Imports System.Collections

Public Class CircleSeeding
    Inherits StraightSeeding
    
    Private circlesd As Integer
    '-----
    Public Sub New(ByVal swmrs As Swimmers, ByVal lanes As Integer)
        MyBase.New(swmrs, lanes)
        
    End Sub
    '-----
    Public Overrides Sub seed()
        
        Dim i, j, k, numHeats As Integer
        'get the lane order
        laneOrder = calcLaneOrder(numLanes)
        sw = sort(sw)    'sort the swimmers
        
        MyBase.seed()            'seed into striaght order
        numheats = MyBase.getHeats
        'numheats = heats    'get the total number of heats
        If (numheats >= 2) Then
            If (numheats >= 3) Then
                circlesd = 3      'seed either 3
            Else
                circlesd = 2      'or 2
            End If
            i = 0
            'copy seeding info into swimmers data
            For j = 0 To numLanes - 1
                For k = 1 To circlesd
                    sw.swm(i).setLane(CType(laneOrder(j), Integer))
                    sw.swm(i).setHeat(numheats - k + 1)
                    i = i + 1
                Next k
            Next j
        End If
    End Sub
    '-----
End Class

