Option Explicit
Imports System
Imports System.IO
Imports System.ComponentModel
Imports System.Collections
Imports vbnetseeder.vbPatterns


Public Class Events
    
    Protected numLanes As Integer
    Protected swmmers As Swimmers
    '-----
    Public Sub New(ByVal Filename As String, ByVal lanes As Integer)
        MyBase.New()
        Dim s As String
        Dim sw As Swimmer
        Dim fl As vbFile
        
        
        fl = New vbFile(filename)       'Open the file
        fl.OpenForRead()
        
        numLanes = lanes                'Remember lane number
        swmmers = New Swimmers()      'list of kids
        
        'read in swimmers from file
        s = fl.ReadLine
        
        
        While Not fl.feof
            sw = New Swimmer(s)    'create each swimmer
            swmmers.Add(sw)        'add to list
            s = fl.ReadLine        'read another
        End While
        
        fl.closeFile()
        
    End Sub
    '-----
    Public Function getSwimmers() As ArrayList
        getSwimmers = swmmers
    End Function
    '-----
    Public Overridable Function isPrelim() As Boolean
    End Function
    '-----
    Public Overridable Function isFinal() As Boolean
    End Function
    '-----
    Public Overridable Function isTimedFinal() As Boolean
    End Function
    '-----
    Public Overridable Function getSeeding() As Seeding
    End Function
    
End Class

