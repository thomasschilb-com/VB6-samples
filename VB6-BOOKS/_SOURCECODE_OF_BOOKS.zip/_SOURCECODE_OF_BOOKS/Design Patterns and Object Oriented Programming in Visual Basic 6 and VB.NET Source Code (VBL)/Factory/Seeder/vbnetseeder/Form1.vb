Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private Seedings As New ArrayList()
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        Dim ev As Events
        
        ev = New PrelimEvent("100free.txt", 6)    'create a Prelim/final event
        
        Seedings.Add(ev.getSeeding)   'get the seeing and add to ArrayList
        lsEvents.Items.Add("100 Free")
        
        ev = New TimedFinalEvent("500free.txt", 6) 'create a mew Timed final event
        Seedings.Add(ev.getSeeding)    'get the seeeding
        lsEvents.Items.Add("500 Free")   'and add to ArrayList
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btSeed As System.WinForms.Button
    Private WithEvents lsSwimmers As System.WinForms.ListBox
    Private WithEvents lsEvents As System.WinForms.ListBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsEvents = New System.WinForms.ListBox()
        Me.btSeed = New System.WinForms.Button()
        Me.lsSwimmers = New System.WinForms.ListBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsEvents.Location = New System.Drawing.Point(8, 32)
        lsEvents.Size = New System.Drawing.Size(120, 173)
        lsEvents.TabIndex = 0
        
        btSeed.Location = New System.Drawing.Point(144, 232)
        btSeed.Size = New System.Drawing.Size(64, 24)
        btSeed.TabIndex = 2
        btSeed.Text = "Seed"
        
        lsSwimmers.Location = New System.Drawing.Point(152, 32)
        lsSwimmers.Size = New System.Drawing.Size(200, 173)
        lsSwimmers.TabIndex = 1
        
        Me.Text = "Form1"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 273)
        
        Me.Controls.Add(btSeed)
        Me.Controls.Add(lsSwimmers)
        Me.Controls.Add(lsEvents)
    End Sub
    
#End Region
    
    Protected Sub lsEvents_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        btSeed_click(sender, e)
    End Sub
    
    Protected Sub btSeed_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim i As Integer
        Dim sd As Seeding
        Dim swmrs As ArrayList
        Dim sw As Swimmer
        Dim sline As String
        Dim lsCol As ArrayList
        
        i = lsEvents.SelectedIndex
        
        If i >= 0 Then
            sd = CType(Seedings(i), seeding)
            sd.seed()
            swmrs = sd.getSeeding
            lsSwimmers.Items.Clear()
            lsCol = New ArrayList()
            
            For i = 0 To swmrs.count - 1
                sw = CType(swmrs(i), swimmer)
                sline = Str$(sw.getHeat) + Str$(sw.getLane) + " " + sw.getName
                sline = sline + " " + sw.getClub + " " + sw.getTime.toString
                lsSwimmers.Items.Add(sline)
            Next i
            
        End If
    End Sub
    
    
End Class
