Imports System
Imports System.ComponentModel
Imports System.Collections
Imports System.Drawing
Imports System.WinForms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility




    Public Class Seeder
        Inherits System.WinForms.Form
        
        Private Seedings As New ArrayList()
        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
        Private Seed As System.WinForms.Button
        Private lsSwimmers As System.WinForms.ListBox
        Private lsEvents As System.WinForms.ListBox
        
        Public Sub New()
            MyBase.New()
            
            'This call is required by the Win Forms Designer.
            InitializeComponent()
            
            ' TODO: Add any constructor code after InitializeComponent call
            Dim ev As Events
            
            ev = New PrelimEvent("100free.txt", 6)    'create a Prelim/final event
            
            Seedings.Add(ev.getSeeding)   'get the seeing and add to ArrayList
            lsEvents.Items.Add("100 Free")
            
            ev = New TimedFinalEvent("500free.txt", 6) 'create a mew Timed final event
            Seedings.Add(ev.getSeeding)    'get the seeeding
            lsEvents.Items.Add("500 Free")   'and add to ArrayList
            
        End Sub
        
        'Clean up any resources being used
        Public Overrides Sub Dispose()
            MyBase.Dispose()
            components.Dispose()
        End Sub
        
        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New Seeder())
        End Sub
        
        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Me.lsEvents = New System.WinForms.ListBox()
            Me.Seed = New System.WinForms.Button()
            Me.lsSwimmers = New System.WinForms.ListBox()
            
            lsEvents.Location = New System.Drawing.Point(40, 24)
            lsEvents.Size = New System.Drawing.Size(120, 160)
            lsEvents.TabIndex = 0
            lsEvents.AddOnSelectedIndexChanged(New System.EventHandler(AddressOf Me.lsEvents_SelectedIndexChanged))
            
            Seed.Location = New System.Drawing.Point(144, 224)
            Seed.Size = New System.Drawing.Size(80, 32)
            Seed.TabIndex = 2
            Seed.Text = "Seed"
            Seed.AddOnClick(New System.EventHandler(AddressOf Me.Seed_Click))
            
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Seed Swimmers"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(440, 269)
            Me.AddOnClick(New System.EventHandler(AddressOf Me.Seed_Click))
            
            lsSwimmers.Location = New System.Drawing.Point(208, 8)
            lsSwimmers.Size = New System.Drawing.Size(208, 199)
            lsSwimmers.TabIndex = 1
            
            Me.Controls.Add(Seed)
            Me.Controls.Add(lsSwimmers)
            Me.Controls.Add(lsEvents)
            
        End Sub
        
        
        Protected Sub lsEvents_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
            seed_click(sender, e)
        End Sub
        
        Protected Sub Seed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
            
            Dim i As Integer
            Dim sd As Seeding
            Dim swmrs As ArrayList
            Dim sw As Swimmer
            Dim sline As String
            Dim lsCol As ArrayList
            
            i = lsEvents.SelectedIndex
            
            If i >= 0 Then
                sd = CType(Seedings(i), seeding)
                sd.seed()
                swmrs = sd.getSeeding
                lsSwimmers.Items.Clear()
                lsCol = New ArrayList()
                
                For i = 0 To swmrs.count - 1
                    sw = CType(swmrs(i), swimmer)
                    sline = Str$(sw.getHeat) + Str$(sw.getLane) + " " + sw.getName
                    If (sline.length < 20) Then
                        sline = sline + space(20 - sline.length)
                    End If
                    sline = sline + sw.getClub + " " + sw.getTime.toString
                    lsSwimmers.Items.Add(sline)
                Next i
                
            End If
        End Sub
        
        
    End Class
    

