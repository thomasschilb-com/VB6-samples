Imports System
Imports System.ComponentModel
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility




Public Class TimedFinalEvent
    Inherits Events
    
    Public Sub New(ByVal Filename As String, ByVal lanes As Integer)
        MyBase.New(Filename, lanes)
    End Sub
    '------    
    Public Overrides Function getSeeding() As Seeding
        Dim sd As Seeding
        'create seeding and execute it
        sd = New StraightSeeding(swmmers, numLanes)
        sd.seed()
        getSeeding = sd
    End Function
    '------    
    Public Overrides Function isFinal() As Boolean
        isFinal = False
    End Function
    '------
    Public Overrides Function isPrelim() As Boolean
        isPrelim = False
    End Function
    '------
    Public Overrides Function isTimedFinal() As Boolean
        isTimedFinal = True
    End Function
    
End Class

