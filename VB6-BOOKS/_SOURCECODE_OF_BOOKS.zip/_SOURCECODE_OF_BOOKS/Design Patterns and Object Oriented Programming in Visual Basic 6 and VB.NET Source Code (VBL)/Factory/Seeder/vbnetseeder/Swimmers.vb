Imports System.Collections
Public Class Swimmers
    Inherits ArrayList
    Public Function swm(ByVal i As Integer) As Swimmer
        Return CType(MyBase.Item(i), Swimmer)
    End Function
End Class
