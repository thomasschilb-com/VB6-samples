Imports System
Imports System.ComponentModel


Public Class Prelimevent
    Inherits Events
    
    Dim sd As Seeding
    
    Public Overrides Function getSeeding() As Seeding
        Return New CircleSeeding(swmmers, numLanes)
    End Function
    
    
    Public Overrides Function isFinal() As Boolean
        isFinal = False
    End Function
    
    Public Overrides Function isPrelim() As Boolean
        isPrelim = True
    End Function
    
    Public Overrides Function isTimedFinal() As Boolean
        isTimedFinal = False
    End Function
    
    Public Sub New(ByVal Filename As String, ByVal lanes As Integer)
        MyBase.New(Filename, lanes)
        numLanes = lanes
    End Sub
    
End Class

