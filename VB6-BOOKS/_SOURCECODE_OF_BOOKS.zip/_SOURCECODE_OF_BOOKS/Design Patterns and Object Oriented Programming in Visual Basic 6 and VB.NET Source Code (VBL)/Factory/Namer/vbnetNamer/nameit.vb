Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility

Namespace WinNamer

    Public Class Win32Form1
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private txLast As System.WinForms.TextBox
                Private txFirst As System.WinForms.TextBox
        Private Label2 As System.WinForms.Label
        Private Label1 As System.WinForms.Label
                Private btClear As System.WinForms.Button
                Private btCompute As System.WinForms.Button
                Private txName As System.WinForms.TextBox
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New Win32Form1())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.txName = New System.WinForms.TextBox
            Me.txFirst = New System.WinForms.TextBox
            Me.Label2 = New System.WinForms.Label
            Me.Label1 = New System.WinForms.Label
            Me.btClear = New System.WinForms.Button
            Me.btCompute = New System.WinForms.Button
            Me.txLast = New System.WinForms.TextBox

            txName.Location = New System.Drawing.Point(32, 16)
            txName.Text = ""
            txName.TabIndex = 0
            txName.Size = New System.Drawing.Size(208, 24)

            txFirst.Location = New System.Drawing.Point(128, 104)
            txFirst.Text = ""
            txFirst.TabIndex = 5
            txFirst.Size = New System.Drawing.Size(88, 24)

            Label2.Location = New System.Drawing.Point(16, 152)
            Label2.Text = "Last name"
            Label2.Size = New System.Drawing.Size(80, 24)
            Label2.ForeColor = ctype(System.Drawing.Color.FromARGB(0, 0, 192), System.Drawing.Color)
            Label2.TabIndex = 4

            Label1.Location = New System.Drawing.Point(16, 112)
            Label1.Text = "First name"
            Label1.Size = New System.Drawing.Size(64, 16)
            Label1.ForeColor = ctype(System.Drawing.Color.FromARGB(0, 0, 192), System.Drawing.Color)
            Label1.TabIndex = 3

            btClear.Location = New System.Drawing.Point(168, 224)
            btClear.Size = New System.Drawing.Size(56, 24)
            btClear.TabIndex = 2
            btClear.Text = "Clear"
            btClear.AddOnClick(New System.EventHandler(AddressOf Me.btClear_Click))


            btCompute.Location = New System.Drawing.Point(88, 224)
            btCompute.Size = New System.Drawing.Size(56, 24)
            btCompute.TabIndex = 1
            btCompute.Text = "Compute"
            btCompute.AddOnClick(New System.EventHandler(AddressOf Me.btCompute_Click))

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Name split window"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0

            txLast.Location = New System.Drawing.Point(128, 152)
            txLast.Text = ""
            txLast.TabIndex = 6
            txLast.Size = New System.Drawing.Size(88, 24)

            Me.Controls.Add(txLast)
            Me.Controls.Add(txFirst)
            Me.Controls.Add(Label2)
            Me.Controls.Add(Label1)
            Me.Controls.Add(btClear)
            Me.Controls.Add(btCompute)
            Me.Controls.Add(txName)

        End Sub

Protected Sub btCompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    dim nm as string
    dim i as integer
    nm = txname.text
    Dim Nmer as NameClass
    Nmer = new NameFactory().getNamer(nm)
     
    txLast.text = nmer.getLast()
    txFirst.text = nmer.getFirst()
    
End Sub

Protected Sub btClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
   txName.text = ""
   txFirst.text =""
   txLast.text = ""
End Sub
End Class

End Namespace
