
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility


Public Class NameClass
    Protected Lname, Frname As String
    
    Public Function getFirst() As String
        Return Frname
    End Function
    
    Public Function getLast() As String
        Return Lname
    End Function
End Class
