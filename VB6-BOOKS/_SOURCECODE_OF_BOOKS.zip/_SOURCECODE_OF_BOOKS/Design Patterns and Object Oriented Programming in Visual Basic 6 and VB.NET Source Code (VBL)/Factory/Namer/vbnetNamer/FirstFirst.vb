
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility




Public Class FirstFirst
    Inherits NameClass
    Public Sub New(ByVal nm As String)
        Dim i As Integer
        i = nm.indexOf(" ")
        If i > 0 Then
            Frname = nm.substring(0, i).trim()
            Lname = nm.substring(i + 1).trim()
        Else
            Frname = ""
            LName = nm
        End If
    End Sub
End Class


