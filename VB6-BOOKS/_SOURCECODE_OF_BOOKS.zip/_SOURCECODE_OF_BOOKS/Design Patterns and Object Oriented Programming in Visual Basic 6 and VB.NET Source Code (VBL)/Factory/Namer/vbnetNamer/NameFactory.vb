
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility


Public Class NameFactory
    
    Public Function getNamer( _
        ByVal nm As String) As NameClass
        Dim i As Integer
        
        i = nm.indexOf(",")
        If i > 0 Then
            Return New LastFirst(nm)
        Else
            Return New FirstFirst(nm)
        End If
    End Function
End Class

