Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form

    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent

        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btCompute As System.WinForms.Button
    Private WithEvents txLast As System.WinForms.TextBox
    Private WithEvents txFirst As System.WinForms.TextBox
    Private WithEvents Label2 As System.WinForms.Label
    Private WithEvents Label1 As System.WinForms.Label
    Private WithEvents txName As System.WinForms.TextBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txFirst = New System.WinForms.TextBox()
        Me.txName = New System.WinForms.TextBox()
        Me.txLast = New System.WinForms.TextBox()
        Me.Label2 = New System.WinForms.Label()
        Me.Label1 = New System.WinForms.Label()
        Me.btCompute = New System.WinForms.Button()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        txFirst.Location = New System.Drawing.Point(136, 96)
        txFirst.TabIndex = 3
        txFirst.Size = New System.Drawing.Size(104, 20)
        
        txName.Location = New System.Drawing.Point(48, 32)
        txName.TabIndex = 0
        txName.Size = New System.Drawing.Size(176, 20)
        
        txLast.Location = New System.Drawing.Point(136, 128)
        txLast.TabIndex = 4
        txLast.Size = New System.Drawing.Size(104, 20)
        
        Label2.Location = New System.Drawing.Point(48, 128)
        Label2.Text = "Last"
        Label2.Size = New System.Drawing.Size(72, 16)
        Label2.TabIndex = 2
        
        Label1.Location = New System.Drawing.Point(48, 96)
        Label1.Text = "First"
        Label1.Size = New System.Drawing.Size(72, 16)
        Label1.TabIndex = 1
        
        btCompute.Location = New System.Drawing.Point(88, 176)
        btCompute.Size = New System.Drawing.Size(80, 24)
        btCompute.TabIndex = 5
        btCompute.Text = "Compute"
        Me.Text = "Get names"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(btCompute)
        Me.Controls.Add(txLast)
        Me.Controls.Add(txFirst)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Label1)
        Me.Controls.Add(txName)
    End Sub
    
#End Region

    Protected Sub btCompute_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim nm As String
        Dim i As Integer
        nm = txname.text
        Dim Nmer As NameClass
        Nmer = New NameFactory().getNamer(nm)
        
        txLast.text = nmer.getLast()
        txFirst.text = nmer.getFirst()
    End Sub
    
End Class
