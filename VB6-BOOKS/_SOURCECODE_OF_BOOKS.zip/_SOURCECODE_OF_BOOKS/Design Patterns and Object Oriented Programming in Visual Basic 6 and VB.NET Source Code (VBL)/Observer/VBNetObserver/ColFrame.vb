Imports System.Drawing
Imports System.WinForms


Imports System.ComponentModel


Public Class ColFrame
    Inherits System.WinForms.Form
    Implements Observer
    Private colname As String
    Dim fnt As Font
    Dim bBrush As SolidBrush
    '-----
    Public Sub New(ByVal subj As Subject)
        MyBase.New()
        subj.registerInterest(Me)
        ColFrame = Me
        InitializeComponent()
        fnt = New Font("arial", 18, Drawing.FontStyle.Bold)
        bbrush = New SolidBrush(Color.Black)
        AddHandler Pic.Paint, New PaintEventHandler(AddressOf painthandler)
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    
    Dim WithEvents ColFrame As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pic = New System.WinForms.PictureBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Pic.Location = New System.Drawing.Point(16, 32)
        Pic.Size = New System.Drawing.Size(248, 184)
        Pic.TabIndex = 0
        Pic.TabStop = False
        
        Me.Text = "ColFrame"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(Pic)
    End Sub
    
#End Region
    '-----
    Public Sub sendNotify(ByVal mesg As System.String) Implements VBNetObserver.Observer.sendNotify
        colname = mesg
        Select Case mesg.ToLower
            Case "red"
                pic.BackColor = color.Red '
            Case "blue"
                pic.BackColor = color.Blue
            Case "green"
                pic.BackColor = color.Green
        End Select
    End Sub
    '-----
    Private Sub paintHandler(ByVal sender As Object, ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        g.DrawString(colname, fnt, bbrush, 20, 40)
    End Sub
End Class
