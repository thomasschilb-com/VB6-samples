Imports System.Drawing
Imports System.WinForms


Imports System.ComponentModel


Public Class listObs
    Inherits System.WinForms.Form
    Implements Observer
    Public Sub New(ByVal subj As Subject)
        MyBase.New()       
        listObs = Me
        InitializeComponent()
        subj.registerInterest(Me)
    End Sub
    '-----
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents lsColors As System.WinForms.ListBox
    
    Dim WithEvents listObs As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsColors = New System.WinForms.ListBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsColors.Location = New System.Drawing.Point(32, 24)
        lsColors.Size = New System.Drawing.Size(224, 184)
        lsColors.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!)
        lsColors.TabIndex = 0
        
        Me.Text = "listObs"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(lsColors)
    End Sub
    
#End Region
    '-----
    Public Sub sendNotify(ByVal mesg As System.String) Implements Observer.sendNotify
        lscolors.Items.Add(mesg)
    End Sub
End Class
