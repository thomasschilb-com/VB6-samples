Public Interface Observer
    Sub sendNotify(ByVal mesg As String)
End Interface
