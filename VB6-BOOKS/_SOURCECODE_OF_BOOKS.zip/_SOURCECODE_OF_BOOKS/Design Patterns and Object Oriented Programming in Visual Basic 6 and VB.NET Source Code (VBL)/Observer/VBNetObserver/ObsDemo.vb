Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class Form1
    Inherits System.WinForms.Form
    Implements Subject
    '-----
    Private observers As ArrayList
    Public Sub New()
        MyBase.New
        Form1 = Me
        InitializeComponent()
        Dim evh As EventHandler = New EventHandler(AddressOf radioHandler)
        AddHandler opRed.Click, evh
        AddHandler opblue.Click, evh
        AddHandler opgreen.Click, evh
        observers = New ArrayList()
        Dim lscol As New listObs(Me)
        lscol.Show()
        Dim frcol As New ColFrame(Me)
        frcol.Show()
    End Sub
    '-----
    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 
    '-----
#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents opGreen As System.WinForms.RadioButton
    Private WithEvents opBlue As System.WinForms.RadioButton
    Private WithEvents opRed As System.WinForms.RadioButton
    
    Private WithEvents rdblue As System.WinForms.GroupBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.opGreen = New System.WinForms.RadioButton()
        Me.rdblue = New System.WinForms.GroupBox()
        Me.opRed = New System.WinForms.RadioButton()
        Me.opBlue = New System.WinForms.RadioButton()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        opGreen.Location = New System.Drawing.Point(16, 72)
        opGreen.Text = "Green"
        opGreen.Size = New System.Drawing.Size(72, 16)
        opGreen.ForeColor = CType(System.Drawing.Color.FromARGB(0, 64, 0), System.Drawing.Color)
        opGreen.TabIndex = 2
        
        rdblue.Location = New System.Drawing.Point(48, 40)
        rdblue.TabIndex = 0
        rdblue.TabStop = False
        rdblue.Text = "Colors"
        rdblue.Size = New System.Drawing.Size(120, 112)
        
        opRed.Location = New System.Drawing.Point(16, 24)
        opRed.Text = "Red"
        opRed.Size = New System.Drawing.Size(80, 16)
        opRed.ForeColor = System.Drawing.Color.Red
        opRed.TabIndex = 0
        
        opBlue.Location = New System.Drawing.Point(16, 48)
        opBlue.Text = "Blue"
        opBlue.Size = New System.Drawing.Size(88, 16)
        opBlue.ForeColor = System.Drawing.SystemColors.ActiveCaption
        opBlue.TabIndex = 1
        Me.Text = "Observer demo"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(240, 221)
        
        Me.Controls.Add(rdblue)
        rdblue.Controls.Add(opGreen)
        rdblue.Controls.Add(opBlue)
        rdblue.Controls.Add(opRed)
    End Sub
    
#End Region
    Protected Sub RadioHandler(ByVal sender As Object, ByVal e As EventArgs)
        Dim i As Integer
        Dim rbut As RadioButton = CType(sender, RadioButton)
        For i = 0 To observers.Count - 1
            Dim obs As Observer = CType(observers(i), observer)
            obs.sendNotify(rbut.Text)
        Next i
    End Sub
    '-----
    Public Sub registerInterest(ByVal obs As VBNetObserver.Observer) Implements VBNetObserver.Subject.registerInterest
        observers.Add(obs)
    End Sub
End Class
