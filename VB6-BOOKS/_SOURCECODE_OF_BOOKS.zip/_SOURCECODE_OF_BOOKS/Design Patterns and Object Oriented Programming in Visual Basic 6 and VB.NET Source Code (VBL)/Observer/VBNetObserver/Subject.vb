'-----
Public Interface Subject
    Sub registerInterest(ByVal obs As observer)
End Interface
