Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class SpoolerException
    Inherits Exception
    Private mesg As String
    '---------  
    Public Sub New()
        MyBase.New()
        mesg = "Only one spooler instance allowed"
    End Sub
    '---------
    Public Overrides ReadOnly Property Message() As String
        Get
            Message = mesg
        End Get    
    End Property    
End Class
