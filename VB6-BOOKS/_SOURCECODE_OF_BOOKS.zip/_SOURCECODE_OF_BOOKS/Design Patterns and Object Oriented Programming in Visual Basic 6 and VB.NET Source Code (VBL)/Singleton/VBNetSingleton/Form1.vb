Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private Spl As Spooler
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent

        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btGetSpooler As System.WinForms.Button
    Private WithEvents Print As System.WinForms.Button
    Private WithEvents TextBox1 As System.WinForms.TextBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox1 = New System.WinForms.TextBox()
        Me.btGetSpooler = New System.WinForms.Button()
        Me.Print = New System.WinForms.Button()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        TextBox1.Location = New System.Drawing.Point(24, 40)
        TextBox1.Text = " "
        TextBox1.TabIndex = 0
        TextBox1.Size = New System.Drawing.Size(200, 20)
        
        btGetSpooler.Location = New System.Drawing.Point(72, 72)
        btGetSpooler.Size = New System.Drawing.Size(104, 32)
        btGetSpooler.TabIndex = 2
        btGetSpooler.Text = "Get spooler"
        
        Print.Location = New System.Drawing.Point(72, 120)
        Print.Size = New System.Drawing.Size(104, 32)
        Print.TabIndex = 1
        Print.Text = "Print"
        Me.Text = "Form1"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(btGetSpooler)
        Me.Controls.Add(Print)
        Me.Controls.Add(TextBox1)
    End Sub
    
#End Region
    
    Protected Sub Print_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            spl.Print("Hi there")
        Catch ex As Exception
            ErrorBox("No spooler allocated")
        End Try
    End Sub
    '--------
    Private Sub ErrorBox(ByVal mesg As String)
        MessageBox.Show(mesg, "Spooler Error", Messagebox.IconError)
    End Sub
    '------
    Protected Sub btGetSpooler_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            spl = Spooler.getSpooler
            TextBox1.text = "Got spooler"
        Catch ex As Exception
            ErrorBox("Spooler already allocated")
        End Try   
    End Sub
    
End Class
