Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class SpoolerDemo
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
        Private TextBox1 As System.WinForms.TextBox
                Private Print As System.WinForms.Button
                Private btGetSpooler As System.WinForms.Button
        Private Spl as Spooler        
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New SpoolerDemo())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.TextBox1 = New System.WinForms.TextBox
            Me.btGetSpooler = New System.WinForms.Button
            Me.Print = New System.WinForms.Button

            TextBox1.Location = New System.Drawing.Point(32, 56)
            TextBox1.Text = " "
            TextBox1.TabIndex = 2
            TextBox1.Size = New System.Drawing.Size(184, 24)

            btGetSpooler.Location = New System.Drawing.Point(40, 208)
            btGetSpooler.Size = New System.Drawing.Size(72, 24)
            btGetSpooler.TabIndex = 0
            btGetSpooler.Text = "Get spooler"
            btGetSpooler.AddOnClick(New System.EventHandler(AddressOf Me.btGetSpooler_Click))

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Spooler Demo"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0

            Print.Location = New System.Drawing.Point(152, 208)
            Print.Size = New System.Drawing.Size(72, 24)
            Print.TabIndex = 1
            Print.Text = "Print"
            Print.AddOnClick(New System.EventHandler(AddressOf Me.Print_Click))

            Me.Controls.Add(TextBox1)
            Me.Controls.Add(Print)
            Me.Controls.Add(btGetSpooler)

        End Sub

Protected Sub btGetSpooler_Click(ByVal sender As System.Object, ByVal ev As System.EventArgs) 
Try  
  spl = Spooler.getSpooler 
  TextBox1.text ="Got spooler"
catch e as Exception
     ErrorBox( "Spooler already allocated")
End Try  
End Sub
'--------
Protected Sub Print_Click(ByVal sender As System.Object, ByVal ev As System.EventArgs) 
 try     
      spl.Print("Hi there")
 catch e as Exception     
    ErrorBox( "No spooler allocated")
 end Try   
End Sub
'--------
Private Sub ErrorBox(mesg as String)
 MessageBox.Show( mesg, "Spooler Error", Messagebox.IconError)
End Sub
  
End Class

