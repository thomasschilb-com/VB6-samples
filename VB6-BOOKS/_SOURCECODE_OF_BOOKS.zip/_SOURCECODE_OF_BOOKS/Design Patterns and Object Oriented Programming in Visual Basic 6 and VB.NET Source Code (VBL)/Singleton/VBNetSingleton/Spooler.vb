Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Spooler
    Private Shared Spool_counter As Integer
    Private Shared glbSpooler As Spooler
    Private legalInstance As Boolean
    '-----
    Private Sub New()
        MyBase.New()
        
        If spool_counter = 0 Then   'create and save one instance
            glbSpooler = Me         'save it
            spool_counter = spool_counter + 1   'count it
            legalInstance = True
        Else
            legalInstance = False
            Throw New SpoolerException()
        End If      
    End Sub
    '-----
    Public Shared Function getSpooler() As Spooler
        Try
            glbSpooler = New Spooler()
        Catch e As Exception
            Throw e             'pass on to calling program
        Finally
            getSpooler = glbSpooler  'or return the legal one    
        End Try
    End Function
    '-----
    Public Sub Print(ByVal str As String)
        If legalInstance Then
            MessageBox.Show(str)
        Else
            Throw New SpoolerException()
        End If
    End Sub
    '-----
End Class