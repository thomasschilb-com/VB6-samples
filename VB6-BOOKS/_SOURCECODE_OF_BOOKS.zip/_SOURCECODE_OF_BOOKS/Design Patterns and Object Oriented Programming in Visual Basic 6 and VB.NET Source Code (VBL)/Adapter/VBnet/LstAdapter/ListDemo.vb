Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections
Imports VBPatterns


    Public Class ListDemo
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private Moveit As System.WinForms.Button
                Private lsNames As System.WinForms.ListBox
                Private lsKids As System.WinForms.ListBox
                Private lsAdapter, ksAdapter as ListAdapter
                Private Swimmers as ArrayList
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
        lsAdapter  = new ListAdapter(lsNames)
        ksAdapter = new ListAdapter(lsKids)
        Swimmers = new ArrayList
        ReadFile

        End Sub
        
       private sub ReadFile
        Dim s As String
        DIm sw as Swimmer
        Dim fl as New vbFile("swimmers.txt")
          fl.openForRead
          s = fl.readLine
          while not fl.fEof
            sw = new Swimmer(s) 
            swimmers.add(sw)
            ksAdapter.addItem(sw.getName)
            s = fl.readLine
          end while
        End Sub
 


        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New ListDemo())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.lsNames = New System.WinForms.ListBox
            Me.lsKids = New System.WinForms.ListBox
            Me.Moveit = New System.WinForms.Button

            lsNames.Location = New System.Drawing.Point(272, 32)
            lsNames.Size = New System.Drawing.Size(168, 186)
            lsNames.TabIndex = 1

            lsKids.Location = New System.Drawing.Point(32, 32)
            lsKids.Size = New System.Drawing.Size(168, 186)
            lsKids.TabIndex = 0

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "ListDemo"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(496, 277)

            Moveit.Location = New System.Drawing.Point(216, 80)
            Moveit.Size = New System.Drawing.Size(40, 24)
            Moveit.TabIndex = 2
            Moveit.Text = "-->"
            Moveit.AddOnClick(New System.EventHandler(AddressOf Me.Moveit_Click))

            Me.Controls.Add(Moveit)
            Me.Controls.Add(lsNames)
            Me.Controls.Add(lsKids)

        End Sub

Protected Sub Moveit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
       Dim i as integer
  Dim sw as Swimmer
  i = ksAdapter.ListIndex
  sw = CTYpe(swimmers(i), Swimmer)
  lsadapter.addText(sw)
End Sub

    
    End Class


