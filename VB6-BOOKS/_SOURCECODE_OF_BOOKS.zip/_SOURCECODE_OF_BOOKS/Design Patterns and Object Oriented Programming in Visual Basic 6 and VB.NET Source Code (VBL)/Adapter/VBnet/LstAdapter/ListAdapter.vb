Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class ListAdapter
    'Adapter for ListBox emulating some of
    'the methods of the VB6 list box.
    Private List As ListBox         'instance of list box
    Private tabChar As String
    '--------
    Public Sub New(ByVal ls As ListBox)
        List = ls
        tabChar = Convert.ToChar(9)
        tabchar = 9.toChar
    End Sub
    '--------
    Public Sub addItem(ByVal s As String)
        list.Items.Add(s)   'add into list box
    End Sub
    '--------
    Public Function ListIndex() As Integer
        Return list.SelectedIndex     'get list index
    End Function
    '--------
    Public Sub addText(ByVal sw As Swimmer)
        list.Items.Add(sw.getname + tabChar + sw.getTime.toString)
    End Sub
    
End Class
