Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Data


Public Class GridAdapter
    Private dtable As DataTable
    Private Dgrid As DataGrid
    '-----   
    Public Sub New(ByVal grid As DataGrid)
        dtable = CType(grid.DataSource, DataTable)
        dgrid = grid
    End Sub
    '-----   
    
    Public Sub addText(ByVal sw As Swimmer)
        Dim scnt As String
        Dim row As DataRow
        
        row = dtable.NewRow
        row("Frname") = sw.getFirstName
        row(1) = sw.getLastName
        row(2) = sw.getAge  'This one is an integer
        dtable.Rows.Add(row)
        dtable.AcceptChanges()
    End Sub
    
End Class
