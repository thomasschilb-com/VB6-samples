Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class TreeAdapter
    
    Private Tree As TreeView
    Public Sub New(ByVal tr As TreeView)
        MyBase.New()
        Tree = tr
    End Sub
    Public Sub addText(ByVal sw As Swimmer)
        Dim scnt As String
        Dim nod As TreeNode
        
        nod = Tree.Nodes.add(sw.getName)
        nod.expandAll()
        nod.Nodes.add(sw.getTime.toString)
    End Sub
    
End Class
