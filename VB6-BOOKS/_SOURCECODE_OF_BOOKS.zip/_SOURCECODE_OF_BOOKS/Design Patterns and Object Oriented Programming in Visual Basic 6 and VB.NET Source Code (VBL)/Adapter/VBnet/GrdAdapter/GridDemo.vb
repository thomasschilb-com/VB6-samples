Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Data
Imports System.Collections
Imports VBPatterns

Namespace Win32Form1Namespace 

    Public Class GridDemo
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private Moveit As System.WinForms.Button
        Private Dgrid As System.WinForms.DataGrid
                Private lsKids As System.WinForms.ListBox
        Private Swimmers as Arraylist  
        Private dtable as DataTable
 
        Private gadapter as GridAdapter     
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
           gadapter = New GridAdapter(DGrid)
            Swimmers = new ArrayList
                ReadFile

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New GridDemo())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.Dgrid = New System.WinForms.DataGrid
            Me.lsKids = New System.WinForms.ListBox
            Me.Moveit = New System.WinForms.Button

            DGrid.BeginInit()

            Dgrid.Location = New System.Drawing.Point(192, 24)
            Dgrid.Size = New System.Drawing.Size(240, 168)
            Dgrid.PreferredColumnWidth = 30'DataGrid.AutoColumnSize
            Dgrid.DataMember = ""
            Dgrid.ForeColor = System.Drawing.SystemColors.WindowText
            Dgrid.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption
            Dgrid.TabIndex = 1
            Dgrid.BackColor = System.Drawing.SystemColors.Window  
            DGrid.ColumnHeadersVisible = false
            DGrid.NavigationMode = DataGridNavigationModes.None
	    'Dim a__1() As System.WinForms.DataGridTable
            'Dgrid.GridTables.All = a__1
            dtable = new DataTable("Kids")
            dtable.minimumCapacity=100
            dtable.CaseSensitive = false
            
            Dim column as DataColumn
            column =   new DataColumn("Frname", System.Type.GetType("System.String") )
            
            dtable.Columns.add( column)
            column =   new DataColumn("Lname", System.Type.GetType("System.String") )
            
            dtable.Columns.add( column)
            column =   new DataColumn("Age", System.Type.GetType("System.Int16") )
            
            dtable.Columns.add( column)  
            
        
            Dgrid.DataSource = dtable
            'DGrid.readOnly = true
            lsKids.Location = New System.Drawing.Point(24, 24)
            lsKids.Size = New System.Drawing.Size(128, 173)
            lsKids.TabIndex = 0

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Grid adapter"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(440, 261)

            Moveit.Location = New System.Drawing.Point(152, 64)
            Moveit.Size = New System.Drawing.Size(32, 24)
            Moveit.TabIndex = 2
            Moveit.Text = "-->"
            Moveit.AddOnClick(New System.EventHandler(AddressOf Me.Moveit_Click))

            Me.Controls.Add(Moveit)
            Me.Controls.Add(Dgrid)
            Me.Controls.Add(lsKids)

            Dgrid.EndInit()
                    End Sub

       private sub ReadFile
        Dim s As String
        DIm sw as Swimmer
        Dim fl as New vbFile("swimmers.txt")
          fl.openForRead
          s = fl.readLine
          while not fl.fEof
            sw = new Swimmer(s) 
            swimmers.add(sw)
            lsKids.items.add(sw.getName)
            s = fl.readLine
          end while
        End Sub
 

Protected Sub Moveit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    Dim i as integer
  Dim sw as Swimmer
  i = lsKids.SelectedIndex
   sw = CTYpe(swimmers(i), Swimmer)
   gadapter.addText(sw)
   dgrid.populatecolumns
        End Sub

    
    End Class

End Namespace
