Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private Swimmers As Arraylist
    Private dtable As DataTable
    Private gadapter As GridAdapter
    
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        
        Swimmers = New ArrayList()
        dtable = New DataTable("Kids")
        
        Dim column As DataColumn
        column = New DataColumn("Frname", System.Type.GetType("System.String"))
        
        dtable.Columns.add(column)
        column = New DataColumn("Lname", System.Type.GetType("System.String"))
        
        dtable.Columns.add(column)
        column = New DataColumn("Age", System.Type.GetType("System.Int16"))
        
        dtable.Columns.add(column)
        Dgrid.DataSource = dtable
        gadapter = New GridAdapter(DGrid)
        ReadFile()
        
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Moveit As System.WinForms.Button
    Private WithEvents DGrid As System.WinForms.DataGrid
    Private WithEvents lsKids As System.WinForms.ListBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsKids = New System.WinForms.ListBox()
        Me.DGrid = New System.WinForms.DataGrid()
        Me.Moveit = New System.WinForms.Button()
        
        DGrid.BeginInit()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsKids.Location = New System.Drawing.Point(16, 16)
        lsKids.Size = New System.Drawing.Size(144, 186)
        lsKids.TabIndex = 0
        
        DGrid.Location = New System.Drawing.Point(232, 40)
        DGrid.ReadOnly = True
        DGrid.CaptionVisible = False
        DGrid.Size = New System.Drawing.Size(192, 152)
        DGrid.ColumnHeadersVisible = False
        DGrid.DataMember = ""
        DGrid.TabIndex = 1
        DGrid.RowHeaderWidth = 3
        
        Moveit.Location = New System.Drawing.Point(168, 80)
        Moveit.Size = New System.Drawing.Size(48, 24)
        Moveit.TabIndex = 2
        Moveit.Text = "--->"
        
        Me.Text = "Grid adapter"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 273)
        
        Me.Controls.Add(Moveit)
        Me.Controls.Add(DGrid)
        Me.Controls.Add(lsKids)
        
        DGrid.EndInit()
    End Sub
    
#End Region
    
    Protected Sub Moveit_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim i As Integer
        Dim sw As Swimmer
        i = lsKids.SelectedIndex
        sw = CType(swimmers(i), Swimmer)
        gadapter.addText(sw)
        dgrid.populatecolumns()
    End Sub
    Private Sub ReadFile()
        Dim s As String
        Dim sw As Swimmer
        Dim fl As New vbFile("swimmers.txt")
        fl.openForRead()
        s = fl.readLine
        While Not fl.fEof
            sw = New Swimmer(s)
            swimmers.add(sw)
            lsKids.items.add(sw.getName)
            s = fl.readLine
        End While
    End Sub
    
End Class
