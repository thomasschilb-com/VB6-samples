Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private swimmers As ArrayList
    Private tadapter As TreeAdapter
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        swimmers = New ArrayList()
        tadapter = New TreeAdapter(trKids)
        ReadFile()
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Moveit As System.WinForms.Button
    Private WithEvents lsKids As System.WinForms.ListBox
    Private WithEvents trKids As System.WinForms.TreeView
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsKids = New System.WinForms.ListBox()
        Me.trKids = New System.WinForms.TreeView()
        Me.Moveit = New System.WinForms.Button()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsKids.Location = New System.Drawing.Point(8, 16)
        lsKids.Size = New System.Drawing.Size(144, 225)
        lsKids.TabIndex = 1
        
        trKids.Location = New System.Drawing.Point(224, 16)
        trKids.Size = New System.Drawing.Size(168, 224)
        trKids.TabIndex = 0
        
        Moveit.Location = New System.Drawing.Point(160, 88)
        Moveit.Size = New System.Drawing.Size(56, 24)
        Moveit.TabIndex = 2
        Moveit.Text = "--->"
        
        Me.Text = "Tree adapter"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 273)
        
        Me.Controls.Add(Moveit)
        Me.Controls.Add(lsKids)
        Me.Controls.Add(trKids)
    End Sub
    
#End Region
    
    Protected Sub Moveit_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim i As Integer
        Dim sw As Swimmer
        i = lsKids.SelectedIndex
        sw = CType(swimmers(i), Swimmer)
        tadapter.addText(sw)
        
    End Sub
    Private Sub ReadFile()
        Dim s As String
        Dim sw As Swimmer
        Dim fl As New vbFile("swimmers.txt")
        fl.openForRead()
        s = fl.readLine
        While Not fl.fEof
            sw = New Swimmer(s)
            swimmers.add(sw)
            lsKids.items.add(sw.getName)
            s = fl.readLine
        End While
    End Sub
    
End Class
