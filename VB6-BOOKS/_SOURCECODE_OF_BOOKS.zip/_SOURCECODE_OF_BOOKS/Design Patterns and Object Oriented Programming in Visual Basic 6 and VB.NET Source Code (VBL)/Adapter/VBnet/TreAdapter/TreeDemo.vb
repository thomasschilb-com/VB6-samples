Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections
Imports VBPatterns

Namespace Win32Form1Namespace 

    Public Class Win32Form1
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private btMove As System.WinForms.Button
                Private trKids As System.WinForms.TreeView
                Private lsKids As System.WinForms.ListBox
        
         private swimmers as ArrayList
         private tadapter as TreeAdapter
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call
           swimmers = New ArrayList
           tadapter = new TreeAdapter(trKids)
           ReadFile
        End Sub
        private sub ReadFile
        Dim s As String
        DIm sw as Swimmer
        Dim fl as New vbFile("swimmers.txt")
          fl.openForRead
          s = fl.readLine
          while not fl.fEof
            sw = new Swimmer(s) 
            swimmers.add(sw)
            lsKids.items.add(sw.getName)
            s = fl.readLine
          end while
        End Sub
        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New Win32Form1())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.lsKids = New System.WinForms.ListBox
            Me.trKids = New System.WinForms.TreeView
            Me.btMove = New System.WinForms.Button

            lsKids.Location = New System.Drawing.Point(16, 32)
            lsKids.Size = New System.Drawing.Size(152, 199)
            lsKids.TabIndex = 0

            trKids.Location = New System.Drawing.Point(224, 32)
            trKids.Text = "Kid tree"
            trKids.Size = New System.Drawing.Size(152, 200)
            trKids.TabIndex = 1

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Tree adapter"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(392, 277)
            Me.AddOnClick(New System.EventHandler(AddressOf Me.Win32Form1_Click))

            btMove.Location = New System.Drawing.Point(184, 80)
            btMove.Size = New System.Drawing.Size(32, 24)
            btMove.TabIndex = 2
            btMove.Text = "-->"
            btMove.AddOnClick(New System.EventHandler(AddressOf Me.btMove_Click))

            Me.Controls.Add(btMove)
            Me.Controls.Add(trKids)
            Me.Controls.Add(lsKids)

        End Sub

Protected Sub btMove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
  Dim i as integer
  Dim sw as Swimmer
  i = lsKids.SelectedIndex
   sw = CTYpe(swimmers(i), Swimmer)
   tadapter.addText(sw)
    
        End Sub

Protected Sub Win32Form1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    
        End Sub

    
    End Class

End Namespace
