Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class TreeAdapter
    'An adapter to use TreeView 
    'instead of list boxes
    Private Tree As TreeView    'instance of tree
    
    Public Sub New(ByVal tr As TreeView)
        Tree = tr
    End Sub
    '-------------
    Public Sub addText(ByVal sw As Swimmer)
        Dim scnt As String
        Dim nod As TreeNode
        'add a root node  
        nod = Tree.Nodes.add(sw.getName)
        
        'add a child node to it
        nod.Nodes.add(sw.getTime.toString)
        Tree.expandAll()
    End Sub
    
End Class
