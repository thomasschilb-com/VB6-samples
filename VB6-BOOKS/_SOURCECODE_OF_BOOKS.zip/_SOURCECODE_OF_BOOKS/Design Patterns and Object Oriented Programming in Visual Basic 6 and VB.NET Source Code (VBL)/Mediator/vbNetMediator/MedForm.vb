Imports system.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class MedForm
    Inherits System.WinForms.Form
    Private med As Mediator
    Public Sub New()
        MyBase.New()
        MedForm = Me
        med = New Mediator()
        'This call is required by the Win Form Designer.
        InitializeComponent()
        
        AddHandler btCopy.click, New System.EventHandler(AddressOf CommandHandler)
        AddHandler btClear.click, New System.EventHandler(AddressOf CommandHandler)
        AddHandler lsKids.SelectedIndexChanged, New System.EventHandler(AddressOf CommandHandler)
        'register remaining controls
        med.register(txName)
        med.register(lspicked)
        med.init()      'initialize mediator
        
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    Public Sub CommandHandler(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim cmd As Command = CType(sender, Command)
        cmd.Execute()
    End Sub
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private btClear As ClearButton
    Private btCopy As CopyButton
    'Private btClear As System.WinForms.Button
    'Private btCopy As System.WinForms.Button
    Private WithEvents txName As System.WinForms.TextBox
    Private WithEvents lsPicked As System.WinForms.ListBox
    'Private WithEvents lsKids As System.WinForms.ListBox
    Private lsKids As KidsListBox
    
    Dim WithEvents MedForm As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        'Me.lsKids = New System.WinForms.ListBox()
        Me.lsKids = New KidsListBox(med)
        Me.txName = New System.WinForms.TextBox()
        'Me.btClear = New System.WinForms.Button()
        Me.btClear = New ClearButton(med)
        Me.lsPicked = New System.WinForms.ListBox()
        'Me.btCopy = New System.WinForms.Button()
        Me.btCopy = New CopyButton(med)
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsKids.Location = New System.Drawing.Point(8, 64)
        lsKids.Size = New System.Drawing.Size(128, 160)
        lsKids.TabIndex = 0
        
        txName.Location = New System.Drawing.Point(8, 16)
        txName.TabIndex = 2
        txName.Size = New System.Drawing.Size(136, 20)
        
        btClear.Location = New System.Drawing.Point(248, 16)
        btClear.Size = New System.Drawing.Size(56, 24)
        btClear.TabIndex = 4
        btClear.Text = "Clear"
        
        lsPicked.Location = New System.Drawing.Point(184, 64)
        lsPicked.Size = New System.Drawing.Size(128, 160)
        lsPicked.TabIndex = 1
        
        btCopy.Location = New System.Drawing.Point(160, 16)
        btCopy.Size = New System.Drawing.Size(56, 24)
        btCopy.TabIndex = 3
        btCopy.Text = "Copy"
        Me.Text = "Mediator in VBnet"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 261)
        
        Me.Controls.Add(btClear)
        Me.Controls.Add(btCopy)
        Me.Controls.Add(txName)
        Me.Controls.Add(lsPicked)
        Me.Controls.Add(lsKids)
    End Sub
    
#End Region
    
    
    
    
    
    
    
End Class
