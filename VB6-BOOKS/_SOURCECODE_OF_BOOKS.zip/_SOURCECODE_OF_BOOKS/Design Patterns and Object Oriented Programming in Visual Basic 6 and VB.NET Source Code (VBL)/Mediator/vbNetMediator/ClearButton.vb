Imports System.WinForms
Public Class ClearButton
    Inherits Button
    Implements Command
    Private med As Mediator
    Public Sub New(ByVal md As Mediator)
        MyBase.New()
        med = md
        med.register(Me)
    End Sub
    
    Public Sub Execute() Implements Command.Execute
        med.clearClicked()
    End Sub
End Class
