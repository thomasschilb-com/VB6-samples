Imports System.WinForms
Public Class CopyButton
    Inherits Button
    Implements Command
    Private med As Mediator
    'derived class for copy button
    '-----
    Public Sub New(ByVal md As Mediator)
        MyBase.New()
        med = md            'copy in Mediator
        med.register(Me)    'register button
    End Sub
    '-----
    'tell the Mediator we've been clicked
    Public Sub Execute() Implements Command.Execute
        med.copyClicked()
    End Sub    
End Class
