Imports System.WinForms
Public Class Mediator
    Private cpButton As CopyButton
    Private clrButton As ClearButton
    Private txkids As TextBox
    Private pkList As ListBox
    Private klist As KidsListBox
    Private kds As Kids
    '-----
    Public Overloads Sub register(ByVal cpb As CopyButton)
        cpbutton = cpb
    End Sub
    '-----
    Public Overloads Sub register(ByVal clr As ClearButton)
        clrbutton = clr
    End Sub
    '-----
    Public Overloads Sub register(ByVal kd As KidsListBox)
        klist = kd
    End Sub
    '-----
    Public Overloads Sub register(ByVal pick As ListBox)
        pklist = pick
    End Sub
    '-----
    Public Overloads Sub register(ByVal tx As TextBox)
        txkids = tx
    End Sub
    '-----
    Public Sub kidPicked()
        'copy text from list to textbox
        txkids.Text = klist.Text
        'copy button enabled
        cpbutton.Enabled = True
    End Sub
    '-----
    Public Sub copyClicked()
        'copy name to picked list
        pklist.Items.Add(txkids.Text)
        'clear button enabled
        clrbutton.Enabled = True
        klist.SelectedIndex = -1
    End Sub
    '-----
    Public Sub clearClicked()
        'disable buttons and clear list
        cpbutton.Enabled = False
        clrbutton.Enabled = False
        pklist.Items.Clear()
    End Sub
    '-----
    Public Sub init()
        Dim kd As Kid
        clearClicked()  'set to defaults
        'read in datafile and load list
        kds = New Kids(Application.StartUpPath & "\50free.txt")
        Dim iter As Iterator = kds.getIterator
        'Note we use the iterator here
        While (iter.hasMoreElements)
            kd = CType(iter.nextElement, Kid)
            klist.Items.Add(kd.getFrname + " " + kd.getlname)
        End While
    End Sub
End Class
