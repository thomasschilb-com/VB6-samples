Imports system.winforms
Public Class KidsListBox
    Inherits ListBox
    Implements Command
    Private med As Mediator
    Sub New(ByVal md As Mediator)
        MyBase.New()
        med = md
        med.register(Me)
    End Sub
    Public Sub Execute() Implements Command.Execute
        med.kidPicked()
    End Sub
End Class
