Public Class MultVar
    Inherits ParseVar
    
    Dim multVec As ArrayList
        
    Public Overloads Sub new(ByVal v1 As ParseObject, ByVal v2 As ParseObject)
        MyBase.New("")
        multVec = New arraylist()
        multVec.Add(v1)
        multVec.add(v2)
        type = MULTVAR
    End Sub
    Public Overloads Sub new()
        MyBase.New("")
        multVec = New arraylist()
        type = MULTVAR
    End Sub
    
    
    Public Sub add(ByVal v1 As ParseObject)
        multVec.Add(v1)
    End Sub
    Public Function getVector() As ArrayList
        Return multVec
    End Function
    
    
End Class
