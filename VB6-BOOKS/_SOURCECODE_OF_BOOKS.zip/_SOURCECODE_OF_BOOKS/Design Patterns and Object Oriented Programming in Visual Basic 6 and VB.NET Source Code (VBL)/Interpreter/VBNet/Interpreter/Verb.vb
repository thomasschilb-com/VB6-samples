Imports system.winforms
Public Class Verb
    Inherits ParseVerb
    Implements Command
    
    Protected data As Data
    Protected ptable As ListBox
    
    Public Sub new(ByVal s As String, ByVal dt As Data, ByVal pt As ListBox)
        MyBase.New(s, data, ptable)
        setdata(dt, pt)
    End Sub
    
    Public Overridable Sub Execute() Implements Command.Execute
        'nothing
    End Sub
    Public Sub setData(ByVal dt As Data, ByVal pt As listbox)
        data = dt
        ptable = pt
        
    End Sub
End Class
