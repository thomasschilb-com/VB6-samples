Public Class VarMultvarParse
    Inherits InterpChain
        
    Public Overrides Function interpret() As Boolean
        If (topStack(ParseObject.VAR, ParseObject.MULTVAR)) Then
            'reduce (Multvar Var) to Multvar
            Dim v As ParseVar = CType(stk.pop(), ParseVar)
            Dim mv As MultVar = CType(stk.pop(), MultVar)
            mv.add(v)
            stk.push(mv)
            Return True
        Else
            Return False
        End If
            
    End Function
    
End Class
