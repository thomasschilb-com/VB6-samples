Public MustInherit Class InterpChain
    Implements Chain
    
    Private nextChain As chain
    Protected stk As Stack
    '------------------------------------------
    Public Sub addtoChain(ByVal c As Chain) Implements Chain.addToChain
        nextChain = c    'next in chain of resp
    End Sub
    '------------------------------------------
    Public MustOverride Function interpret() As Boolean
    '------------------------------------------
    Public Function getChain() As Interpreter.Chain Implements Interpreter.Chain.getChain
        Return nextChain
    End Function
    '------------------------------------------
    Public Sub sendToChain(ByVal stk_ As Stack) Implements Chain.sendToChain
        stk = stk_
        If (Not interpret) Then  'interpret stack
            'Otherwise, pass request along chain
            nextChain.sendToChain(stk)
        End If
    End Sub
    '-----------------------------------------
    Protected Sub addArgsToVerb()
        Dim v As ParseObject = CType(stk.pop(), parseobject)
        Dim verb As ParseVerb = CType(stk.pop(), parseverb)
        verb.addArgs(v)
        stk.push(verb)
    End Sub
    '----------------------------------------
    Protected Function topStack(ByVal c1 As Integer, ByVal c2 As Integer) As Boolean
        Dim pobj1, pobj2 As ParseObject
        pobj1 = stk.top
        pobj2 = stk.nextTop
        Return (pobj1.get_Type() = c1) And (pobj2.get_Type() = c2)
    End Function
    
    
End Class
