Public Class VerbMultvarParse
    Inherits InterpChain
        
    Public Overrides Function interpret() As Boolean
        'reduce Verb MultVar to Verb containing vars
        If (topStack(ParseObject.MULTVAR, ParseObject.VERB)) Then
            
            addArgsToVerb()
            Return True
           else
            Return False
        End If
    End Function
    
    
End Class
