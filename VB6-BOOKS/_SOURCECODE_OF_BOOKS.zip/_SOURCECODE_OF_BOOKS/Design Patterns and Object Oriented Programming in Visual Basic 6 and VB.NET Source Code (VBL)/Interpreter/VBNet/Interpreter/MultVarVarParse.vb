Public Class MultVarVarParse
    
    Inherits InterpChain
    
    Public Overrides Function interpret() As Boolean
        Dim i As Integer
        'reduce MULTVAR VAR to MULTVAR
        If (topStack(ParseObject.MULTVAR, ParseObject.VAR)) Then
            
            Dim mv As multvar = New MultVar()
            Dim mvo As MultVar = CType(stk.pop(), MultVar)
            Dim v As ParseVar = CType(stk.pop(), parseVar)
            mv.add(v)
            Dim mvec As ArrayList = mvo.getVector()
            For i = 0 To mvec.Count - 1
                mv.add(CType(mvec(i), ParseVar))
            Next i
            stk.push(mv)
            
            Return True
            
        Else
            Return False
        End If
    End Function
    
End Class
