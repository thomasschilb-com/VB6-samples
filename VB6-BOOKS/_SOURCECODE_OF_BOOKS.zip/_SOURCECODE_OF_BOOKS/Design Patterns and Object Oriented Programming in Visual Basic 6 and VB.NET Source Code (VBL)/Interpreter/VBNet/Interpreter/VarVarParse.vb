Public Class VarVarParse
    Inherits InterpChain
    
    Public Overrides Function interpret() As Boolean
        If (topStack(ParseObject.VAR, ParseObject.VAR)) Then
            'reduce (Var Var) to Multvar
            Dim v As ParseVar = CType(stk.pop(), ParseVar)
            Dim v1 As ParseVar = CType(stk.pop(), ParseVar)
            Dim mv As MultVar = New MultVar(v1, v)
            stk.push(mv)
            Return True
        Else
            Return False
        End If
    End Function
End Class
