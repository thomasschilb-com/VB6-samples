Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private kdata As KidData
    Public Sub New()
        MyBase.New

        Form1 = Me
        
        'This call is required by the Win Form Designer.
        InitializeComponent
        kdata = New KidData("50free.txt")
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Compute As System.WinForms.Button
    Private WithEvents lsResults As System.WinForms.ListBox
    Private WithEvents txCommand As System.WinForms.TextBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsResults = New System.WinForms.ListBox()
        Me.Compute = New System.WinForms.Button()
        Me.txCommand = New System.WinForms.TextBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsResults.Location = New System.Drawing.Point(32, 88)
        lsResults.Size = New System.Drawing.Size(272, 186)
        lsResults.Font = New System.Drawing.Font("Courier New", 8!)
        lsResults.TabIndex = 1
        
        Compute.Location = New System.Drawing.Point(96, 48)
        Compute.Size = New System.Drawing.Size(96, 24)
        Compute.TabIndex = 2
        Compute.Font = New System.Drawing.Font("Microsoft Sans Serif", 10!)
        Compute.Text = "Compute"
        
        txCommand.Location = New System.Drawing.Point(8, 16)
        txCommand.Font = New System.Drawing.Font("Microsoft Sans Serif", 10!)
        txCommand.TabIndex = 0
        txCommand.Size = New System.Drawing.Size(264, 23)
        
        Me.Text = "Interpreter"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 293)
        
        Me.Controls.Add(Compute)
        Me.Controls.Add(lsResults)
        Me.Controls.Add(txCommand)
    End Sub
    
#End Region
       
    Protected Sub Compute_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim par As New Parser(txcommand.Text, kdata, lsresults)
        par.Execute()
    End Sub
    
    
End Class
