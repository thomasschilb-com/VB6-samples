Imports System.WinForms
Public Class Parser
    Implements Command
    Private stk As Stack
    Private actionList As ArrayList
    Private kdata As KidData
    Private dat As Data
    Private ptable As Listbox
    Private chn As Chain
    
    Public Sub new(ByVal line As String, ByVal k As kidData, ByVal pt As ListBox)
        stk = New Stack()
        setdata(k, pt)
        
        actionList = New arraylist()  'actions accumulate here
        buildStack(line)
        buildChain()    'construct interpreter chain
    End Sub
    '----------------------------------------
    Private Sub buildStack(ByVal line As String)
        'parse input tokens and build stack
        Dim tok As StringTokenizer = New StringTokenizer(line)
        While (tok.hasMoreElements())
            Dim token As ParseObject = tokenize(tok.nextToken())
            'Try
                stk.push(token)
            'Catch e As exception     'catches null
            'End Try
        End While
    End Sub
    '----------------------------------------
    Private Sub buildChain()
        chn = New VarVarParse()  'start of chain
        Dim vmvp As VarMultvarParse = New VarMultvarParse()
        chn.addtoChain(vmvp)
        Dim mvvp As MultvarVarParse = New MultvarVarParse()
        vmvp.addtoChain(mvvp)
        Dim vrvp As VerbMultvarParse = New VerbMultvarParse()
        mvvp.addtoChain(vrvp)
        Dim vvp As VerbVarParse = New VerbVarParse()
        vrvp.addtoChain(vvp)
        Dim va As VerbAction = New VerbAction(actionList)
        vvp.addtoChain(va)
    End Sub
    '----------------------------------------
    Public Sub setData(ByVal k As KidData, ByVal pt As listbox)
        dat = New Data(k.getData())
        ptable = pt
    End Sub
    '----------------------------------------
    'executes parse and interpretation of command line
    Public Sub Execute() Implements Command.Execute
        Dim i As Integer
        While (stk.hasMoreElements())
            chn.sendToChain(stk)
        End While
        'now execute the verbs
        For i = 0 To actionList.Count - 1
            Dim v As Verb = CType(actionList(i), Verb)
            v.setData(dat, ptable)
            v.Execute()
        Next i
    End Sub
    '--------------------------------------
    Protected Function tokenize(ByVal s As String) As ParseObject
        Dim obj As ParseObject
        Dim typ As Integer
        Try
            obj = getVerb(s)
            typ = obj.get_Type 'this will throw null exception
        Catch e As NullReferenceException
            obj = getVar(s)
        End Try
        
        Return obj
    End Function
    '----------------------------------------
    Protected Function getVerb(ByVal s As String) As ParseVerb
        Dim v As ParseVerb
        v = New ParseVerb(s, dat, ptable)
        If (v.isLegal()) Then
            
            Return v.getVerb(s)
        Else
            Return Nothing
        End If
    End Function
    '----------------------------------------
    Protected Function getVar(ByVal s As String) As ParseVar
        Dim v As ParseVar
        v = New ParseVar(s)
        If (v.isLegal()) Then
            Return v
            'Else
            '   Throw New nullexception()
        End If
    End Function
    
End Class
