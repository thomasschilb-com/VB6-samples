Imports System.WinForms
Public Class print
    Inherits verb
    
    Private kids As Kid()
    
    Public Sub new(ByVal s As String, ByVal kd As Data, ByVal pt As Listbox)
        MyBase.New(s, kd, pt)
        value = PRINT
    End Sub
    '-----------------------------------
    Public Overrides Sub Execute()
        
        Dim pline As String
        Dim i, j, k As Integer
        Dim tabc As Char
        Dim ic As Integer = 9
        tabc = ic.ToChar    'tab character for list box
        kids = data.getData()
        ptable.Items.Clear()
        
        For i = 0 To kids.Length - 1
            
            pline = ""    'line in output list
            'for each variable, get that kid's property
            For j = 0 To args.Count - 1
                
                Dim v As ParseVar = CType(args(j), parsevar)
                If TypeOf (v) Is MultVar Then   'if multiple get all of them
                    
                    Dim mv As MultVar = CType(v, multvar)
                    Dim vlist As ArrayList = mv.getVector()
                    For k = 0 To vlist.Count - 1
                        
                        Dim pv As ParseVar = CType(vlist(k), parsevar)
                        pline = pline + kids(i).getData(pv.getValue()).ToString + " "
                    Next k
                Else    'if single get that one
                    pline = pline + kids(i).getData(v.getValue()).ToString + " "
                End If
                
                ptable.Items.Add(pline)
                
            Next j
        Next i
        
        ptable.Refresh()
    End Sub
    
End Class
