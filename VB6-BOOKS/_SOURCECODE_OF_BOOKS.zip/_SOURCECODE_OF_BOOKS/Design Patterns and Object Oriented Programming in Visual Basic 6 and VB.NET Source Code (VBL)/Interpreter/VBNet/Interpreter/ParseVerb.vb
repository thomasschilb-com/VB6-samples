Imports System.WinForms
Public Class ParseVerb
    Inherits ParseObject
    Protected Const PRINT As Integer = 100
    Protected Const SORTBY As Integer = 110
    Protected Const THENBY As Integer = 120
    Protected args As ArrayList
    Protected kd As Data
    Protected pt As listbox
    '----------   
    Public Sub New(ByVal s As String, ByVal kd_ As Data, ByVal pt_ As ListBox)
        MyBase.New(-1, VERB)
        args = New Arraylist()
        s = s.ToLower()
        
        kd = kd_
        pt = pt_
        Select Case s
            Case "print"
                value = PRINT
            Case "sortby"
                value = SORTBY
        End Select
    End Sub
    '-----
    Public Function getVerb(ByVal s As String) As ParseVerb
        Select Case value
            Case PRINT
                Return New Print(s, kd, pt)
            Case SORTBY
                Return New Sort(s)
            Case Else
                Return Nothing
        End Select
    End Function
    '-----------------------------------
    Public Overloads Sub addArgs(ByVal mv As MultVar)
        args = mv.getVector()
    End Sub
    '-----------------------------------
    Public Overloads Sub addArgs(ByVal p As ParseObject)
        args.Add(p)
    End Sub
    '-----------------------------------
    Public Function isLegal() As Boolean
        Return (value >= 0)
    End Function
    
    
    
End Class
