Public Class VerbAction
    
    Inherits InterpChain
    Dim actionList As ArrayList
        
    Public Sub new(ByVal aList As ArrayList)
        MyBase.New()
        actionList = aList
    End Sub
    Public Overrides Function interpret() As Boolean
        'move top verb to action list
        If (stk.top().get_Type() = ParseObject.VERB) Then
            
            actionList.add(stk.pop())
            Return True
          else
            Return False
        End If
        
    End Function
    
End Class
