Public Class Data
    
        
    
    Dim kids() As Kid
    Public Sub new(ByVal kd() As Kid)
        MyBase.New()
        kids = kd
    End Sub
    Public Function getData() As kid()
        
        Return kids
    End Function
    
    
End Class
