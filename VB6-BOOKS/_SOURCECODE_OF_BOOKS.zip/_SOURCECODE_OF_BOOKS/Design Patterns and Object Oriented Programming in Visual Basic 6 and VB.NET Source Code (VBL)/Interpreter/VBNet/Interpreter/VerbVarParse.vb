Public Class VerbVarParse
    Inherits InterpChain
        
    Public Overrides Function interpret() As Boolean
        'reduce Verb Var to Verb containing vars
        If (topStack(ParseObject.VAR, ParseObject.VERB)) Then
            addArgsToVerb()
            Return True
            
        else
            Return False
        End If
        
    End Function
    
End Class
