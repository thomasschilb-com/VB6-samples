Public Class Kid

    Private frname, lname, club As String
    Private age As Integer
    Private time As Single
    '-------------------------------------
    Public Sub new(ByVal line As String)
        
        Dim tok As stringtokenizer = New stringTokenizer(line)
        
        Dim lnum As String = tok.nextToken()
        frname = tok.nextToken()
        lname = tok.nextToken()
        age = tok.nextToken().ToInt16
        club = tok.nextToken()
        time = tok.nextToken().ToSingle
    End Sub
    '-------------------------------
    Public Function getData(ByVal key As Integer) As Object
        
        Select Case key
            
        Case ParseVar.FRNAME
                Return frname
            Case ParseVar.LNAME
                Return lname
            Case ParseVar.CLUB
                Return club
            Case ParseVar.AGE
                Return age
            Case ParseVar.TIME
                Return time
            Case Else
                Return Nothing
        End Select
    End Function
    
    '--------------------------------
    Public Function getAge() As Integer
        Return age
    End Function
    Public Function getTime() As Single
        Return time
    End Function
    Public Function getFrname() As String
        Return frname
    End Function
    Public Function getLname() As String
        Return lname
    End Function
    Public Function getClub() As String
        Return club
    End Function
    
End Class
    