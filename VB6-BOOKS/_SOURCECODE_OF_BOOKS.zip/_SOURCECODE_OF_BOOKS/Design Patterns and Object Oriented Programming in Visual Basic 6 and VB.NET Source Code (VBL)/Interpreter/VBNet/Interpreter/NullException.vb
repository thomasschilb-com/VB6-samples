Public Class NullException
    Inherits Exception
    Public Sub new()
        MyBase.New("Null exception")
    End Sub
End Class
