Public Class ParseVar
    Inherits ParseObject
    Public Const FRNAME As Integer = 0
    Public Const LNAME As Integer = 1
    Public Const AGE As Integer = 2
    Public Const CLUB As Integer = 3
    Public Const TIME As Integer = 4
    Public Const tabMAX As Integer = 5
    
    Public Sub New(ByVal s As String)
        MyBase.New(-1, VAR)
        
        s = s.ToLower()
        Select Case s
            Case "frname"
                value = FRNAME
            Case "lname"
                value = LNAME
            Case "age"
                value = AGE
            Case "club"
                value = CLUB
            Case "time"
                value = TIME
        End Select
    End Sub
    '--------------------------------------
    Public Function isLegal() As Boolean
        Return (value >= 0)
    End Function
    
End Class
