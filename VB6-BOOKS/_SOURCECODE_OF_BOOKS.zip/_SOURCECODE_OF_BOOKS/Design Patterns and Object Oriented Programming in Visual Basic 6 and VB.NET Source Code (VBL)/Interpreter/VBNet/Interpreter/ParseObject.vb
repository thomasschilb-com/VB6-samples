Public Class ParseObject
    
    Public Const VERB As Integer = 1000
    Public Const VAR As Integer = 1010
    Public Const MULTVAR As Integer = 1020
    Protected value As Integer
    Protected type As Integer
        
    Public Sub new(ByVal val As Integer, ByVal typ As Integer)
        MyBase.New()
        value = val
        type = typ
    End Sub
    '-----
    Public Function getValue() As Integer
        Return value
    End Function
    '-----
    Public Function get_Type() As Integer
        Return type
    End Function
    
End Class
    