Imports System.Collections
Public Class Stack
    Private stk As arraylist
    'Private stk As System.Collections.Stack
    Public Sub new()
        MyBase.New()
        'stk = New System.Collections.Stack() 'New arraylist()
        stk = New arraylist()
    End Sub
    '----------------------------------------
    Public Sub push(ByVal obj As Object)
        stk.Add(obj)
        'stk.Push(obj)
    End Sub
    '----------------------------------------
    Public Function pop() As ParseObject
        
        'Dim obj As Object = stk.Pop  'CType(stk(stk.Count - 1), ParseObject)
        Dim obj As Object = CType(stk(stk.Count - 1), ParseObject)
        Dim i As Integer = stk.Count - 1
        stk.RemoveAt(i)
        Return CType(obj, ParseObject)
    End Function
    '----------------------------------------
    Public Function top() As ParseObject
        Dim obj As Object
        'obj = stk.Peek 'stk(stk.Count - 1)
        obj = stk(stk.Count - 1)
        Return CType(obj, ParseObject)
    End Function
    '----------------------------------------
    Public Function hasMoreElements() As Boolean
        Return (stk.Count > 0)
    End Function
    '----------------------------------------
    Public Function nextTop() As ParseObject
        Dim i As Integer
        i = stk.count
        If (i > 1) Then
            'Dim obj1 As Object = stk.Pop
            'Return CType(stk.Peek, ParseObject) 'stk(i - 2), ParseObject)
            Return CType(stk(i - 2), ParseObject)
            'stk.Push(obj1)
        Else
            Return Nothing
        End If
        
    End Function
    '---------------------------------------
    Public Sub pop2Push(ByVal p As ParseObject)
        Dim i As Integer
        i = stk.Count
        If (i >= 2) Then
            pop()
            pop()
            push(p)
        Else
            push(p)
        End If
    End Sub
    
End Class
