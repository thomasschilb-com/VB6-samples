Public Interface Chain
    Sub addToChain(ByVal c As Chain)
    Sub sendToChain(ByVal stk As Stack)
    Function getChain() As Chain
End Interface