Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class Boss
    Inherits Employee
    'A Boss implementation of AbstractEmployee
    'which allows subordinates
    
    Public Overloads Overrides Sub add(ByVal nm As String, ByVal salary As Single)
        Dim newEmp As AbstractEmployee
        newEmp = New Employee(nm, salary)
        subordinates.add(newEmp)
    End Sub
    '--------
    Public Overloads Overrides Sub add(ByVal emp As AbstractEmployee)
        subordinates.add(emp)
    End Sub
    '--------
    Public Overrides Function getChild(ByVal nm As String) As AbstractEmployee
        
        Dim found As Boolean
        Dim tEmp As AbstractEmployee
        Dim esub As IEnumerator
        
        If getName = nm Then
            Return Me
        Else
            found = False
            esub = subordinates.getEnumerator
            
            While Not found And esub.MoveNext
                'If subordinates.hasMoreElements Then
                tEmp = CType(esub.Current, AbstractEmployee)
                found = (tEmp.getName = nm)
                If Not found Then
                    If Not tEmp.isLeaf Then
                        tEmp = tEmp.getChild(nm)
                        found = (tEmp.getName = nm)
                    End If
                    
                End If
                'End If
                
            End While
            If found Then
                Return tEmp
            Else
                Return New Employee("New person", 0)
            End If
        End If
        
    End Function
    '--------
    Public Overloads Sub New(ByVal name As String, _
            ByVal salary As Single)
        MyBase.New(name, salary)
        subordinates = New ArrayList()
    End Sub
    '--------
    Public Overloads Sub New(ByVal emp As Employee)
        MyBase.New(emp.getName, emp.getSalary)
    End Sub
    '--------
    
    Public Overrides Function isLeaf() As Boolean
        Return False
    End Function
    '--------
    
End Class
