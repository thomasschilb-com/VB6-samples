Imports System.Drawing
Imports System.WinForms


Imports System.ComponentModel


Public Class Form1
    Inherits System.WinForms.Form
    Dim prez As AbstractEmployee
    Dim rootNode As TreeNode
    Dim marketVP As AbstractEmployee
    Dim salesMgr As AbstractEmployee
    Dim advMgr As AbstractEmployee
    Dim emp As AbstractEmployee
    Dim prodVP As AbstractEmployee
    Dim prodMgr As AbstractEmployee
    Dim shipMgr As AbstractEmployee
    Private Rnd As Random
    
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent()

        Rnd = New Random()
        BuildEmployeeList()
        buildTree()
    End Sub
    Private Sub buildEmployeeList()
        Dim i As Integer
        
        prez = New Boss("CEO", 200000)
        
        marketVP = New Boss("Marketing VP", 100000)
        prez.add(marketVP)
        
        salesMgr = New Boss("Sales Mgr", 50000)
        
        advMgr = New Boss("Advt Mgr", 50000)
        
        marketVP.add(salesMgr)
        marketVP.add(advMgr)
        prodVP = New Boss("Production VP", 100000)
        
        prez.add(prodVP)
        advMgr.add("Secy", 20000)
        
        'add salesmen reporting to sales manager
        For i = 1 To 5
            salesMgr.add("Sales" + i.toString, rand_sal(30000))
        Next i
        
        prodMgr = New Boss("Prod Mgr", 40000)
        shipMgr = New Boss("Ship Mgr", 35000)
        prodVP.add(prodMgr)
        prodVP.add(shipMgr)
        
        For i = 1 To 3
            shipMgr.add("Ship" + i.toString, rand_sal(25000))
        Next i
        For i = 1 To 4
            prodMgr.add("Manuf" + i.toString, rand_sal(20000))
        Next i
    End Sub
    '--------
    Private Sub buildTree()
        Dim nod As EmpNode
        
        nod = New EmpNode(prez)
        rootNode = nod
        EmpTree.nodes.add(nod)
        addNodes(nod, prez)
    End Sub
    '---------
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    Private Function getNodeSum(ByVal node As EmpNode) As Single
        Dim emp As AbstractEmployee
        Dim sum As Single
        
        emp = node.getEmployee
        sum = emp.getSalaries
        
        lbSalary.Text = sum.Format("n", Nothing)
    End Function
    '---------
    Private Sub addNodes(ByVal nod As EmpNode, ByVal emp As AbstractEmployee)
        Dim newEmp As AbstractEmployee
        Dim newNode As EmpNode
        Dim empEnum As IEnumerator
        empEnum = emp.getSubordinates
        
        While empEnum.MoveNext
            newEmp = CType(empEnum.Current, AbstractEmployee)
            newNode = New EmpNode(newEmp)
            nod.nodes.Add(newNode)
            addNodes(newNode, newEmp)
        End While
        
    End Sub
    '------------
    Private Function rand_sal(ByVal sal As Single) As Single
        Dim rnum As Single
        rnum = Rnd.Next
        rnum = rnum / Int32.MaxValue
        Return Rnum * sal / 5 + sal
    End Function
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents lbSalary As System.WinForms.Label
    Private WithEvents EmpTree As System.WinForms.TreeView
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbSalary = New System.WinForms.Label()
        Me.EmpTree = New System.WinForms.TreeView()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lbSalary.Location = New System.Drawing.Point(64, 232)
        lbSalary.Text = " "
        lbSalary.Size = New System.Drawing.Size(152, 24)
        lbSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 12!, System.Drawing.FontStyle.Bold)
        lbSalary.TabIndex = 1
        
        EmpTree.Location = New System.Drawing.Point(24, 24)
        EmpTree.Size = New System.Drawing.Size(240, 184)
        EmpTree.Font = New System.Drawing.Font("Microsoft Sans Serif", 10!)
        EmpTree.TabIndex = 0
        
        Me.Text = "Composite"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(lbSalary)
        Me.Controls.Add(EmpTree)
    End Sub
    
#End Region
    
    Protected Sub EmpTree_AfterSelect( _
            ByVal sender As Object, _
            ByVal e As System.WinForms.TreeViewEventArgs)
        Dim node As EmpNode
        node = CType(EmpTree.SelectedNode, EmpNode)
        getNodeSum(node)
    End Sub
    
End Class
