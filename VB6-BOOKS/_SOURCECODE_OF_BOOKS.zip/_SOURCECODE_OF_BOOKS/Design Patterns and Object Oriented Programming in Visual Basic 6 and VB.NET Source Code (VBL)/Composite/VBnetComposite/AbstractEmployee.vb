Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections


Interface AbstractEmployee
    Inherits IEnumerable
    'Interface for all Employee classes
    Function getSalary() As Single
    Function getName() As String
    Function isLeaf() As Boolean
    Overloads Sub add(ByVal nm As String, ByVal salary As Single)
    Overloads Sub add(ByVal emp As AbstractEmployee)
    Function getSubordinates() As IEnumerator
    Sub remove(ByVal emp As AbstractEmployee)
    Function getChild(ByVal nm As String) As AbstractEmployee
    Function getSalaries() As Single   
End Interface
