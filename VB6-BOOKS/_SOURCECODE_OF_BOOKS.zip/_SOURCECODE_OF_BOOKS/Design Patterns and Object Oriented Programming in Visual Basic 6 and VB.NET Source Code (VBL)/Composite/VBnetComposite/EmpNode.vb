Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Collections
Imports System.WinForms

Public Class EmpNode
    Inherits TreeNode
    
    Private emp As AbstractEmployee
    
    Public Sub New(ByVal aEmp As AbstractEmployee)
        MyBase.New(aEmp.getName)
        emp = aemp
    End Sub
    
    Public Function getEmployee() As AbstractEmployee
        Return emp
    End Function
    
End Class
