Imports System
Imports System.ComponentModel
Imports System.Collections


Public Class SexSwimData
        Inherits SwimData

Public Sub New(filename as String)
  MyBase.New(filename)
end Sub  
'-----------
'Here is the sort method
Public Overrides Sub sort()
Dim i, j, max As Integer
Dim sw as Swimmer

max = swimmers.Count
Dim sws(max) As Swimmer
'copy into array
For i = 0 To max-1
   sws(i) = CType( swimmers(i), Swimmer)
Next i
'first sort by time
For i = 0 To max -1
  For j = i To max-1
    If sws(i).getTime > sws(j).getTime Then
      sw = sws(i)
      sws(i) = sws(j)
      sws(j) = sw
    End If
  Next j
Next i
'and then by sex
For i = 0 To max-1
  For j = i To max-1
    If sws(i).getSex > sws(j).getSex Then
      sw = sws(i)
      sws(i) = sws(j)
      sws(j) = sw
    End If
  Next j
Next i
'copy back into new arraylist
swimmers = new ArrayList
For i = 0 To max-1
  swimmers.Add( sws(i))
Next i

End Sub

End Class
