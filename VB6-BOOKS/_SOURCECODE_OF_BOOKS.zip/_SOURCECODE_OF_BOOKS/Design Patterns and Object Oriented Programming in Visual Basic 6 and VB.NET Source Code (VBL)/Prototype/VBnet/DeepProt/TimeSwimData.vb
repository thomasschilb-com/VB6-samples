Imports System
Imports System.ComponentModel
Imports System.Collections

 
Public Class TimeSwimData
    Inherits SwimData
    '---------        
    Public Overloads Sub New(ByVal filename As String)
        MyBase.New(filename)
    End Sub
    '---------
    Public Overloads Sub New()
        MyBase.new()
    End Sub
    '---------
    'Required sort method
    Public Overrides Sub sort()
        Dim i, j, max As Integer
        Dim sw As Swimmer
        max = swimmers.Count
        'copy into array
        Dim sws(max) As Swimmer
        swimmers.CopyTo(sws)
        'sort by time
        For i = 0 To max - 1
            For j = i To max - 1
                If sws(i).getTime > sws(j).getTime Then
                    sw = sws(i)
                    sws(i) = sws(j)
                    sws(j) = sw
                End If
            Next j
        Next i
        'copy back into new ArrayList
        swimmers = New Arraylist()
        For i = 0 To max - 1
            swimmers.Add(sws(i))
        Next i
    End Sub
    
End Class
