Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility.VB6


Public Class ProtoDemo
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private btRefresh As System.WinForms.Button
                Private btClone As System.WinForms.Button
                Private rightList As System.WinForms.ListBox
                Private leftList As System.WinForms.ListBox
                Private swd, tsd as SwimData
    
        Public Sub New()
           MyBase.New
           InitializeComponent
           swd = new SexSwimData("swimmers.txt")
           loadLeftList
        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New ProtoDemo())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.btRefresh = New System.WinForms.Button
            Me.leftList = New System.WinForms.ListBox
            Me.btClone = New System.WinForms.Button
            Me.rightList = New System.WinForms.ListBox

            btRefresh.Location = New System.Drawing.Point(56, 208)
            btRefresh.Size = New System.Drawing.Size(64, 24)
            btRefresh.TabIndex = 3
            btRefresh.Text = "Refresh"
            btRefresh.AddOnClick(New System.EventHandler(AddressOf Me.btRefresh_Click))

            leftList.Location = New System.Drawing.Point(24, 32)
            leftList.Size = New System.Drawing.Size(168, 160)
            leftList.TabIndex = 0

            btClone.Location = New System.Drawing.Point(200, 56)
            btClone.Size = New System.Drawing.Size(48, 24)
            btClone.TabIndex = 2
            btClone.Text = "Clone"
            btClone.AddOnClick(New System.EventHandler(AddressOf Me.btClone_Click))

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Clone demonsration"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(456, 253)

            rightList.Location = New System.Drawing.Point(264, 32)
            rightList.Size = New System.Drawing.Size(168, 160)
            rightList.TabIndex = 1

            Me.Controls.Add(btRefresh)
            Me.Controls.Add(btClone)
            Me.Controls.Add(rightList)
            Me.Controls.Add(leftList)

        End Sub
private sub loadLeftList
       Dim sw as Swimmer
           DIm s as String
           DIm t as  single
           
swd.MoveFirst
leftList.items.clear
           while swd.hasMoreElements
             sw = swd.getNextSwimmer
             s =  sw.getName +chr$(9)+ sw.getClub +" "
             t = sw.getTime
             's = s+ t.Format("d", Nothing)
             s=s+" "+t.toString
             
             leftList.items.Add( s )
           end while  
end Sub        

public sub loadRightList
    Dim sw as Swimmer
           DIm s as String
           DIm t as  single
           while tsd.hasMoreElements
             sw = tsd.getNextSwimmer
             s =  sw.getName +chr$(9)+ sw.getClub +" "
             t = sw.getTime
             's = s+ t.Format("d", Nothing)
             s=s+" "+t.toString
             
             rightList.items.Add( s )
           end while  
end sub

Protected Sub btClone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
   tsd = New TimeSwimData
   swd.Clone(tsd)
   tsd.sort
   loadRightList
End Sub

Protected Sub btRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    loadLeftList
End Sub

    
    End Class


