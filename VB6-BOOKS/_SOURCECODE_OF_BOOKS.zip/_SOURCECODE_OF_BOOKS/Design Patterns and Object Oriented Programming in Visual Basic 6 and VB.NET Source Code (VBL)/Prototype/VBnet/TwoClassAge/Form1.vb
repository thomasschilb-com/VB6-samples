Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private swd, tsd As SwimData
    Dim tab As Char = 9.toChar
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        swd = New SexSwimData("swimmers.txt")
        loadLeftList()
        
    End Sub
    Private Sub loadLeftList()
        Dim sw As Swimmer
        Dim s As String
        Dim t As Single
        
        swd.MoveFirst()
        leftList.items.clear()
        While swd.hasMoreElements
            sw = swd.getNextSwimmer
            s = sw.getName + tab + sw.getClub + " "
            t = sw.getTime
            's = s+ t.Format("d", Nothing)
            s = s + " " + t.toString
            
            leftList.items.Add(s)
        End While
    End Sub
    
    Public Sub loadRightList()
        Dim sw As Swimmer
        Dim s As String
        Dim t As Single
        
        While tsd.hasMoreElements
            sw = tsd.getNextSwimmer
            s = sw.getName + tab + sw.getClub + " "
            t = sw.getTime
            's = s+ t.Format("d", Nothing)
            s = s + " " + t.toString
            
            rightList.items.Add(s)
        End While
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btRefresh As System.WinForms.Button
    Private WithEvents btClone As System.WinForms.Button
    Private WithEvents rightList As System.WinForms.ListBox
    Private WithEvents leftList As System.WinForms.ListBox
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btClone = New System.WinForms.Button()
        Me.leftList = New System.WinForms.ListBox()
        Me.btRefresh = New System.WinForms.Button()
        Me.rightList = New System.WinForms.ListBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        btClone.Location = New System.Drawing.Point(200, 56)
        btClone.Size = New System.Drawing.Size(48, 24)
        btClone.TabIndex = 2
        btClone.Text = "Clone"
        
        leftList.Location = New System.Drawing.Point(16, 24)
        leftList.Size = New System.Drawing.Size(176, 160)
        leftList.TabIndex = 0
        
        btRefresh.Location = New System.Drawing.Point(200, 112)
        btRefresh.Size = New System.Drawing.Size(56, 24)
        btRefresh.TabIndex = 3
        btRefresh.Text = "Refresh"
        
        rightList.Location = New System.Drawing.Point(296, 24)
        rightList.Size = New System.Drawing.Size(184, 160)
        rightList.TabIndex = 1
        Me.Text = "Prototype demo"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(496, 237)
        
        Me.Controls.Add(btRefresh)
        Me.Controls.Add(btClone)
        Me.Controls.Add(rightList)
        Me.Controls.Add(leftList)
    End Sub
    
#End Region
    
    Protected Sub btRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        loadLeftList()
    End Sub
    
    Protected Sub btClone_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        tsd = New TimeSwimData()
        swd.Clone(tsd)
        tsd.sort()
        loadRightList()
    End Sub
    
End Class
