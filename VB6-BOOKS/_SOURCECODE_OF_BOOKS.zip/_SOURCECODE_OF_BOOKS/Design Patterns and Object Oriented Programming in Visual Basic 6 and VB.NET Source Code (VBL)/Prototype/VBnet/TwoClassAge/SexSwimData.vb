Imports System
Imports System.ComponentModel
Imports System.Collections


Public Class SexSwimData
    Inherits SwimData
    
    Public Sub New(ByVal filename As String)
        MyBase.New(filename)
    End Sub
    
    
    Public Overrides Sub sort()
        Dim i, j, max As Integer
        Dim sw As Swimmer
        
        max = swimmers.Count
        Dim sws(max) As Swimmer
        For i = 0 To max - 1
            sws(i) = CType(swimmers(i), Swimmer)
        Next i
        For i = 0 To max - 1
            For j = i To max - 1
                If sws(i).getTime > sws(j).getTime Then
                    sw = sws(i)
                    sws(i) = sws(j)
                    sws(j) = sw
                End If
            Next j
        Next i
        For i = 0 To max - 1
            For j = i To max - 1
                If sws(i).getSex > sws(j).getSex Then
                    sw = sws(i)
                    sws(i) = sws(j)
                    sws(j) = sw
                End If
            Next j
        Next i
        swimmers = New ArrayList()
        For i = 0 To max - 1
            swimmers.Add(sws(i))
        Next i
        
    End Sub
    
End Class
