Imports System
Imports System.ComponentModel
Imports System.Collections


Public MustInherit Class SwimData
    Protected Swimmers As ArrayList
    Private index As Integer
    
    Public Overloads Sub New()
        MyBase.New()
        index = 0
    End Sub
    
    Public Overloads Sub New(ByVal Filename As String)
        MyBase.New()
        Dim fl As New vbFile(Filename)
        Dim sw As Swimmer
        Dim sname As String
        
        swimmers = New ArrayList()
        Fl.OpenForRead(Filename)
        
        sname = fl.readLine
        While sname.length > 0
            If (sname.length > 0) Then
                sw = New Swimmer(sname)
                swimmers.Add(sw)
            End If
            sname = fl.readLine
        End While
        sort()
        index = 0
    End Sub
    
    Public Sub Clone(ByVal swd As SwimData)
        Dim swmrs As New ArrayList()
        Dim i As Integer
        'copy data from one collection
        ' to another
        For i = 0 To swimmers.Count - 1
            swmrs.Add(swimmers(i))
        Next i
        'and put into new class
        swd.setData(swmrs)
        
    End Sub
    '-----
    Public Sub setData(ByVal swcol As ArrayList)
        swimmers = swcol
        movefirst()
    End Sub
    '-----
    Public MustOverride Sub sort()
    '-----
    Public Sub MoveFirst()
        index = -1
    End Sub
    '-----
    Public Function hasMoreElements() As Boolean
        Return (index < (Swimmers.count - 1))
    End Function
    '-----
    Public Function getNextSwimmer() As Swimmer
        index = index + 1
        Return CType(swimmers(index), Swimmer)
    End Function
    
End Class
