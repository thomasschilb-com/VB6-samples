Imports System.WinForms
Public Class UndoButton
    Implements Command
    Private ubutton As toolbarButton
    Private med As Mediator
    Public Sub new(ByVal md As Mediator, ByVal but As toolbarButton)
        ubutton = but
        med = md
    End Sub
    
    Public Sub Execute() Implements VBNetMemento.Command.Execute
        med.undo()
    End Sub
End Class
