Imports System.WinForms
Imports System.Drawing
Imports system.Collections
Public Class Mediator
    Private startRect As Boolean
    Private rectSelected As Boolean
    Private drawings As arrayList
    Private canvas As PictureBox
    Private selectedIndex As Integer
    Private caretakr As Caretaker
    Private rect As RectButton
    '-----
    Public Sub New(ByVal p As PictureBox)
        startRect = False
        rectSelected = False
        
        drawings = New arraylist()
        caretakr = New Caretaker()
        caretakr.init(drawings)
        canvas = p
    End Sub
    '-----
    Public Sub startRectangle()
        startRect = True
    End Sub
    '-----
    Public Sub createRect(ByVal x As Integer, ByVal y As Integer)
        Dim count As Integer
        Dim v As VisRectangle
        unpick()           'make sure no rectangle is selected
        If startRect Then  'if rect button is depressed
            count = drawings.count
            caretakr.add(count)  'Save previous drawing list size
            v = New VisRectangle(x, y)    'create a rectangle
            drawings.add(v)              'add new element to list
            startRect = False          'done with this rectangle
            rect.setSelected(False)      'unclick button
            canvas.Refresh()
        Else
            pickRect(x, y)   'if not pressed look for rect to select
        End If
    End Sub
    '------------------------------------------
    Public Sub registerRectButton(ByVal rb As RectButton)
        rect = rb
    End Sub
    '-------------------------------------------
    Private Sub unpick()
        If rectSelected And selectedIndex >= 0 Then
            Dim vis As visRectangle
            vis = CType(drawings(selectedindex), visrectangle)
            vis.setSelected(False)
            selectedIndex = -1
            rectSelected = False
            canvas.Refresh()
        End If
    End Sub
    '-----
    Public Sub pickRect(ByVal x As Integer, ByVal y As Integer)
        'save current selected rectangle
        'to avoid double save of undo
        Dim lastPick As Integer = -1
        Dim v As VisRectangle
        Dim i As Integer
        If selectedIndex >= 0 Then
            lastPick = selectedIndex
        End If
        unpick() 'undo any selection
        'see if one is being selected
        For i = 0 To drawings.count - 1
            v = CType(drawings(i), visrectangle)
            If v.contains(x, y) Then 'did click inside a rectangle
                selectedIndex = i     'save it
                rectSelected = True
                If selectedIndex <> lastPick Then 'but don't save twice
                    caretakr.rememberPosition(v)
                End If
                v.setSelected(True)    'turn on handles
                repaint()          'and redraw
            End If
        Next i
    End Sub
    '-----
    Public Sub clear()
        drawings = New arraylist()
        caretakr.clear(drawings)
        rectSelected = False
        selectedIndex = 0
        repaint()
    End Sub
    '-----
    Private Sub repaint()
        canvas.Refresh()
    End Sub
    '-----
    Public Sub drag(ByVal x As Integer, ByVal y As Integer)
        Dim v As visRectangle
        If rectSelected Then
            v = CType(drawings(selectedIndex), visrectangle)
            If v.contains(x, y) Then
                v.move(x, y)
                repaint()
            End If
        End If
    End Sub
    
    '-------------------------------------------
    Public Sub reDraw(ByVal g As graphics)
        Dim i As Integer
        Dim v As VisRectangle
        
        For i = 0 To drawings.count - 1
            v = CType(drawings(i), visrectangle)
            v.draw(g)
        Next i
    End Sub
    
    '-------------------------------------------
    Public Sub undo()
        caretakr.undo()
        repaint()
    End Sub
    
    '-------------------------------------------
    
    
    
    
    
    
    
End Class
