Imports System.WinForms
Public Class RectButton
    Implements Command
    Private bt As toolbarbutton
    Private med As Mediator
    '-----
    Public Sub New(ByVal md As Mediator, ByVal but As toolbarbutton)
        bt = but
        med = md
        med.registerRectButton(Me)
    End Sub
    '-----
    Public Sub setSelected(ByVal sel As Boolean)
        If sel Then
            bt.Pushed = True
        Else
            bt.Pushed = False
        End If
    End Sub
    
    Public Sub Execute() Implements VBNetMemento.Command.Execute
        If bt.Pushed Then
            med.startRectangle()
        End If
    End Sub
End Class
