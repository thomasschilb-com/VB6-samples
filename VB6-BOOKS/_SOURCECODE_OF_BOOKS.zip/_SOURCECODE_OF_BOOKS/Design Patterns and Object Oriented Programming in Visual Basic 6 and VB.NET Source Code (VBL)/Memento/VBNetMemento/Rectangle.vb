Namespace vbPatterns
    Public Class Rectangle
        Private xp, yp As Integer
        Private wr, hr As Integer
        Public Overloads Sub New(ByVal x As Integer, ByVal y As Integer, ByVal w As Integer, ByVal h As Integer)
            xp = x
            yp = y
            wr = w
            hr = h
        End Sub
        Public Overloads Sub new(ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal h As Single)
            xp = x.ToInt16
            yp = y.ToInt16
            wr = w.ToInt16
            hr = h.ToInt16
        End Sub
        Public Function contains(ByVal x As Integer, ByVal y As Integer) As Boolean
            Dim cn As Boolean
            cn = xp <= x And x <= xp + wr
            cn = cn And yp <= y And y <= yp + hr
            Return cn
        End Function
        Property x() As Integer
            Get
                Return xp
            End Get
            Set
                xp = x
            End Set
        End Property
        Property y() As Integer
            Get
                Return yp
            End Get
            Set
                yp = y
            End Set
        End Property
        Property w() As Integer
            Get
                Return wr
            End Get
            Set
                wr = w
            End Set
        End Property
        Property h() As Integer
            Get
                Return hr
            End Get
            Set
                hr = h
            End Set
        End Property
    End Class
End Namespace
