Imports System.Collections
Public Class CareTaker
    Private drawings As arraylist
    Private undoList As arraylist
    Public Sub init(ByVal dcol As ArrayList)
        drawings = dcol
        undoList = New arraylist()
    End Sub
    '------------------------------------
    Public Sub rememberPosition(ByVal vrect As VisRectangle)
        Dim m As Memento
        m = New Memento(vrect)
        undoList.add(m)
    End Sub
    
    '------------------------------------
    Public Sub clear(ByVal drw As ArrayList)
        undoList = New ArrayList()
        drawings = drw
    End Sub
    Public Sub add(ByVal intObj As Integer)
        undoList.add(intobj)
    End Sub
    '------------------------------------
    Private Sub removeDrawing()
        drawings.removeAt(drawings.count - 1)
    End Sub
    '------------------------------------
    Private Sub remove(ByVal obj As Memento)
        obj.restore()
    End Sub
    
    '-----------------------------------
    Public Sub undo()
        Dim obj As Object
        If undoList.count > 0 Then
            'get last element in undo list
            obj = undoList(undoList.count - 1)
            If (TypeOf obj Is Memento) Then
                remove(CType(obj, Memento))
            Else
                removeDrawing()
            End If
            undoList.removeAt(undoList.count - 1)  'and remove it
        End If
    End Sub
    
    
    
End Class
