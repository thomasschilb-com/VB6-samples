Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections


Public Class Form1
    Inherits System.WinForms.Form
    Private commands As Hashtable
    Private med As Mediator
    Private mouse_down As Boolean
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent()
        med = New Mediator(pic)     'create Mediator
        commands = New Hashtable()  'and Hash table
        'create the command objects
        Dim rbutn As New RectButton(med, tbar.Buttons(0))
        Dim ubutn As New UndoButton(med, tbar.Buttons(1))
        Dim clrbutn As New Clearbutton(med)
        'add them to the hashtable using the button hash values
        commands.Add(btrect.GetHashCode, rbutn)
        commands.Add(btundo.GetHashCode, ubutn)
        commands.add(btclear.GetHashCode, clrbutn)
        AddHandler Pic.Paint, New PaintEventHandler(AddressOf paintHandler)
        
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    Private btClear As System.WinForms.ToolBarButton
    Private btUndo As System.WinForms.ToolBarButton
                Private btRect As System.WinForms.ToolBarButton
    Private WithEvents tBar As System.WinForms.ToolBar
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pic = New System.WinForms.PictureBox()
        Me.btRect = New System.WinForms.ToolBarButton()
        Me.tBar = New System.WinForms.ToolBar()
        Me.btClear = New System.WinForms.ToolBarButton()
        Me.btUndo = New System.WinForms.ToolBarButton()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Pic.Location = New System.Drawing.Point(8, 64)
        Pic.Size = New System.Drawing.Size(336, 200)
        Pic.TabIndex = 1
        Pic.TabStop = False
        
        btRect.Text = "Rectangle"
        btRect.Style = System.WinForms.ToolBarButtonStyle.ToggleButton
        
        tBar.Size = New System.Drawing.Size(352, 40)
        tBar.DropDownArrows = True
        tBar.TabIndex = 0
        tBar.ShowToolTips = True
        Dim a__1(3) As System.WinForms.ToolBarButton
        a__1(0) = btRect
        a__1(1) = btUndo
        a__1(2) = btClear
        tBar.Buttons.All = a__1
        
        btClear.Text = "Clear"
        
        btUndo.Text = "Undo"
        Me.Text = "Memento Rectangles"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 273)
        
        Me.Controls.Add(Pic)
        Me.Controls.Add(tBar)
    End Sub
    
#End Region
    
    Protected Sub paintHandler(ByVal sender As Object, ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        med.reDraw(g)
    End Sub
    Protected Sub tBar_ButtonClick(ByVal sender As Object, _
            ByVal e As ToolBarButtonClickEventArgs)
        Dim cmd As Command
        Dim tbutn As ToolBarButton = e.button
        cmd = CType(commands(tbutn.GetHashCode), Command)
        cmd.Execute()
    End Sub
    
    Public Sub Pic_MouseUp(ByVal sender As Object, ByVal e As System.WinForms.MouseEventArgs) Handles Pic.MouseUp
        mouse_down = False
    End Sub
    Public Sub Pic_MouseMove(ByVal sender As Object, ByVal e As System.WinForms.MouseEventArgs) Handles Pic.MouseMove
        If mouse_down Then
            med.drag(e.X, e.Y)
        End If
    End Sub
    Public Sub Pic_MouseDown(ByVal sender As Object, ByVal e As System.WinForms.MouseEventArgs) Handles Pic.MouseDown
        mouse_down = True
        med.createRect(e.X, e.Y)
    End Sub
End Class
