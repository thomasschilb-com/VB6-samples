Imports System.Drawing
Public Class visRectangle
    Private x, y, w, h As Single
    Private rect As vbpatterns.Rectangle
    Private selected As Boolean
    Private bPen As Pen
    Private bBrush As SolidBrush
    '-----
    Public Sub New(ByVal xp As Integer, ByVal yp As Integer)
        x = xp     'save coordinates
        y = yp
        w = 40     'default size
        h = 30
        saveAsRect() 'keep in rectangle class as well
        bpen = New Pen(Color.Black)
        bbrush = New SolidBrush(Color.Black)
    End Sub
    '-----
    'Property methods used to save and restore state
    Friend Property rects() As vbpatterns.Rectangle
        Set
            x = value.x
            y = value.y
            w = value.w
            h = value.h
            saveAsRect()
        End Set
        Get
            Return rect
        End Get
    End Property
    '-----
    Public Sub setSelected(ByVal b As Boolean)
        selected = b
    End Sub
    '-----
    'save values in Rectangle class
    Private Sub saveAsRect()
        rect = New vbpatterns.Rectangle(x, y, w, h)
    End Sub
    '-----
    'draw rectangle and handles
    Public Sub draw(ByVal g As Graphics)
        'draw rectangle
        g.DrawRectangle(bpen, x, y, w, h)
        
        If selected Then   'draw handles
            g.fillrectangle(bbrush, x + w / 2, y - 2, 4, 4)
            g.FillRectangle(bbrush, x - 2, y + h / 2, 4, 4)
            g.FillRectangle(bbrush, x + (w / 2), y + h - 2, 4, 4)
            g.FillRectangle(bbrush, x + (w - 2), y + (h / 2), 4, 4)
        End If
    End Sub
    '-----
    Public Function contains(ByVal xp As Integer, ByVal yp As Integer) As Boolean
        contains = rect.contains(xp, yp)
    End Function
    '-----
    Public Sub move(ByVal xpt As Integer, ByVal ypt As Integer)
        x = xpt
        y = ypt
        saveAsRect()
    End Sub
    
End Class
