Public Class Clearbutton
    Implements Command
    Private med As Mediator
    Public Sub New(ByVal md As Mediator)
        med = md
    End Sub
    Public Sub Execute() Implements VBNetMemento.Command.Execute
        med.clear()
    End Sub
End Class
