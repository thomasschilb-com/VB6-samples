Public Class Memento
    Private x As Integer, y As Integer
    Private w As Integer, h As Integer
    Private rect As vbpatterns.Rectangle
    Private visRect As VisRectangle
    
    Public Sub New(ByVal vrect As VisRectangle)
        'save the state of a visual rectangle
        visRect = vrect
        rect = vrect.rects
        x = rect.x
        y = rect.y
        w = rect.w
        h = rect.h
    End Sub
    Public Sub restore()
        'restore the state of a visual rectangle
        rect.x = x
        rect.y = y
        rect.h = h
        rect.w = w
        visRect.rects = rect
    End Sub
    
End Class
