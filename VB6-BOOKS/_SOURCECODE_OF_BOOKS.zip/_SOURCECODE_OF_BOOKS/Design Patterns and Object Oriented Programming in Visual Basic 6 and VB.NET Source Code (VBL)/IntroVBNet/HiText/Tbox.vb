Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


    Public Class TbForm
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
    Private WithEvents HiTextBox1 As WindowsApplication1.HiTextBox
    
        Private TextBox1 As System.WinForms.TextBox
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New TbForm())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox1 = New System.WinForms.TextBox()
        Me.HiTextBox1 = New WindowsApplication1.HiTextBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = True
        '@design Me.TrayAutoArrange = True
        TextBox1.Location = New System.Drawing.Point(40, 40)
        TextBox1.Text = "TextBox1"
        TextBox1.TabIndex = 0
        TextBox1.Size = New System.Drawing.Size(136, 20)
        
        HiTextBox1.Location = New System.Drawing.Point(40, 88)
        HiTextBox1.Text = "HiTextbox1"
        HiTextBox1.TabIndex = 1
        HiTextBox1.Size = New System.Drawing.Size(136, 20)
        Me.Text = "TbForm"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(HiTextBox1)
        Me.Controls.Add(TextBox1)
    End Sub
    
    
    
End Class


