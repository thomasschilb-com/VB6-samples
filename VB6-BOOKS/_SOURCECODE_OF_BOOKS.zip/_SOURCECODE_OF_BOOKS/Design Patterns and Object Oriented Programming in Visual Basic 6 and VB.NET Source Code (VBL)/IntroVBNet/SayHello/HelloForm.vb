Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Public Class HelloForm
    Inherits System.WinForms.Form
    
    Public Sub New()
        MyBase.New()
        Form1 = Me
        'This call is required by the Win Form Designer.
        InitializeComponent()
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents SayHello As System.WinForms.Button
    Private WithEvents lbHi As System.WinForms.Label
    Private WithEvents txHi As System.WinForms.TextBox
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbHi = New System.WinForms.Label()
        Me.SayHello = New System.WinForms.Button()
        Me.txHi = New System.WinForms.TextBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lbHi.Location = New System.Drawing.Point(48, 72)
        lbHi.Size = New System.Drawing.Size(176, 24)
        lbHi.ForeColor = System.Drawing.Color.Blue
        lbHi.Font = New System.Drawing.Font("Microsoft Sans Serif", 10!, System.Drawing.FontStyle.Bold)
        lbHi.TabIndex = 1
        
        SayHello.Location = New System.Drawing.Point(72, 128)
        SayHello.Size = New System.Drawing.Size(112, 24)
        SayHello.TabIndex = 2
        SayHello.Text = "Say Hello"
        
        txHi.Location = New System.Drawing.Point(48, 24)
        txHi.Text = "Hello"
        txHi.TabIndex = 0
        txHi.Size = New System.Drawing.Size(176, 20)
        Me.Text = "Simple Hello"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        
        Me.Controls.Add(SayHello)
        Me.Controls.Add(lbHi)
        Me.Controls.Add(txHi)
    End Sub
    
#End Region
    
    Protected Sub SayHello_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        lbhi.Text() = txhi.Text
        txhi.Text = ""
    End Sub
End Class
