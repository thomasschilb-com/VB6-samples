Imports System
'illustrates use of tokenizer
Public Class TokTest
    
    Shared Sub Main()
        Dim s As String
        Dim tok As New StringTokenizer("Hello VB World")
        s = tok.nextToken()
        While (s <> "")
            Console.writeLine(s)
            s = tok.nextToken()
        End While
    End Sub
End Class
