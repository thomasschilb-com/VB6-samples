Imports System
'illustrates use of tokenizer

Public class TokTest
 
Shared Sub Main()
  'Dim tok as StringTokenizer
  Dim s as String
  'tok = new StringTokenizer("Hello VB World")
  Dim tok as new StringTokenizer("Hello VB World")
  s= tok.nextToken() 
  while (s<> "")
      Console.writeLine(s)
      s= tok.nextToken()
  End While  
   
 End Sub
End Class
