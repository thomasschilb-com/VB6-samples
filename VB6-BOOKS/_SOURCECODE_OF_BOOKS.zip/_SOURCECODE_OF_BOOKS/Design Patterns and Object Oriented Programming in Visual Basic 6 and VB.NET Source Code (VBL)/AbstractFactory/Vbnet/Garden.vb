Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Namespace Garden

Public Class Garden
  'protected objects are accessed by derived classes
  Protected pltShade, pltBorder, pltCenter As Plant
  Protected center, shade, border as Boolean
  
  'These are created in the constructor
  Private gbrush as SolidBrush  
  Private gdFont as Font

'Constructor creates brush and font fro drawing
Public Sub New ()
  MyBase.New
  gBrush = new SolidBrush(Color.Black)
  gdFont = new Font("Arial", 10)
End Sub
  
Public Sub showCenter
  center = true
end sub

public sub showBorder
  border=true
end sub

public sub showShade
  shade=true
end sub

Public Sub draw(g as Graphics)
 If border Then 
    g.DrawString(pltBorder.getName, gdFont, gbrush, 50,  150)
 end if   
 If center Then 
   g.DrawString(pltCenter.getName, gdFont, gbrush, 100, 100)
 End If  
 If shade Then 
   g.DrawString(pltShade.getName,  gdFont, gbrush, 10,  50)
 End If  
End Sub 
End Class

End NameSpace
