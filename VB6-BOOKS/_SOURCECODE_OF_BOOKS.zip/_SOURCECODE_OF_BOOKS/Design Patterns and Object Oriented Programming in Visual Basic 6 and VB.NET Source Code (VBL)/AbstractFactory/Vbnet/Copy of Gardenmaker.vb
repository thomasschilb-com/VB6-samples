Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms

Namespace Garden

    Public Class Gardenmaker
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private opPerennial As System.WinForms.RadioButton
                Private opAnnual As System.WinForms.RadioButton
        
        
                Private opVegetable As System.WinForms.RadioButton
        Private GroupBox1 As System.WinForms.GroupBox
                Private btShade As System.WinForms.Button
                Private btBorder As System.WinForms.Button
                Private btCenter As System.WinForms.Button
                Private pBox As GardenPic
                
                Private gden as Garden
    
        Public Sub New()
           MyBase.New
    
           'This call is required by the Win Forms Designer.
           InitializeComponent
    
           ' TODO: Add any constructor code after InitializeComponent call

        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New GardenMaker())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.btShade = New System.WinForms.Button
            Me.GroupBox1 = New System.WinForms.GroupBox
            Me.pBox = New GardenPic
            Me.opVegetable = New System.WinForms.RadioButton
            Me.btBorder = New System.WinForms.Button
            Me.btCenter = New System.WinForms.Button
            Me.opAnnual = New System.WinForms.RadioButton
            Me.opPerennial = New System.WinForms.RadioButton

            btShade.Location = New System.Drawing.Point(336, 248)
            btShade.Size = New System.Drawing.Size(56, 24)
            btShade.TabIndex = 3
            btShade.Text = "Shade"
            btShade.AddOnClick(New System.EventHandler(AddressOf Me.btShade_Click))

            GroupBox1.Location = New System.Drawing.Point(24, 64)
            GroupBox1.TabIndex = 4
            GroupBox1.TabStop = False
            GroupBox1.Text = "Garden type"
            GroupBox1.Size = New System.Drawing.Size(160, 152)

            pBox.BorderStyle = System.WinForms.BorderStyle.Fixed3D
            pBox.Location = New System.Drawing.Point(200, 32)
            pBox.Size = New System.Drawing.Size(200, 184)
            pBox.TabIndex = 0
            pBox.TabStop = False
            pBox.Text = "PictureBox1"

            opVegetable.Location = New System.Drawing.Point(16, 32)
            opVegetable.Size = New System.Drawing.Size(128, 16)
            opVegetable.TabIndex = 0
            opVegetable.Text = "Vegetable"
            opVegetable.AddOnCheckedChanged(New System.EventHandler(AddressOf Me.opVegetable_CheckedChanged))

            btBorder.Location = New System.Drawing.Point(264, 248)
            btBorder.Size = New System.Drawing.Size(56, 24)
            btBorder.TabIndex = 2
            btBorder.Text = "Border"
            btBorder.AddOnClick(New System.EventHandler(AddressOf Me.btBorder_Click))

            btCenter.Location = New System.Drawing.Point(200, 248)
            btCenter.Size = New System.Drawing.Size(56, 24)
            btCenter.TabIndex = 1
            btCenter.Text = "Center"
            btCenter.AddOnClick(New System.EventHandler(AddressOf Me.btCenter_Click))

            opAnnual.Location = New System.Drawing.Point(16, 64)
            opAnnual.Size = New System.Drawing.Size(120, 16)
            opAnnual.TabIndex = 1
            opAnnual.Text = "Annual"
            opAnnual.AddOnCheckedChanged(New System.EventHandler(AddressOf Me.opAnnual_CheckedChanged))

            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Garden maker"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(416, 309)

            opPerennial.Location = New System.Drawing.Point(16, 96)
            opPerennial.Size = New System.Drawing.Size(104, 16)
            opPerennial.TabIndex = 2
            opPerennial.Text = "Perennial"
            opPerennial.AddOnCheckedChanged(New System.EventHandler(AddressOf Me.opPerennial_CheckedChanged))

            Me.Controls.Add(GroupBox1)
            Me.Controls.Add(btShade)
            Me.Controls.Add(btBorder)
            Me.Controls.Add(btCenter)
            Me.Controls.Add(pBox)
            GroupBox1.Controls.Add(opPerennial)
            GroupBox1.Controls.Add(opAnnual)
            GroupBox1.Controls.Add(opVegetable)
         gden=new VegetableGarden
         pBox.setGarden(gden)
        End Sub  
 '-----------
Protected Sub btShade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    gden.showShade
    pBox.refresh
End Sub

Protected Sub btBorder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    gden.showBorder
    pBox.refresh
End Sub

Protected Sub btCenter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) 
    gden.showCenter
    pBox.refresh
End Sub

Protected Sub opPerennial_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) 
     gden = new PerennialGarden
     pBox.setGarden(gden)
End Sub

Protected Sub opAnnual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) 
  gden = new AnnualGarden
   pBox.setGarden(gden)    
   End Sub

Protected Sub opVegetable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) 
  gden = new VegetableGarden
   pBox.setGarden(gden)
End Sub

    
End Class

End Namespace
