Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class GardenPic
   Inherits PictureBox
   
Protected Overrides Sub OnPaint(e as PaintEventArgs) 
            Dim g as Graphics = e.Graphics
    Dim rpen As new Pen(Color.FromARGB(255, Color.Black), 3)     
    Dim br as new SolidBrush(Color.Gray)
     g.FillEllipse( br,5,5,100,100)

 End Sub

