Namespace Garden
Public Class AnnualGarden      
        Inherits Garden

Public Sub New()    
 MyBase.New
 pltShade = New Plant("Coleus")
 pltBorder = New Plant("Alyssum")
 pltCenter = New Plant("Marigold")
End Sub

End Class
End NameSpace
