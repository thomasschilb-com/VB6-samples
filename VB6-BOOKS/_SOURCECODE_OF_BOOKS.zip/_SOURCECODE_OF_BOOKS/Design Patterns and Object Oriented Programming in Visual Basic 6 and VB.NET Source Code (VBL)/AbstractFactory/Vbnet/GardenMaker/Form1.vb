Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private gden As Garden
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        gden = New VegetableGarden()
        pBox.setGarden(gden)
        
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents ckShade As System.WinForms.CheckBox
    Private WithEvents ckBorder As System.WinForms.CheckBox
    Private WithEvents ckCenter As System.WinForms.CheckBox
    
    
    
    Private WithEvents opPeren As System.WinForms.RadioButton
    Private WithEvents opVegie As System.WinForms.RadioButton
    Private WithEvents opAnnual As System.WinForms.RadioButton
    Private WithEvents GroupBox1 As System.WinForms.GroupBox
    Private WithEvents PBox As GardenMaker.GPic
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.opAnnual = New System.WinForms.RadioButton()
        Me.ckBorder = New System.WinForms.CheckBox()
        Me.ckShade = New System.WinForms.CheckBox()
        Me.ckCenter = New System.WinForms.CheckBox()
        Me.opVegie = New System.WinForms.RadioButton()
        Me.PBox = New GardenMaker.GPic()
        Me.GroupBox1 = New System.WinForms.GroupBox()
        Me.opPeren = New System.WinForms.RadioButton()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        opAnnual.Location = New System.Drawing.Point(16, 24)
        opAnnual.Text = "Annual"
        opAnnual.Size = New System.Drawing.Size(80, 16)
        opAnnual.TabIndex = 0
        
        ckBorder.Location = New System.Drawing.Point(240, 240)
        ckBorder.Text = "Border"
        ckBorder.Size = New System.Drawing.Size(64, 16)
        ckBorder.TabIndex = 3
        
        ckShade.Location = New System.Drawing.Point(320, 240)
        ckShade.Text = "Shade"
        ckShade.Size = New System.Drawing.Size(72, 16)
        ckShade.TabIndex = 4
        
        ckCenter.Location = New System.Drawing.Point(144, 240)
        ckCenter.Text = "Center"
        ckCenter.Size = New System.Drawing.Size(72, 16)
        ckCenter.TabIndex = 2
        
        opVegie.Location = New System.Drawing.Point(16, 48)
        opVegie.Text = "Vegetable"
        opVegie.Size = New System.Drawing.Size(72, 16)
        opVegie.TabIndex = 1
        
        PBox.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        PBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        PBox.Location = New System.Drawing.Point(144, 16)
        PBox.Size = New System.Drawing.Size(256, 216)
        PBox.TabIndex = 0
        PBox.TabStop = False
        
        GroupBox1.Location = New System.Drawing.Point(16, 40)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8!)
        GroupBox1.Text = "Garden type"
        GroupBox1.Size = New System.Drawing.Size(112, 120)
        
        opPeren.Location = New System.Drawing.Point(16, 72)
        opPeren.Text = "Perennial"
        opPeren.Size = New System.Drawing.Size(80, 16)
        opPeren.TabIndex = 2
        Me.Text = "Garden maker"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 301)
        
        GroupBox1.Controls.Add(opPeren)
        GroupBox1.Controls.Add(opVegie)
        GroupBox1.Controls.Add(opAnnual)
        Me.Controls.Add(ckShade)
        Me.Controls.Add(ckBorder)
        Me.Controls.Add(ckCenter)
        Me.Controls.Add(GroupBox1)
        Me.Controls.Add(PBox)
    End Sub
    
#End Region
    
    Protected Sub ckShade_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        gden.showShade()
        pBox.refresh()
    End Sub
    
    Protected Sub ckBorder_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        gden.showBorder()
        pBox.refresh()
    End Sub
    
    Protected Sub ckCenter_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        gden.showCenter()
        pBox.refresh()
    End Sub
    
    Protected Sub opPeren_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        gden = New PerennialGarden()
        pBox.setGarden(gden)
        clearchecks()
    End Sub
    
    Protected Sub opVegie_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        gden = New VegetableGarden()
        pBox.setGarden(gden)
        clearchecks()
    End Sub
    
    Protected Sub opAnnual_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        gden = New AnnualGarden()
        pBox.setGarden(gden)
        clearchecks()
    End Sub
    Private Sub clearChecks()
        ckcenter.CheckState = CheckState.Unchecked
        ckborder.CheckState = CheckState.Unchecked
        ckshade.CheckState = CheckState.Unchecked
    End Sub
End Class
