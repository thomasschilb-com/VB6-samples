
Public Class VegetableGarden      
        Inherits Garden

Public Sub New() 
 MyBase.New
 pltShade = New Plant("Broccoli")
 pltBorder = New Plant("Peas")
 pltCenter = New Plant("Corn")
End Sub


End Class

