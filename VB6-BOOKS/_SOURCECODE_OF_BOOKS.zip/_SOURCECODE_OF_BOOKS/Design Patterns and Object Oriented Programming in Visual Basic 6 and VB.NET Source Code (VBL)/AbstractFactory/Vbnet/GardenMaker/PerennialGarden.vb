
Public Class PerennialGarden      
        Inherits Garden

Public Sub New()
  MyBase.New
 pltShade = New Plant("Astilbe")
 pltBorder = New Plant("Sedum")
 pltCenter = New Plant("Dicentrum")
End Sub

End Class

