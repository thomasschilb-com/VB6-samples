Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Garden
    'protected objects are accessed by derived classes
    Protected pltShade, pltBorder, pltCenter As Plant
    Protected center, shade, border As Boolean
    
    'These are created in the constructor
    Private gbrush As SolidBrush
    Private gdFont As Font
    
    'Constructor creates brush and font fro drawing
    Public Sub New()
        MyBase.New()
        gBrush = New SolidBrush(Color.Black)
        gdFont = New Font("Arial", 10)
    End Sub
    '-----
    Public Sub showCenter()
        center = True
    End Sub
    '-----
    Public Sub showBorder()
        border = True
    End Sub
    '-----
    Public Sub showShade()
        shade = True
    End Sub
    '-----
    Public Sub clear()
        center = False
        border = False
        shade = False
    End Sub
    '-----
    Public Sub draw(ByVal g As Graphics)
        If border Then
            g.DrawString(pltBorder.getName, gdFont, _
                gbrush, 50, 150)
        End If
        If center Then
            g.DrawString(pltCenter.getName, gdFont, _
                 gbrush, 100, 100)
        End If
        If shade Then
            g.DrawString(pltShade.getName, gdFont, _
                 gbrush, 10, 50)
        End If
    End Sub
End Class


