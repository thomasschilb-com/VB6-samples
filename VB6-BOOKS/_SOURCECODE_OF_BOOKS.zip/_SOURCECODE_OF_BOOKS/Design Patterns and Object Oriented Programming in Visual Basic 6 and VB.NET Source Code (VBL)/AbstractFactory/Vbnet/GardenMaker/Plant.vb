

Public Class Plant
    Private plantName As String
    '-----
    Public Sub New(ByVal nm As String)
        MyBase.New()
        plantName = nm        'save the plant name
    End Sub
    '-----
    Public Function getName() As String
        getName = plantName   'return the plant name
    End Function
End Class


