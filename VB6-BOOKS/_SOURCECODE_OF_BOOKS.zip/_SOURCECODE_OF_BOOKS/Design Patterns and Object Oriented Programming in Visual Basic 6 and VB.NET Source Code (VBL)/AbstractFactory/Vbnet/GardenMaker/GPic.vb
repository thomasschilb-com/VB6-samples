Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class GPic
    Inherits System.WinForms.PictureBox
    ' simple derived Picturebox class that
    'draws the Garden plant names and shade circle
    Private gden As Garden
    Private br As SolidBrush
    Public Sub New()
        MyBase.New
        InitializeComponent()
        br = New SolidBrush(Color.LightGray)
    End Sub

    'Gpic overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    Dim WithEvents GPic As System.WinForms.UserControl

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region
    Public Sub setGarden(ByVal gd As Garden)
        gden = gd      'copy in current garden
        gden.clear()
        refresh()
    End Sub
    '-----
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        'draw the circle 
        g.FillEllipse(br, 5, 5, 100, 100)
        'have the garden draw itself
        gden.draw(g)    
    End Sub
End Class


