Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Namespace Garden

'A simple derived PictureBox class 
' which draws the circle 
' and the garden 
Public Class GardenPic
   Inherits PictureBox
   private gden as Garden
   
Public Sub setGarden(gd as Garden)
 gden= gd       'copy in current garden
end sub
 
Protected Overrides Sub OnPaint(e as PaintEventArgs) 
    Dim g as Graphics = e.Graphics
    Dim br as new SolidBrush(Color.Gray)
    
    'draw the circle 
    g.FillEllipse( br,5,5,100,100)
    'have the garden draw itself
    gden.draw(g)

 End Sub
 End Class
End NameSpace
