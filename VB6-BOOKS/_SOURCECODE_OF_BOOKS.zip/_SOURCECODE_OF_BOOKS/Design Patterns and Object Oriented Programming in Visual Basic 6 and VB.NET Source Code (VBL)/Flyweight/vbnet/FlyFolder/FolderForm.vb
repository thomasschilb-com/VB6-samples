Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class Form1
    Inherits System.WinForms.Form
    Private names As ArrayList
    Private fol As Folder
    Private Const pLeft As Integer = 30, pTop As Integer = 30
    Private Const HSpace As Integer = 70, VSpace As Integer = 80
    Private rect As vbPatterns.Rectangle
    Private selectedName As String
    Private folFact As FolderFactory
    '-----
    Public Sub New()
        MyBase.New
        Form1 = Me
        InitializeComponent()
        AddHandler Pic.Paint, New PaintEventHandler(AddressOf picpaint)
        names = New ArrayList()
        names.Add("Adam")
        names.Add("Bill")
        names.Add("Charlie")
        names.Add("Dave")
        names.Add("Edward")
        names.Add("Fred")
        names.Add("George")
        fol = New Folder(color.Bisque)
        AddHandler Pic.MouseMove, (AddressOf evmouse)
        rect = New vbPatterns.Rectangle()
        rect.setSize(50, 30)
        folfact = New FolderFactory()
    End Sub
    '-----
    'paints the folders in the picture box
    Private Sub picPaint(ByVal sender As Object, ByVal e As PaintEventArgs)
        Dim i As Integer, x As Integer, y As Integer, cnt As Integer
        Dim g As Graphics = e.Graphics
        x = pleft
        y = ptop
        cnt = 0
        For i = 0 To names.Count - 1
            fol = folfact.getFolder(selectedname = CType(names(i), String))
            fol.draw(g, x, y, CType(names(i), String))
            cnt = cnt + 1
            If cnt > 2 Then
                cnt = 0
                x = pleft
                y = y + vspace
            Else
                x = x + hspace
            End If
        Next
    End Sub
    'Form overrides dispose to clean up the component list.
    '-----
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents Pic As System.WinForms.PictureBox
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pic = New System.WinForms.PictureBox()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        Pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        Pic.BackColor = System.Drawing.SystemColors.Control
        Pic.Location = New System.Drawing.Point(16, 16)
        Pic.Size = New System.Drawing.Size(320, 248)
        Pic.TabIndex = 0
        Pic.TabStop = False
        
        Me.Text = "Flyweight Folder"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 341)
        
        Me.Controls.Add(Pic)
    End Sub
    
#End Region
    '-----
    'mouse move event handler
    Public Sub evmouse(ByVal sender As Object, ByVal e As MouseEventArgs)
        Dim x, y, i, cnt As Integer
        Dim oldname As String
        Dim found As Boolean
        oldname = selectedname  'save old name
        x = pleft   'move through coordinates
        y = ptop
        i = 0
        cnt = 0
        found = False
        While i < names.Count And Not found
            rect.init(x, y)
            'see if a rectangle contains the mouse
            If rect.contains(e.X, e.Y) Then
                selectedname = CType(names(i), String)
                found = True
            End If
            i = i + 1
            cnt = cnt + 1
            'move on to next rectangle
            If cnt > 2 Then
                cnt = 0
                x = pleft
                y = y + vspace
            Else
                x = x + hspace
            End If
            
        End While
        'only refresh if mouse in new rectangle
        If found And oldname <> selectedname Then
            pic.Refresh()
        End If
    End Sub
End Class
