Namespace vbPatterns
    Public Class Rectangle
        Private x1, x2, y1, y2 As Integer
        Private w, h As Integer
        '-----
        Public Sub init(ByVal x_ As Integer, ByVal y_ As Integer)
            x1 = x_
            y1 = y_
            x2 = x1 + w
            y2 = y1 + h
        End Sub
        '-----
        Public Sub setSize(ByVal w_ As Integer, ByVal h_ As Integer)
            w = w_
            h = h_
        End Sub
        '-----
        Public Function contains(ByVal xp As Integer, ByVal yp As Integer) As Boolean
            Return x1 <= xp And xp <= x2 And y1 <= yp And yp <= y2
        End Function
    End Class
End Namespace
