Imports System.WinForms
Imports System.Drawing
Public Class Folder
    'Draws a folder at the specified coordinates
    Private Const w As Integer = 50, h As Integer = 30
    Private blackPen As Pen, whitePen As Pen
    Private grayPen As Pen
    Private backBrush, blackBrush As SolidBrush
    Private fnt As Font
    '-----
    Public Sub new(ByVal col As Color)
        backBrush = New SolidBrush(Col)
        blackBrush = New SolidBrush(Color.Black)
        blackPen = New Pen(color.Black)
        whitePen = New Pen(color.White)
        grayPen = New Pen(color.Gray)
        fnt = New Font("Arial", 12)
    End Sub
    '-----
    Public Sub draw(ByVal g As Graphics, ByVal x As Integer, _
            ByVal y As Integer, ByVal title As String)
        g.FillRectangle(backBrush, x, y, w, h)
        g.DrawRectangle(blackPen, x, y, w, h)
        g.Drawline(whitePen, x + 1, y + 1, x + w - 1, y + 1)
        g.Drawline(whitePen, x + 1, y, x + 1, y + h)
        
        g.DrawRectangle(blackPen, x + 5, y - 5, 15, 5)
        g.FillRectangle(backBrush, x + 6, y - 4, 13, 6)
        
        g.DrawLine(graypen, x, y + h - 1, x + w, y + h - 1)
        g.DrawLine(graypen, x + w - 1, y, x + w - 1, y + h - 1)
        g.DrawString(title, fnt, blackBrush, x, y + h + 5)
    End Sub
    
End Class
