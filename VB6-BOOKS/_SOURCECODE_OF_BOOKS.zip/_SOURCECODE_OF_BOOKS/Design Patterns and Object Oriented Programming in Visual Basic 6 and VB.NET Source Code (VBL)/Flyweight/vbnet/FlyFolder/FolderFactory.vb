Imports System.Drawing
Public Class FolderFactory
    Private selFolder, unselFolder As Folder
    '-----
    Public Sub new()
        'create the two folders
        selFolder = New Folder(Color.Brown)
        unselFolder = New Folder(color.Bisque)
    End Sub
    '-----
    Public Function getFolder(ByVal isSelected As Boolean) As Folder
        'return one or the other
        If isSelected Then
            Return selFolder
        Else
            Return unselFolder
        End If
    End Function
End Class
