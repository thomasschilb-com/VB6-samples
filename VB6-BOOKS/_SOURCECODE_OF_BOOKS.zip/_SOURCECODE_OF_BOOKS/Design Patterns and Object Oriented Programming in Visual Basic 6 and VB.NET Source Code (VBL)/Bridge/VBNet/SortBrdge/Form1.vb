Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private products As ArrayList
    Private br As Bridger   'bridge to list
    Private gbr As Bridger  'bridge to grid
    Private prodList, execList As visList
    Private fl As vbFile
    
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        Dim dtable As DataTable
        dtable = New DataTable("Products")
        
        Dim column As DataColumn
        column = New DataColumn("ProdName")
        
        dtable.Columns.add(column)
        column = New DataColumn("Qty")
        
        dtable.Columns.add(column)
        lsExecList.DataSource = dtable
        
        products = New ArrayList()
        Execlist = New ProductTable(lsExeclist)
        prodList = New ProductList(lsProdList)
        readData(products)
        Dim prodBridge As New ListBridge(prodList)
        Dim tableBridge As New ListBridge(ExecList)
        prodbridge.addData(products)
        tableBridge.addData(products)
        
    End Sub

    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents lsExecList As System.WinForms.DataGrid
    
    Private WithEvents lsProdList As System.WinForms.ListBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsExecList = New System.WinForms.DataGrid()
        Me.lsProdList = New System.WinForms.ListBox()
        
        lsExecList.BeginInit()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        lsExecList.Location = New System.Drawing.Point(192, 32)
        lsExecList.CaptionVisible = False
        lsExecList.Size = New System.Drawing.Size(200, 176)
        lsExecList.DataMember = ""
        lsExecList.TabIndex = 1
        
        lsProdList.Location = New System.Drawing.Point(16, 24)
        lsProdList.Size = New System.Drawing.Size(152, 186)
        lsProdList.TabIndex = 0
        Me.Text = "Sorted bridge"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 273)
        
        Me.Controls.Add(lsExecList)
        Me.Controls.Add(lsProdList)
        
        lsExecList.EndInit()
    End Sub
    
#End Region
    Private Sub readData(ByVal plist As ArrayList)
        Dim fl As vbFile
        Dim s As String
        fl = New vbFile("products.txt")
        fl.OpenForRead()
        s = fl.readLine
        
        While s.length > 0
            Dim p As Product
            p = New Product(s)
            plist.add(p)
            s = fl.readLine
        End While
    End Sub
    
End Class
