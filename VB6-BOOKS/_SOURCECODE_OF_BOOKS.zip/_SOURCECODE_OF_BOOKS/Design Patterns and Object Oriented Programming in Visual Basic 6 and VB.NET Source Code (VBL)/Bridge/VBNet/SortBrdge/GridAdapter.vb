Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Data


Public Class GridAdapter
private dtable as DataTable
private Dgrid as DataGrid

Public Sub New(grid as DataGrid)
  MyBase.New
  dtable = CType(grid.DataSource, DataTable)
  dgrid = grid
End Sub

Public Sub addLine(p as Product)
Dim scnt As String
dim row as DataRow
 
 dgrid.readonly = false

 row = dtable.NewRow
 row(0) = p.GetName
 row(1) = p.getQty
 
 dtable.Rows.Add(row)
 dtable.AcceptChanges
 dgrid.readonly = true
 dgrid.populatecolumns

End Sub
public sub removeLine(num as integer)
end sub

End Class
