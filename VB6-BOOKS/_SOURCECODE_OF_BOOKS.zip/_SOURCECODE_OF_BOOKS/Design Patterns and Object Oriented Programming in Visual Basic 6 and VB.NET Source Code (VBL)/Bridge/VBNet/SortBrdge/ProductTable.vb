Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class ProductTable
    Implements visList
    'class wrapper for the grid
    'to give it a common interface
    
    Private gridList As GridAdapter
    
    Public Sub addLine(ByVal p As Product) Implements visList.addLine
        gridList.AddLine(p)
    End Sub
    
    Public Sub New(ByVal c As DataGrid)
        MyBase.new()
        gridList = New GridADapter(c)
    End Sub
    
    Public Sub removeLine(ByVal num As Integer) Implements visList.removeLine
        gridList.removeLine(num)
    End Sub
    
End Class
