Interface  VisList

'add a line to the display
Sub addLine(p As Product)

'remove a line from the display
Sub removeLine(num As Integer)

End Interface
