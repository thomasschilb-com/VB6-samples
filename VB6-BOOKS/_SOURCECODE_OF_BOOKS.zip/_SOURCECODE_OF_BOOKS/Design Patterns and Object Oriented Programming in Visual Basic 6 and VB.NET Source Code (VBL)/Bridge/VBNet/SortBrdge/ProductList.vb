Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

public Class ProductList
Implements visList
'class wrapper for the list box
'to give it a common interface
Private lst As ListBox
'------------
Private Sub addLine(p As Product)  Implements visList.addLine

lst.Items.Add( p.getName)
End Sub
'------------
Public Sub New(c As ListBox)
MyBase.New
lst = c
End Sub
'------------
Public Sub removeLine(ByVal num As Integer) Implements visList.removeLine
lst.Items.remove( num)
End Sub

End Class
