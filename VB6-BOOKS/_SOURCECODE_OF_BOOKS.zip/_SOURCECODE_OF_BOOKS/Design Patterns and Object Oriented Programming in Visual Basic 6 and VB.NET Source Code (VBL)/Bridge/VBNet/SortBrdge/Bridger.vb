Imports System
Imports System.ComponentModel
Imports System.WinForms
Imports System.Collections


'Bridge interface to display classes
'add data to display

public interface Bridger
 Sub addData(col As ArrayList)

end interface