Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

'A sorted version of the Data to Vislist
'Bridge class
Public Class ListBridge
    Implements Bridger
    'A bridge between lists and display
    Private visL As visList
    '-----    
    Public Sub New(ByVal vis As visList)
        MyBase.New()
        visL = vis
    End Sub
    '-----    
    Public Sub addData(ByVal col As ArrayList) _
            Implements Bridger.addData
        Dim i, j, max As Integer
        Dim p As Product
        max = col.count
        Dim products(max) As Product
        For i = 0 To max - 1
            products(i) = CType(col(i), Product)
        Next i
        'sort array into alphabetical order
        For i = 0 To max - 1
            For j = i To max - 1
                If products(i).getName > products(j).getName Then
                    p = products(i)
                    products(i) = products(j)
                    products(j) = p
                End If
            Next j
        Next i
        'add data to list from product collection
        For i = 0 To max - 1
            visL.addLine(products(i))
        Next i
    End Sub
End Class
