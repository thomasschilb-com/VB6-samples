Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections
Imports System.Data
Imports VBPatterns

    Public Class SortBridge
        Inherits System.WinForms.Form

        'Required by the Win Forms Designer   
        Private components As System.ComponentModel.Container
                Private lsExecList As System.WinForms.DataGrid
                Private lsProdList As System.WinForms.ListBox
        Private products As ArrayList
        Private br As Bridger   'bridge to list
        Private gbr As Bridger  'bridge to grid
        Private prodList, execList As visList
        Private fl as vbFile
    
        Public Sub New()
           MyBase.New
           InitializeComponent
           products = new ArrayList
           Execlist = new ProductTable(lsExeclist)
           prodList = new ProductList(lsProdList)
           readData(products)           
           Dim prodBridge as New ListBridge(prodList)
           DIm tableBridge as New ListBridge(ExecList)
           prodbridge.addData(products)
           tableBridge.addData(products)
        End Sub

        'Clean up any resources being used
        Overrides Public Sub Dispose()
            MyBase.Dispose
            components.Dispose
        End Sub 

        'The main entry point for the application
        Shared Sub Main()
            System.WinForms.Application.Run(New SortBridge())
        End Sub

        'NOTE: The following procedure is required by the Win Forms Designer
        'Do not modify it.
        Private Sub InitializeComponent() 
            Me.components = New System.ComponentModel.Container
            Me.lsProdList = New System.WinForms.ListBox
            Me.lsExecList = New System.WinForms.DataGrid

            lsExecList.BeginInit()

            lsProdList.Location = New System.Drawing.Point(16, 24)
            lsProdList.Size = New System.Drawing.Size(144, 173)
            lsProdList.TabIndex = 0

            lsExecList.Location = New System.Drawing.Point(184, 24)
            lsExecList.Size = New System.Drawing.Size(168, 176)
            lsExecList.PreferredColumnWidth = 50
            lsExecList.DataMember = ""
            lsExecList.ForeColor = System.Drawing.SystemColors.WindowText
            lsExecList.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption
            lsExecList.TabIndex = 1
            'lsExecList.ColumnHeadersVisible = false
            lsExecList.NavigationMode = DataGridNavigationModes.None
            lsExecList.BackColor = System.Drawing.SystemColors.Window
            Dim dtable as DataTable
            dtable = new DataTable("Products")
            dtable.minimumCapacity=100
            dtable.CaseSensitive = false
            
            Dim column as DataColumn
            'column =   new DataColumn("ProdName", System.Type.GetType("System.String"))
            column =   new DataColumn("ProdName")
            
            dtable.Columns.add( column)
            'column =   new DataColumn("Qty", System.Type.GetType("System.String" ))
            column =   new DataColumn("Qty")
            
            dtable.Columns.add( column)
            lsExecList.DataSource = dtable
           
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.Text = "Bridge display"
            '@design Me.TrayLargeIcon = True
            '@design Me.TrayHeight = 0
            Me.ClientSize = New System.Drawing.Size(360, 277)
            
            Me.Controls.Add(lsExecList)
            Me.Controls.Add(lsProdList)

            lsExecList.EndInit()
        End Sub
        
        Private Sub readData(plist as ArrayList)
         Dim fl as vbFile
         DIm s as String
         fl = new vbFile("products.txt")
         fl.OpenForRead
         s = fl.readLine
        
         while s.length >0
          Dim p as Product
          p = new Product(s)
          plist.add(p)
          s = fl.readLine
         end while 
        end sub
    
    End Class


