Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

'This is the Bridge class that communicates
'between the data and the display classes
Public Class ListBridge
    Implements Bridger  
    Private visL As visList
    '-----
    Public Sub New(ByVal vis As visList)
        MyBase.New()
        visL = vis    'copy in display class
    End Sub
    '-----
    'Adds array of product data
    Public Sub addData(ByVal col As ArrayList) Implements _
            Bridger.addData
        Dim i As Integer
        Dim p As Product
        
        'add data to list from product array
        For i = 0 To col.Count - 1
            p = CType(col(i), Product)
            visL.addLine(p)
        Next i
    End Sub
End Class
