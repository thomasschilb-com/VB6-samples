Imports System
Imports System.ComponentModel
Imports System.WinForms
Imports System.Collections


'Bridge interface to data
Public Interface Bridger
    Sub addData(ByVal col As ArrayList)
End Interface