public Class Product 
'and provides accessor methods
Private prodName As String
Private qty As String
'------------
Public Sub New(prodString As String)
MyBase.New
Dim i As Integer
i = prodString.indexOf("--")
If i > 0 Then
  prodName = prodString.substring(0, i - 1).trim()
  qty = prodString.substring(i + 2 )
Else
  prodName = prodString
  qty = ""
End If
End Sub
'------------
Public Function getName() As String
getName = prodName
End Function
'------------
Public Function getQty() As String
getQty = qty
End Function 

End Class
