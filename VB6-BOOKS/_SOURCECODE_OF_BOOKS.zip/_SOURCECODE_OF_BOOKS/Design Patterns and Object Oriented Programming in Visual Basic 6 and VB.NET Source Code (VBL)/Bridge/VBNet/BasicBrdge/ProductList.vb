Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

Public Class ProductList
    Implements visList
    'class wrapper for the list box
    'to give it a common interface
    Private lst As ListBox
    '------------
    Private Sub addLine(ByVal p As Product) _
     Implements visList.addLine
        lst.Items.Add(p.getName)
    End Sub
    '------------
    Public Sub New(ByVal c As ListBox)
        MyBase.New()
        lst = c        'copy in list box
    End Sub
    '------------
    Public Sub removeLine(ByVal num As Integer) _
         Implements visList.removeLine
        lst.Items.remove(num)
    End Sub
End Class
