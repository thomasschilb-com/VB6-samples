'Interface to visual display classes
Interface VisList
    'add a line to the display
    Sub addLine(ByVal p As Product)
    'remove a line from the display
    Sub removeLine(ByVal num As Integer)
End Interface
