Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Collections

'class wrapper for the DataGrid
'to give it a common VisList interface
'uses the GridAdapter class

Public Class ProductTable
    Implements visList
    Private gridList As GridAdapter
    '-----
    Public Sub addLine(ByVal p As Product) _
            Implements visList.addLine
        gridList.AddLine(p)
    End Sub
    '-----
    Public Sub New(ByVal c As DataGrid)
        MyBase.new()
        gridList = New GridADapter(c)
    End Sub
    '-----
    Public Sub removeLine(ByVal num As Integer) _
        Implements visList.removeLine
        gridList.removeLine(num)
    End Sub
End Class
