Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms
Imports System.Data


Public Class GridAdapter
    Private dtable As DataTable
    Private Dgrid As DataGrid
    
    Public Sub New(ByVal grid As DataGrid)
        MyBase.New()
        dtable = CType(grid.DataSource, DataTable)
        dgrid = grid
    End Sub
    
    Public Sub addLine(ByVal p As Product)
        Dim scnt As String
        Dim row As DataRow
        
        dgrid.readonly = False
        
        row = dtable.NewRow
        row(0) = p.GetName
        row(1) = p.getQty
        
        dtable.Rows.Add(row)
        dtable.AcceptChanges()
        dgrid.readonly = True
        dgrid.populatecolumns()
        
    End Sub
    Public Sub removeLine(ByVal num As Integer)
    End Sub
    
End Class
