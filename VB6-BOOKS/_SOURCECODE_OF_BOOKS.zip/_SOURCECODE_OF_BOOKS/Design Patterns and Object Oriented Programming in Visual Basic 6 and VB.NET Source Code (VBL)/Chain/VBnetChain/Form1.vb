Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private chn As Chain
    Public Sub New()
        MyBase.New

        Form1 = Me

        'This call is required by the Win Form Designer.
        InitializeComponent
        setupChain()
        'TODO: Add any initialization after the InitializeComponent() call
    End Sub
    Private Sub setUpChain()
        Dim clrchain As New ColorChain(pnlcolor)
        Dim flchain As New FileChain(lsfiles)
        Dim nochain As New NoCmd(lsnocomd)
        
        chn = New ImageChain(picImage)
        chn.addChain(clrchain)
        clrchain.addChain(flchain)
        flchain.addChain(nochain)
    End Sub
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents lsnoComd As System.WinForms.ListBox
    Private WithEvents pnlColor As System.WinForms.Panel
    Private WithEvents lsFiles As System.WinForms.ListBox
    Private WithEvents btSend As System.WinForms.Button
    Private WithEvents txCommand As System.WinForms.TextBox
    Private WithEvents GroupBox1 As System.WinForms.GroupBox
    Private WithEvents picImage As System.WinForms.PictureBox
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.WinForms.GroupBox()
        Me.lsnoComd = New System.WinForms.ListBox()
        Me.btSend = New System.WinForms.Button()
        Me.picImage = New System.WinForms.PictureBox()
        Me.txCommand = New System.WinForms.TextBox()
        Me.lsFiles = New System.WinForms.ListBox()
        Me.pnlColor = New System.WinForms.Panel()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        GroupBox1.Location = New System.Drawing.Point(24, 168)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "Send commands"
        GroupBox1.Size = New System.Drawing.Size(168, 128)
        
        lsnoComd.Location = New System.Drawing.Point(360, 16)
        lsnoComd.Size = New System.Drawing.Size(112, 134)
        lsnoComd.TabIndex = 4
        
        btSend.Location = New System.Drawing.Point(48, 80)
        btSend.Size = New System.Drawing.Size(64, 24)
        btSend.TabIndex = 1
        btSend.Text = "Send"
        
        picImage.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        picImage.Location = New System.Drawing.Point(24, 16)
        picImage.Size = New System.Drawing.Size(168, 128)
        picImage.TabIndex = 0
        picImage.TabStop = False
        
        txCommand.Location = New System.Drawing.Point(8, 24)
        txCommand.Text = " "
        txCommand.TabIndex = 0
        txCommand.Size = New System.Drawing.Size(152, 20)
        
        lsFiles.Location = New System.Drawing.Point(224, 16)
        lsFiles.Size = New System.Drawing.Size(120, 134)
        lsFiles.TabIndex = 2
        
        pnlColor.BorderStyle = System.WinForms.BorderStyle.FixedSingle
        pnlColor.Location = New System.Drawing.Point(224, 184)
        pnlColor.Size = New System.Drawing.Size(120, 112)
        pnlColor.TabIndex = 3
        Me.Text = "Chain of Responsibility"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 325)
        
        GroupBox1.Controls.Add(btSend)
        GroupBox1.Controls.Add(txCommand)
        Me.Controls.Add(lsnoComd)
        Me.Controls.Add(pnlColor)
        Me.Controls.Add(lsFiles)
        Me.Controls.Add(GroupBox1)
        Me.Controls.Add(picImage)
    End Sub
    
#End Region
    
    Protected Sub btSend_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        chn.sendToChain(txcommand.Text)
    End Sub
    
End Class
