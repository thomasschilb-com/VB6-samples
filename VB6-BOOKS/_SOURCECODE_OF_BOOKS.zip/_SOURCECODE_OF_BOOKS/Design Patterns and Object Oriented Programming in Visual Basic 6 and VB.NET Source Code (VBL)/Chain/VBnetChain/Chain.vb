Public MustInherit Class Chain
    Protected chn As Chain
    Private hasLink As Boolean
    '-----
    Public Sub New()
        hasLink = False
    End Sub
    '-----
    Public Sub addChain(ByVal c As chain)
        chn = c
        haslink = True  'mark as available
    End Sub
    '-----
    'will fill this in in derived classes    
    Public MustOverride Sub sendToChain(ByVal mesg As String)
    '-----
    Public Function getChain() As chain
        Return chn
    End Function
    '-----
    Public Function hasChain() As Boolean
        Return hasLink
    End Function
End Class
