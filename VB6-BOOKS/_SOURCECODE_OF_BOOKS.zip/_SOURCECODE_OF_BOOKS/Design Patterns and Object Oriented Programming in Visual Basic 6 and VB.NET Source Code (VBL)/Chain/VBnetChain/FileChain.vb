Imports System.IO
Imports System.WinForms
Public Class FileChain
    Inherits Chain
    Private flist As ListBox
    '-----
    Public Sub new(ByVal lbox As ListBox)
        MyBase.new()
        flist = lbox
    End Sub
    '-----
    Public Overrides Sub sendToChain(ByVal mesg As String)
        Dim fname As String
        Dim files As File()
        fname = mesg + "*.*"
        files = Directory.GetFilesInDirectory( _
            Directory.CurrentDirectory, fname)
        'add them all to the listbox
        If files.Length > 0 Then
            Dim i As Integer
            For i = 0 To files.Length - 1
                flist.Items.Add(files(i).Name)
            Next
        Else
            If haschain Then
                chn.sendToChain(mesg)
            End If
        End If
    End Sub
End Class
