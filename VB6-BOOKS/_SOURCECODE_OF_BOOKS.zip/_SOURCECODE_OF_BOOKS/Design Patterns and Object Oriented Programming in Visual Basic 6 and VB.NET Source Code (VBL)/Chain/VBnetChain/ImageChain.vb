Imports System.WinForms
Imports System.Drawing
Public Class ImageChain
    Inherits Chain
    Private fl As vbFile
    Private picBox As PictureBox
    Public Sub new(ByVal pic As PictureBox)
        MyBase.new()
        picBox = pic
    End Sub
    Public Overrides Sub sendToChain(ByVal mesg As String)
        Dim fname As String = mesg + ".jpg"
        fl = New vbfile(fname)
        If fl.exists Then
            picbox.Image = New Bitmap(fname)
        Else
            If hasChain Then
                chn.sendToChain(mesg)
            End If
        End If
    End Sub
End Class
