Imports System.WinForms
Public Class NoCmd
    Inherits Chain
    Private lbox As ListBox
    Public Sub new(ByVal lsbox As ListBox)
        lbox = lsbox
    End Sub
    Public Overrides Sub sendToChain(ByVal mesg As String)
        lbox.Items.Add(mesg)
    End Sub
End Class
