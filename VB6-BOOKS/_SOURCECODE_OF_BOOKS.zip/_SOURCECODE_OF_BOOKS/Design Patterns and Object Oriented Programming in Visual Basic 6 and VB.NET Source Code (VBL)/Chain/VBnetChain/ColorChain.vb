Imports System.Drawing
Imports System.WinForms
Public Class ColorChain
    Inherits Chain
    Private panl As Panel
    Public Sub New(ByVal pnl As Panel)
        MyBase.New()
        panl = pnl
    End Sub
    Public Overrides Sub sendToChain(ByVal mesg As String)
        Select Case lcase(mesg)
            Case "red"
                panl.BackColor = Color.Red
            Case "blue"
                panl.BackColor = Color.Blue
            Case "green"
                panl.BackColor = color.Green
            Case "yellow"
                panl.BackColor = Color.Yellow
            Case Else
                If hasChain Then
                    chn.sendToChain(mesg)
                End If
        End Select
        
    End Sub
    
End Class
