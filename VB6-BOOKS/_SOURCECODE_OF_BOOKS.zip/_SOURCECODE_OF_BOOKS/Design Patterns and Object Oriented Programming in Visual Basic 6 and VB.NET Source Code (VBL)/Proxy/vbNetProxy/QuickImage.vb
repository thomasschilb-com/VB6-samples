Imports System.Drawing
Public Class QuickImage
    Implements Imager
    '-----
    Public Function getImage() As Image _
            Implements Imager.getImage
        Return New bitmap("Box.gif")
    End Function
End Class
