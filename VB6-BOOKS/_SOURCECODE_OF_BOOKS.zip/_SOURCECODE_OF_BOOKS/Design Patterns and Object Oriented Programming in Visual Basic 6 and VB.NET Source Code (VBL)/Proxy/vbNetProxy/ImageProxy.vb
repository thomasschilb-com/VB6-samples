Imports System.Threading
Imports System.Drawing
Public Class ImageProxy
    Private done As Boolean
    Private tm As Timer
    '-----
    Public Sub New()
        done = False
        'set up timer that ticks once after 5 seconds 
        tm = New Timer( _
        New TimerCallback(AddressOf tcallback), _
                            Me, 5000, 0)
    End Sub
    '-----
    Public Function isReady() As Boolean
        Return done
    End Function
    '-----
    Public Function getImage() As Image
        Dim img As Imager
        'return quick image until ready
        If isReady Then
            img = New FinalImage()
        Else
            img = New QuickImage()
        End If
        Return img.getImage
    End Function
    '-----
    Public Sub tCallback(ByVal obj As Object)
        'set done flag and turn off timer
        done = True
        tm.Dispose()
    End Sub
End Class
