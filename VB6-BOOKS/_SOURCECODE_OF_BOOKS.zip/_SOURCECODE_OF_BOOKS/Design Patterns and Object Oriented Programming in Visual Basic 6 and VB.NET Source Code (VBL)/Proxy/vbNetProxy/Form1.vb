Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Private imgProxy As ImageProxy
    Public Sub New()
        MyBase.New
        Form1 = Me
        InitializeComponent
        imgproxy = New ImageProxy()
    End Sub
    '-----
    'Form overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub 
    '-----
#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    Private WithEvents btLoad As System.WinForms.Button
    Private WithEvents pic As System.WinForms.PictureBox
    
    Dim WithEvents Form1 As System.WinForms.Form

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pic = New System.WinForms.PictureBox()
        Me.btLoad = New System.WinForms.Button()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        pic.BorderStyle = System.WinForms.BorderStyle.Fixed3D
        pic.Location = New System.Drawing.Point(40, 40)
        pic.Size = New System.Drawing.Size(280, 192)
        pic.TabIndex = 0
        pic.TabStop = False
        
        btLoad.Location = New System.Drawing.Point(136, 256)
        btLoad.Size = New System.Drawing.Size(56, 24)
        btLoad.TabIndex = 1
        btLoad.Text = "Load"
        
        Me.Text = "Image proxy"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 309)
        
        Me.Controls.Add(btLoad)
        Me.Controls.Add(pic)
    End Sub
    
#End Region
    '-----
    Protected Sub btLoad_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        pic.Image = imgProxy.getImage
    End Sub
    
End Class
