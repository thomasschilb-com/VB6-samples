Imports System.Drawing
Public Interface Imager
    Function getImage() As image
End Interface
