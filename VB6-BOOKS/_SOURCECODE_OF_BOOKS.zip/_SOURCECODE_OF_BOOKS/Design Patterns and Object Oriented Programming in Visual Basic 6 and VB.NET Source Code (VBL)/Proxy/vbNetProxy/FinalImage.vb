Imports System.Drawing
Public Class FinalImage
    Implements Imager
    '-----    
    Public Function getImage() As Image _
        Implements Imager.getImage
        Return New Bitmap("flowrtree.jpg")
    End Function
End Class
