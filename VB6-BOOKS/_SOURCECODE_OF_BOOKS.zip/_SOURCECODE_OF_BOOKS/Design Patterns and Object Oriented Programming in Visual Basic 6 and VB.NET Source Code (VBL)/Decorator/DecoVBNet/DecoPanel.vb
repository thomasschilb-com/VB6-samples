Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class DecoPanel
    Inherits System.WinForms.Panel
    Private bPen, wpen, gpen As Pen
    Private c As RichControl
    Private gotControl As Boolean
    Private mouse_over As Boolean
    Private x1, y1, x2, y2 As Single
    Public Sub New()
        MyBase.New
        'This call is required by the Win Form Designer.
        InitializeComponent()
        'Create black and white pens
        bpen = New Pen(system.Drawing.Color.Black, 1)
        wpen = New Pen(System.Drawing.Color.White, 1)        
        gotcontrol = False      'no control yet
    End Sub
    
    'overrides dispose to clean up the component list.
    Overrides Public Sub Dispose()
        MyBase.Dispose
        components.Dispose
    End Sub
    '-----
    Public Sub ctMouseEnter(ByVal sender As Object, ByVal e As EventArgs)
        mouse_over = True
        Refresh()
    End Sub
    '-----
    Public Sub ctMouseLeave(ByVal sender As Object, ByVal e As EventArgs)
        mouse_over = False
        Refresh()
    End Sub
    '-----
    Public Sub ctMouseMove(ByVal sender As Object, ByVal e As MouseEventArgs)
        mouse_over = True
    End Sub
    '-----
    Public Sub ctPaint(ByVal sender As Object, ByVal e As PaintEventArgs)
        'draw over button to change its outline
        Dim g As Graphics = e.Graphics
        'draw over everything in gray first
        g.DrawRectangle(gpen, 0, 0, x2, y2)
        'draw black and white boundaries
        'if the mouse is over
        If mouse_over Then
            g.DrawLine(bpen, 0, 0, x2 - 1, 0)
            g.DrawLine(bpen, 0, 0, 0, y2 - 1)
            g.DrawLine(wpen, 0, y2 - 1, x2 - 1, y2 - 1)
            g.DrawLine(wpen, x2 - 1, 0, x2 - 1, y2 - 1)
        End If
    End Sub
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    
    Dim WithEvents DecoPanel As System.WinForms.UserControl
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub
    
#End Region
    
    Protected Overrides Sub OnPaint(ByVal e As System.WinForms.PaintEventArgs)
        'This is where we find out about the control
        If Not gotcontrol Then  'once only
            'get the control
            c = CType(Me.Controls(0), richcontrol)
            'set the panel size  1 pixel bigger all around
            Me.Size.Width = c.Size.Width + 2
            Me.Size.Height = c.Size.Height + 2
            x1 = c.Location.X - 1
            y1 = c.Location.y - 1
            x2 = c.Size.Width
            y2 = c.Size.Height
            'create the overwrite pen
            gpen = New Pen(c.BackColor, 2)
            gotControl = True        'only once
            'mouse over, enter handler
            Dim evh As EventHandler = New EventHandler(AddressOf ctMouseEnter)
            AddHandler c.MouseHover, evh
            AddHandler c.MouseEnter, evh
            AddHandler c.MouseMove, New MouseEventHandler(AddressOf ctMouseMove)
            AddHandler c.MouseLeave, New EventHandler(AddressOf ctMouseLeave)
            'paint handler catches button's paint
            AddHandler c.Paint, New PaintEventHandler(AddressOf ctPaint)
        End If
    End Sub
End Class
