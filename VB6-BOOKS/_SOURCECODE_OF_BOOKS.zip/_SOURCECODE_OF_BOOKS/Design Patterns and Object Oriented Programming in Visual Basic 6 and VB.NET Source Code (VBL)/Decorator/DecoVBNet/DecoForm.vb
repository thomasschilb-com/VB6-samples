Imports System.ComponentModel
Imports System.Drawing
Imports System.WinForms


Public Class Form1
    Inherits System.WinForms.Form
    Public Sub New()
        MyBase.New()
        Form1 = Me
        'This call is required by the Win Form Designer.
        InitializeComponent()
    End Sub
    
    'Form overrides dispose to clean up the component list.
    Public Overrides Sub Dispose()
        MyBase.Dispose()
        components.Dispose()
    End Sub
    
#Region " Windows Form Designer generated code "
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container
    
    Private WithEvents AButton As System.WinForms.Button
    Private WithEvents DecoPanel1 As DecoVBNet.DecoPanel
    
    
    
    
    
    Private WithEvents btQuit As System.WinForms.Button
    
    
    
    
    Dim WithEvents Form1 As System.WinForms.Form
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btQuit = New System.WinForms.Button()
        Me.AButton = New System.WinForms.Button()
        Me.DecoPanel1 = New DecoVBNet.DecoPanel()
        
        '@design Me.TrayHeight = 0
        '@design Me.TrayLargeIcon = False
        '@design Me.TrayAutoArrange = True
        btQuit.Location = New System.Drawing.Point(152, 24)
        btQuit.Size = New System.Drawing.Size(80, 32)
        btQuit.TabIndex = 2
        btQuit.Text = "Quit"
        
        AButton.Location = New System.Drawing.Point(8, 8)
        AButton.Size = New System.Drawing.Size(80, 32)
        AButton.TabIndex = 0
        AButton.Text = "A button"
        
        DecoPanel1.Location = New System.Drawing.Point(8, 16)
        DecoPanel1.Size = New System.Drawing.Size(104, 48)
        DecoPanel1.TabIndex = 3
        Me.Text = "Decorator form"
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(248, 101)
        
        DecoPanel1.Controls.Add(AButton)
        Me.Controls.Add(DecoPanel1)
        Me.Controls.Add(btQuit)
    End Sub
    
#End Region
    
    
    Protected Sub btQuit_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        End
    End Sub
    
    
End Class
