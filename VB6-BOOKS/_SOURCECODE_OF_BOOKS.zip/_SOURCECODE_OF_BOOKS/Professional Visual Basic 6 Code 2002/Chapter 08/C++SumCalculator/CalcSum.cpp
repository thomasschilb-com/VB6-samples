// CalcSum.cpp : Implementation of CCalcSum
#include "stdafx.h"
#include "SumCalculator.h"
#include "CalcSum.h"

/////////////////////////////////////////////////////////////////////////////
// CCalcSum


STDMETHODIMP CCalcSum::SumofNumbers(long lsum1, long lsum2, long *total)
{
	// TODO: Add your implementation code here
	*total=(lsum1 + lsum2);

	return S_OK;
}
