// CalcSum.h : Declaration of the CCalcSum

#ifndef __CALCSUM_H_
#define __CALCSUM_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCalcSum
class ATL_NO_VTABLE CCalcSum : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCalcSum, &CLSID_CalcSum>,
	public IDispatchImpl<ICalcSum, &IID_ICalcSum, &LIBID_SUMCALCULATORLib>
{
public:
	CCalcSum()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CALCSUM)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCalcSum)
	COM_INTERFACE_ENTRY(ICalcSum)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICalcSum
public:
	STDMETHOD(SumofNumbers)(/*[in]*/long lsum1, /*[in]*/long lsum2, /*[out,retval]*/long* total);
};

#endif //__CALCSUM_H_
