For the ExeClientTest project to run a reference to ExeServerTest.exe in the directory named Page158. From the Project menu, select References and scroll down to ExeServerTest.

To see the application working, first run the ExeServerTest.exe in the Page158 dircetory. You will then be able to run multiple versions of the ExeClientTest.exe from that one server.