Before running the CustCBO please ensure that Microsoft DAO 3.51 Object Library has been selected in the References dialog.
In order for the code in this directory a copy of Nwind.mdb must be copied and pasted into this directory.
To run the example first load the Group1 project group.