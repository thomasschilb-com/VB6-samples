CREATE PROCEDURE spMTSBookInfo

@Author char (20),
@Title char (50),
@Available char (2),
@BookID char (5),
@InStock char (2),
@OutOfPrint char (2)

AS

BEGIN DISTRIBUTED TRANSACTION

INSERT MTSBooks (Author, Title, Available)
VALUES (@Author, @Title, @Available)

IF @@error!=0
BEGIN
     ROLLBACK TRANSACTION
     RETURN
END

INSERT MTSOutOfPrint (BookID, InStock, OutOfPrint) 
VALUES (@BookID, @Available, @OutOfPrint)

IF @@error!=0
BEGIN
     ROLLBACK TRANSACTION
     RETURN
END

COMMIT TRANSACTION
