BEGIN DISTRIBUTED TRANSACTION

INSERT MTSBooks (Author, Title, Available)
VALUES ("Matthew Bortniker","Professional VB6 MTS Programming","Y")

IF @@error!=0
BEGIN
     ROLLBACK TRANSACTION
     RETURN
END

INSERT MTSOutOfPrint (BookID, InStock, OutOfPrint) 
VALUES ("ac12","N","Y")

IF @@error!=0
BEGIN
     ROLLBACK TRANSACTION
     RETURN
END

COMMIT TRANSACTION
