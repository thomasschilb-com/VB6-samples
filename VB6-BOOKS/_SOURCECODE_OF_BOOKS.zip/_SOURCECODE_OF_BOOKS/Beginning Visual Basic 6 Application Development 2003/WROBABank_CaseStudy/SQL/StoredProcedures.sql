/****** Object:  Stored Procedure dbo.sp_delete_Bank    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_delete_Bank]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_delete_Bank]
GO

/****** Object:  Stored Procedure dbo.sp_delete_BankAccount    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_delete_BankAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_delete_BankAccount]
GO

/****** Object:  Stored Procedure dbo.sp_delete_CardxAccount    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_delete_CardxAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_delete_CardxAccount]
GO

/****** Object:  Stored Procedure dbo.sp_delete_payee    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_delete_payee]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_delete_payee]
GO

/****** Object:  Stored Procedure dbo.sp_delete_TxLock    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_delete_TxLock]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_delete_TxLock]
GO

/****** Object:  Stored Procedure dbo.sp_delete_WROBACard    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_delete_WROBACard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_delete_WROBACard]
GO

/****** Object:  Stored Procedure dbo.sp_insert_Bank    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_insert_Bank]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_insert_Bank]
GO

/****** Object:  Stored Procedure dbo.sp_insert_BankAccount    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_insert_BankAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_insert_BankAccount]
GO

/****** Object:  Stored Procedure dbo.sp_insert_CardxAccount    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_insert_CardxAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_insert_CardxAccount]
GO

/****** Object:  Stored Procedure dbo.sp_insert_Payee    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_insert_Payee]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_insert_Payee]
GO

/****** Object:  Stored Procedure dbo.sp_insert_TxLock    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_insert_TxLock]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_insert_TxLock]
GO

/****** Object:  Stored Procedure dbo.sp_insert_WROBACard    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_insert_WROBACard]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_insert_WROBACard]
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountHistory_By_AccountId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_AccountHistory_By_AccountId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_AccountHistory_By_AccountId]
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountId_By_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_AccountId_By_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_AccountId_By_CardId]
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountType    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_AccountType]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_AccountType]
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountType_By_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_AccountType_By_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_AccountType_By_CardId]
GO

/****** Object:  Stored Procedure dbo.sp_select_All_Payees    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_All_Payees]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_All_Payees]
GO

/****** Object:  Stored Procedure dbo.sp_select_Bank    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_Bank]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_Bank]
GO

/****** Object:  Stored Procedure dbo.sp_select_Bank_By_BankId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_Bank_By_BankId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_Bank_By_BankId]
GO

/****** Object:  Stored Procedure dbo.sp_select_BankAccount_By_AccountId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_BankAccount_By_AccountId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_BankAccount_By_AccountId]
GO

/****** Object:  Stored Procedure dbo.sp_select_BankAccount_By_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_BankAccount_By_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_BankAccount_By_CardId]
GO

/****** Object:  Stored Procedure dbo.sp_select_Last_AccountId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_Last_AccountId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_Last_AccountId]
GO

/****** Object:  Stored Procedure dbo.sp_select_Last_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_Last_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_Last_CardId]
GO

/****** Object:  Stored Procedure dbo.sp_select_PayeeByCardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_PayeeByCardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_PayeeByCardId]
GO

/****** Object:  Stored Procedure dbo.sp_select_WROBACard_PwdCnt    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_select_WROBACard_PwdCnt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_select_WROBACard_PwdCnt]
GO

/****** Object:  Stored Procedure dbo.sp_update_Bank    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_Bank]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_Bank]
GO

/****** Object:  Stored Procedure dbo.sp_update_BankAccount    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_BankAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_BankAccount]
GO

/****** Object:  Stored Procedure dbo.sp_update_BankAccount_Dec    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_BankAccount_Dec]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_BankAccount_Dec]
GO

/****** Object:  Stored Procedure dbo.sp_update_BankAccount_Inc    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_BankAccount_Inc]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_BankAccount_Inc]
GO

/****** Object:  Stored Procedure dbo.sp_update_payee    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_payee]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_payee]
GO

/****** Object:  Stored Procedure dbo.sp_update_WROBACard_Pwd    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_WROBACard_Pwd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_WROBACard_Pwd]
GO

/****** Object:  Stored Procedure dbo.sp_update_WROBACard_PwdCnt    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_update_WROBACard_PwdCnt]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_update_WROBACard_PwdCnt]
GO

/****** Object:  Stored Procedure dbo.sp_verify_BankAccount_By_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_verify_BankAccount_By_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_verify_BankAccount_By_CardId]
GO

/****** Object:  Stored Procedure dbo.sp_verify_CardAccount_By_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_verify_CardAccount_By_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_verify_CardAccount_By_CardId]
GO

/****** Object:  Stored Procedure dbo.sp_verify_Payee_By_CardId    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp_verify_Payee_By_CardId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp_verify_Payee_By_CardId]
GO

/****** Object:  Table [dbo].[AccountHistory]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[AccountHistory]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AccountHistory]
GO

/****** Object:  Table [dbo].[AccountType]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[AccountType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AccountType]
GO

/****** Object:  Table [dbo].[Bank]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[Bank]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Bank]
GO

/****** Object:  Table [dbo].[BankAccount]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[BankAccount]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[BankAccount]
GO

/****** Object:  Table [dbo].[CardxAccount]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[CardxAccount]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CardxAccount]
GO

/****** Object:  Table [dbo].[Payee]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[Payee]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Payee]
GO

/****** Object:  Table [dbo].[TxLock]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[TxLock]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[TxLock]
GO

/****** Object:  Table [dbo].[TxType]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[TxType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[TxType]
GO

/****** Object:  Table [dbo].[WROBACard]    Script Date: 4/12/2000 11:48:22 PM ******/
if exists (select * from sysobjects where id = object_id(N'[dbo].[WROBACard]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[WROBACard]
GO


SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_delete_Bank    Script Date: 4/12/2000 ******/
Create Procedure sp_delete_Bank
	(@BankId_1 smallint,
	 @ReturnValue int output)

AS DELETE Bank 
 
WHERE  (BankId = @BankId_1)

SET @ReturnValue = @@ERROR

RETURN @ReturnValue




GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_delete_BankAccount    Script Date: 4/12/2000 ******/
Create PROCEDURE sp_delete_BankAccount(@AccountId_1 int)

AS DELETE BankAccount 

WHERE 	( AccountId = @AccountId_1)


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_delete_CardxAccount    Script Date: 4/12/2000 ******/
Create PROCEDURE sp_delete_CardxAccount(@AccountId_1 int)

AS DELETE CardxAccount 

WHERE 	( AccountId = @AccountId_1)


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_delete_payee    Script Date: 4/12/2000 ******/
CREATE Procedure sp_delete_payee
	(@PayeeId_1	char(36),
	 @ReturnValue	int output)

AS  DELETE Payee 
WHERE  (PayeeId	 = @PayeeId_1)

SET @ReturnValue = @@ERROR

RETURN @ReturnValue





GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_delete_TxLock    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_delete_TxLock
	(@BankId_1 	smallint,
@CardId_2 	int)

AS DELETE TxLock 

WHERE 
	( BankId	 = @BankId_1) and
	( CardId	 = @CardId_2)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_delete_WROBACard    Script Date: 4/12/2000 ******/
Create PROCEDURE sp_delete_WROBACard(@CardId_1 int)

AS DELETE WROBACard 

WHERE 	( CardId = @CardId_1)



GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_insert_Bank    Script Date: 4/12/2000 ******/
Create Procedure sp_insert_Bank
	(@BankId_1 smallint,
	 @BankDesc_2 char(20),
	 @BankDSN_3 varchar(250),
	 @ReturnValue int output)

AS INSERT INTO Bank 
	 ( BankId,
	 BankDesc,
	 BankDSN)
 
VALUES 
	 (@BankId_1,
	 @BankDesc_2,
	 @BankDSN_3)

SET @ReturnValue = @@ERROR

RETURN   @ReturnValue 




GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_insert_BankAccount    Script Date: 4/12/2000 ******/
Create Procedure sp_insert_BankAccount
	(@AccountId_1 int,
	 @AccountType_2 tinyint,
	 @Balance_3 money,
	 @Limit_4 money,
	 @Remaining_5 money,
	 @LastDate_6 datetime,
	 @Overdraft_7 money,
	 @ReturnValue int output)

AS INSERT INTO BankAccount
	 ( AccountId,
	 AccountType,
	 Balance,
	 DailyWithdrawalLimit,
	 DailyRemaining,
	 LastWithdrawalDate,
	 OverdraftLimit)
 
VALUES 
	 (@AccountId_1,
	 @AccountType_2,
	 @Balance_3,
	 @Limit_4,
	 @Remaining_5,
	 @LastDate_6,
	 @Overdraft_7)

SET @ReturnValue = @@ERROR

RETURN   @ReturnValue 



GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_insert_CardxAccount    Script Date: 4/12/2000 ******/
Create Procedure sp_insert_CardxAccount
	(@CardId_1 int,
	 @AccountType_2 tinyint,
	 @AccountId_3 int,
	 @ReturnValue int output)

AS INSERT INTO CardxAccount
	 ( CardId,
	 AccountType,
	 AccountId)
 
VALUES 
	 (@CardId_1,
	 @AccountType_2,
	 @AccountId_3)

SET @ReturnValue = @@ERROR

RETURN   @ReturnValue 


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_insert_Payee    Script Date: 4/12/2000 ******/

CREATE PROCEDURE sp_insert_Payee
	(@CardId_2 	int,
	 @PayeeDesc_3 	char(30),
	 @BankId_4 	smallint,
	 @AccountId_5 	int,
	 @DefaultAmount_6 	money,
	 @WROBACardId_7	int,
	 @ReturnValue	int output)

AS INSERT INTO Payee 
	 ( PayeeId,
	 CardId,
	 PayeeDesc,
	 BankId,
	 AccountId,
	 DefaultAmount,
	 WROBACardId) 
 
VALUES 
	( NewID(),
	 @CardId_2,
	 @PayeeDesc_3,
	 @BankId_4,
	 @AccountId_5,
	 @DefaultAmount_6,
	 @WROBACardId_7)

SET @ReturnValue = @@ERROR

RETURN   @ReturnValue 



GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_insert_TxLock    Script Date: 4/12/2000 ******/

CREATE PROCEDURE sp_insert_TxLock
	(@BankId_1 	smallint,
@CardId_2 	int)

AS INSERT INTO TxLock 
	 (BankId,  CardId) 
 
VALUES 
	( @BankId_1, @CardId_2)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_insert_WROBACard    Script Date: 4/12/2000 ******/
CREATE Procedure sp_insert_WROBACard
	(@CardId_1 int,
	 @Password_2 char(10),
	 @InvalidPasswordCnt_3 tinyint,
	 @ReturnValue int output)

AS INSERT INTO WROBACard 
	 ( CardId,
	 Password,
	 InvalidPasswordCnt)
 
VALUES 
	 (@CardId_1,
	 @Password_2,
	 @InvalidPasswordCnt_3)

SET @ReturnValue = @@ERROR

RETURN   @ReturnValue 

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountHistory_By_AccountId    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_AccountHistory_By_AccountId (
    @AccountId_1 int,
    @MaxTxDate_2 datetime) 
AS 
SELECT TOP 5 AccountHistory.TxDate, TxType.TxTypeDesc, 
    AccountHistory.TxDescription, AccountHistory.TxAmount, 
    AccountHistory.CounterpartyRef
FROM AccountHistory INNER JOIN
    TxType ON AccountHistory.TxType = TxType.TxType
WHERE (AccountHistory.AccountId = @AccountId_1) AND 
    (TxDate <=
        (SELECT MAX(TxDate)
      FROM AccountHistory
      WHERE (AccountHistory.AccountId = @AccountId_1) AND 
           (TxDate < @MaxTxDate_2)))
ORDER BY AccountHistory.TxDate DESC

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountId_By_CardId    Script Date: 04/12/2000 ******/
Create PROCEDURE sp_select_AccountId_By_CardId (
@CardId_1 int) 
AS SELECT CardxAccount.AccountId
FROM CardxAccount INNER JOIN
    WROBACard ON 
    CardxAccount.CardId = WROBACard.CardId 
WHERE (WROBACard.CardId = @CardId_1)

--RETURN @@ROWCOUNT
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountType    Script Date: 4/12/2000 ******/
Create Procedure sp_select_AccountType

As SELECT AccountType, AccountTypeDesc

FROM AccountType

WHERE (AccountTypeDesc <> 'Administrator')


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_AccountType_By_CardId    Script Date: 4/12/2000 ******/
CREATE Procedure sp_select_AccountType_By_CardId(@CardId_1 int)

As SELECT AccountTypeDesc

FROM AccountType INNER JOIN
      CardxAccount ON
      AccountType.AccountType = CardxAccount.AccountType

WHERE (CardxAccount.CardId = @CardId_1)


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_All_Payees    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_All_Payees (@CardId_1 int)

AS

SELECT PayeeId, CardId, PayeeDesc, BankId, AccountId, DefaultAmount, WROBACardId

FROM Payee

WHERE (WROBACardId = @CardId_1)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_Bank    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_Bank AS
SELECT BankId, BankDesc, BankDSN
FROM Bank
ORDER BY BankId
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_Bank_By_BankId    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_Bank_By_BankId (
@BankId_1 int) 
AS 
SELECT BankDesc, BankDSN
FROM Bank
WHERE (BankId = @BankId_1)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_BankAccount_By_AccountId    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_BankAccount_By_AccountId (
@AccountId_1 int, 
@AccountTypeDesc_2 char(15) out,
@Balance_3 money out,
@DailyRemaining_4 money out,
@OverdraftLimit_5 money out) 
AS
-- NOTE: If LastWithdrawalDate is not current, then this 
-- stored procedure will reset the DailyRemaining
-- and the LastWithdrawalDate.

DECLARE @today DATETIME

SELECT @today = GETDATE()

IF 	(SELECT DATEDIFF(DAY, LastWithdrawalDate, @today) 
		FROM BankAccount 
		WHERE ( AccountId	 = @AccountId_1)) 
	> 0
BEGIN
UPDATE BankAccount 
	SET  DailyRemaining	 = DailyWithdrawalLimit,
	 LastWithdrawalDate	 = @today
		WHERE ( AccountId	 = @AccountId_1)
END

SELECT 
    @AccountTypeDesc_2 = AccountType.AccountTypeDesc, 
    @Balance_3 = BankAccount.Balance, 
    @DailyRemaining_4 = BankAccount.DailyRemaining, 
    @OverdraftLimit_5 = BankAccount.OverdraftLimit
FROM BankAccount INNER JOIN
    AccountType ON 
    BankAccount.AccountType = AccountType.AccountType
WHERE (BankAccount.AccountId = @AccountId_1)



GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_BankAccount_By_CardId    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_BankAccount_By_CardId (
@CardId_1 int) 
AS 
SELECT BankAccount.AccountId, AccountType.AccountTypeDesc, 
    BankAccount.Balance, BankAccount.DailyWithdrawalLimit, 
    BankAccount.DailyRemaining, 
    BankAccount.LastWithdrawalDate, 
    BankAccount.OverdraftLimit
FROM BankAccount INNER JOIN
    CardxAccount ON 
    BankAccount.AccountId = CardxAccount.AccountId INNER JOIN
    WROBACard ON 
    CardxAccount.CardId = WROBACard.CardId INNER JOIN
    AccountType ON 
    CardxAccount.AccountType = AccountType.AccountType
WHERE (WROBACard.CardId = @CardId_1)

--RETURN @@ROWCOUNT
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_Last_AccountId    Script Date: 04/12/2000 ******/
Create PROCEDURE sp_select_Last_AccountId(@ReturnValue int output)
AS SELECT @ReturnValue = MAX(AccountId)
FROM CardxAccount 

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_Last_CardId    Script Date: 04/12/2000 ******/
Create PROCEDURE sp_select_Last_CardId(@ReturnValue int output)
AS SELECT @ReturnValue = MAX(CardId)
FROM WROBACard


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_PayeeByCardId    Script Date: 4/12/2000 ******/
CREATE Procedure sp_select_PayeeByCardId
	(@CardId_1 	int)

AS SELECT  
	 PayeeId,
	 PayeeDesc,
	 BankId,
	 AccountId,
	 DefaultAmount

FROM Payee

WHERE (CardId =  @CardId_1)


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_select_WROBACard_PwdCnt    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_select_WROBACard_PwdCnt (
@CardId_1 int, 
@Password_2 char(10),
@InvalidPasswordCnt_3 tinyint output) 
AS 
SELECT @InvalidPasswordCnt_3 = InvalidPasswordCnt 
FROM WROBACard 
WHERE CardId = @CardId_1 
AND Password = @Password_2

return @@ROWCOUNT    -- 0 means not found, 1 means it matched
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_Bank    Script Date: 4/12/2000 ******/
Create PROCEDURE sp_update_Bank
	(@BankId_1 smallint,
	 @BankDesc_2 char(20),
	 @BankDSN_3 varchar(250),
	 @ReturnValue int output)

AS UPDATE Bank

SET  BankDesc = @BankDesc_2,
        BankDSN = @BankDSN_3

WHERE 
	(BankId = @BankId_1)

SET @ReturnValue = @@ERROR

RETURN @ReturnValue
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_BankAccount    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_update_BankAccount
	(@AccountId_1 	int,
	 @Balance_2 	money,
	 @DailyRemaining_3 	money)

AS UPDATE BankAccount 

SET  Balance	 = @Balance_2,
	 DailyRemaining	 = @DailyRemaining_3

WHERE 
	( AccountId	 = @AccountId_1)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_BankAccount_Dec    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_update_BankAccount_Dec
	(@AccountId_1 	int,
	 @TxAmount_2 	money,
	 @TxType_3 	tinyint,
	 @TxDescription_4 	char(40),
	 @CounterpartyRef_5 	char(16),
	 @ReturnValue int output

-- NOTE 1: The name of the @ReturnValue parameter is hardcoded 
-- in a VB method in the data layer and MUST NOT be changed. 
-- NOTE 2:The following meaning for the return values are 
-- assumed in the business layer:
	-- Success = 0; 
	-- DailyLimitExceeded = 1; 
	-- NotEnoughFunds = 2; 
	-- UnknownError = 3.
-- NOTE 3: If LastWithdrawalDate is not current, then this 
-- stored procedure will reset the DailyRemaining
-- and the LastWithdrawalDate, even if the withdrawal
-- is refused (DailyLimitExceeded or NotEnoughFunds).
)

AS 

DECLARE @today DATETIME

SELECT @today = GETDATE()

SELECT @ReturnValue = 3         -- Pessimistic default to UnknownError

IF 	(SELECT DATEDIFF(DAY, LastWithdrawalDate, @today) 
		FROM BankAccount 
		WHERE ( AccountId	 = @AccountId_1)) 
	> 0
BEGIN
	-- LastWithdrawalDate is not current, reset the DailyRemaining
	-- and the LastWithdrawalDate

	UPDATE BankAccount 
	SET	DailyRemaining	 = DailyWithdrawalLimit,
		LastWithdrawalDate	 = @today
	WHERE ( AccountId	 = @AccountId_1)
END

IF 	(SELECT Balance + OverdraftLimit
		FROM BankAccount 
		WHERE ( AccountId	 = @AccountId_1)) 
	< @TxAmount_2

	SELECT @ReturnValue = 2         -- NotEnoughFunds

ELSE

BEGIN

	IF 	(SELECT DailyRemaining
			FROM BankAccount 
			WHERE ( AccountId	 = @AccountId_1)) 
		< @TxAmount_2

		SELECT @ReturnValue = 1         -- DailyLimitExceeded

	ELSE

	BEGIN
		-- Withdraw
		UPDATE BankAccount 
		SET	Balance	 	= Balance - @TxAmount_2,
			DailyRemaining	= DailyRemaining - @TxAmount_2
		WHERE 
		( AccountId	 = @AccountId_1)

		-- Update AccountHistory
		INSERT INTO AccountHistory 
		( TxId,
		AccountId,
		TxDate,
		TxType,
		TxDescription,
		TxAmount,
		CounterpartyRef)  
		VALUES 
		( NEWID(),
		@AccountId_1,
		@today,
		@TxType_3,
		@TxDescription_4,
		- @TxAmount_2,
		@CounterpartyRef_5)

		SELECT @ReturnValue = 0         -- Success
	END
END

RETURN @ReturnValue


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_BankAccount_Inc    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_update_BankAccount_Inc
	(@AccountId_1 	int,
	 @TxAmount_2 	money,
	 @TxType_3 	tinyint,
	 @TxDescription_4 	char(40),
	 @CounterpartyRef_5 	char(16))

AS 

UPDATE BankAccount 
SET	Balance	 	= Balance + @TxAmount_2
WHERE 
	( AccountId	 = @AccountId_1)

INSERT INTO AccountHistory 
	 ( TxId,
	 AccountId,
	 TxDate,
	 TxType,
	 TxDescription,
	 TxAmount,
	 CounterpartyRef) 
 
VALUES 
	( NEWID(),
	 @AccountId_1,
	 GETDATE(),
	 @TxType_3,
	 @TxDescription_4,
	 @TxAmount_2,
	 @CounterpartyRef_5)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_payee    Script Date: 4/12/2000 ******/
CREATE Procedure sp_update_payee
	(@PayeeId_1	char(36),
	 @PayeeDesc_2 	char(30),
	 @DefaultAmount_3 	money,
	 @ReturnValue	int output)

AS UPDATE Payee 

SET 	PayeeDesc = @PayeeDesc_2,
	DefaultAmount = @DefaultAmount_3

WHERE 	( PayeeId	 = @PayeeId_1)

SET @ReturnValue = @@ERROR

RETURN  @ReturnValue 

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_WROBACard_Pwd    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_update_WROBACard_Pwd (
@CardId_1 int, 
@Password_2 char(10))
AS 
UPDATE WROBACard SET Password = @Password_2
WHERE CardId = @CardId_1 

return @@ROWCOUNT    -- 0 means not found, 1 means it matched
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_update_WROBACard_PwdCnt    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_update_WROBACard_PwdCnt
	(@CardId_1 	int,
	 @InvalidPasswordCnt_2 	tinyint)

AS UPDATE WROBACard 

SET  InvalidPasswordCnt	 = @InvalidPasswordCnt_2 

WHERE 
	( CardId	 = @CardId_1)

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_verify_BankAccount_By_CardId    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_verify_BankAccount_By_CardId (
@CardId_1 int,
@ReturnValue int output
) 
AS 
SELECT @ReturnValue  = COUNT(BankAccount.AccountId)
FROM BankAccount
WHERE (BankAccount.AccountId = @CardId_1)
RETURN @ReturnValue

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_verify_CardAccount_By_CardId    Script Date: 4/12/2000 ******/
Create PROCEDURE sp_verify_CardAccount_By_CardId (@CardId_1 int,@ReturnValue int output) 
AS 
SELECT @ReturnValue  = COUNT(CardId)
FROM WROBACard
WHERE (CardId = @CardId_1)
RETURN @ReturnValue


GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

/****** Object:  Stored Procedure dbo.sp_verify_Payee_By_CardId    Script Date: 4/12/2000 ******/
CREATE PROCEDURE sp_verify_Payee_By_CardId (@CardId_1 int, @ReturnValue int output)
AS 
SELECT CardId
FROM Payee
WHERE (CardId = @CardId_1)

SET @ReturnValue = @@ROWCOUNT    -- 0 means not found, 1 means it matched

RETURN @ReturnValue

GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

