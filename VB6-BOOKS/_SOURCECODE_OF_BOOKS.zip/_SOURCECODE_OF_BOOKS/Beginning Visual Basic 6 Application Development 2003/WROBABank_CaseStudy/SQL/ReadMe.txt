Schema.sql creates the BigBank database, including all tables, constraints and stored procedures. This is an alternative to building the database manually, as described in the book.

StoredProcedures.sql creates the stored procedures only - use this if you have created the database manually, as described in the book. If you have built the database using Schema.sql, you DON'T need to use this script.

FillTables.sql will populate the finished database.