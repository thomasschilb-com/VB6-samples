INSERT [dbo].[AccountType] (
	[AccountType],
	[AccountTypeDesc]
)
VALUES (
	0, 
	'Administrator'
)
GO
INSERT [dbo].[AccountType] (
	[AccountType],
	[AccountTypeDesc]
)
VALUES (
	1, 
	'Checking'
)
GO

INSERT [dbo].[AccountType] (
	[AccountType],
	[AccountTypeDesc]
)
VALUES (
	2, 
	'Saving'
)
GO

INSERT [dbo].[WROBACard] (
	[CardId],
	[Password]
)
VALUES (
	10000, 
	'Admin'
)
GO

INSERT [dbo].[WROBACard] (
	[CardId],
	[Password]
)
VALUES (
	10001, 
	'Secret1'
)
GO

INSERT [dbo].[WROBACard] (
	[CardId],
	[Password]
)
VALUES (
	10002, 
	'Secret2'
)
GO

INSERT [dbo].[Bank] (
	[BankId],
	[BankDesc],
	[BankDSN]
)
VALUES (
	1, 
	'Big Bank',
	'DSN_Big_Bank'
)
GO

INSERT [dbo].[Bank] (
	[BankId],
	[BankDesc],
	[BankDSN]
)
VALUES (
	2, 
	'Another Big Bank',
	'DSN_Another_Big_Bank'
)
GO

INSERT [dbo].[Bank] (
	[BankId],
	[BankDesc],
	[BankDSN]
)
VALUES (
	3, 
	'Small Bank',
	'DSN_Small_Bank'
)
GO

INSERT [dbo].[BankAccount] (
	[AccountId],
	[AccountType],
	[Balance],
	[DailyWithdrawalLimit],
	[DailyRemaining],
	[LastWithdrawalDate],
	[OverdraftLimit]
) 
VALUES (
	20000, 
	0,
	0,
	0,
	0,
	GETDATE(),
	0
)
GO

INSERT [dbo].[BankAccount] (
	[AccountId],
	[AccountType],
	[Balance],
	[DailyWithdrawalLimit],
	[DailyRemaining],
	[LastWithdrawalDate],
	[OverdraftLimit]
) 
VALUES (
	20001, 
	1,
	254,
	500,
	500,
	GETDATE(),
	500
)
GO

INSERT [dbo].[BankAccount] (
	[AccountId],
	[AccountType],
	[Balance],
	[DailyWithdrawalLimit],
	[DailyRemaining],
	[LastWithdrawalDate],
	[OverdraftLimit]
) 
VALUES (
	20002, 
	2,
	2376,
	500,
	500,
	GETDATE(),
	500
)
GO

INSERT [dbo].[BankAccount] (
	[AccountId],
	[AccountType],
	[Balance],
	[DailyWithdrawalLimit],
	[DailyRemaining],
	[LastWithdrawalDate],
	[OverdraftLimit]
) 
VALUES (
	20003, 
	1,
	-56,
	1000,
	40,
	GETDATE(),
	1500
)
GO

INSERT [dbo].[BankAccount] (
	[AccountId],
	[AccountType],
	[Balance],
	[DailyWithdrawalLimit],
	[DailyRemaining],
	[LastWithdrawalDate],
	[OverdraftLimit]
) 
VALUES (
	20004, 
	2,
	3236,
	500,
	340,
	GETDATE(),
	500
)
GO

INSERT [dbo].[CardxAccount] (
	[CardId],
	[AccountType],
	[AccountId]
)
VALUES (
	10000, 
	0,
	20000
)
GO

INSERT [dbo].[CardxAccount] (
	[CardId],
	[AccountType],
	[AccountId]
)
VALUES (
	10001, 
	1,
	20001
)
GO

INSERT [dbo].[CardxAccount] (
	[CardId],
	[AccountType],
	[AccountId]
)
VALUES (
	10001, 
	2,
	20002
)
GO

INSERT [dbo].[CardxAccount] (
	[CardId],
	[AccountType],
	[AccountId]
)
VALUES (
	10002, 
	1,
	20003
)
GO

INSERT [dbo].[CardxAccount] (
	[CardId],
	[AccountType],
	[AccountId]
)
VALUES (
	10002, 
	2,
	20004
)
GO

INSERT [dbo].[TxType] (
	[TxType],
	[TxTypeDesc]
) VALUES (
	1, 
	'TSF'
)
GO

INSERT [dbo].[TxType] (
	[TxType],
	[TxTypeDesc]
) VALUES (
	2, 
	'BIL'
)
GO

INSERT [dbo].[Payee] (
	[PayeeId],
	[CardId],
	[PayeeDesc],
	[BankId],
	[AccountId],
	[DefaultAmount],
	[WROBACardId]
) VALUES (
	'67FC28E6-6174-4684-8409-138CE36CED6C'
	2, 
	10002,
	'Cecilia Poremsky',
	1,
	20003,
	100,
	10001
)
GO
