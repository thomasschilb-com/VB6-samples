To integrate the Logger class in the WROBA Banking Application, 
it is necessary to replace the existing Context.bas module in the 
Bank_DB project, and add the Logger.cls class to the Bank_DB project.

It is also necessary to run the Logger.sql script in SQL Query Analyser 
in order to add the appropriate table to the Database.