Before running the Client.exe application please ensure that you have registered Employee.dll on your computer.

(Select Run from the Start men and enter - regsvr32 "C:\ProVB6DB\Employee.dll" in the Open text box.)