Before running any of the code in this folder please create a DSN called Northwind that connects to your Northwind database in SQL Server.

Before running ClientApp.exe please ensure that you have registered ServerApp.dll on your machine and installed it into MTS.