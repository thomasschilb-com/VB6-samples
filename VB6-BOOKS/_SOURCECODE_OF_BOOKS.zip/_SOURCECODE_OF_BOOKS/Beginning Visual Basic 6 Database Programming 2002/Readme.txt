Readme - Beginning VB 6 Databases

Please add Biblio.mdb and Nwind.mdb to this folder, C:\BegDB

To see the applications in action please select the .vbp or .vbg as applicable.